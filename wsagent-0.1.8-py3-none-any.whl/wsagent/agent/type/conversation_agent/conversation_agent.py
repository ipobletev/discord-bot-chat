from enum import Enum
from typing import List, Optional, Union
import uuid
from wsagent.agent.base import Agent
from wsagent import AIServices
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_services.ai_services_interface import AIServicesInterface
from wsagent.ai_services.services.openai.utils.count import count_tokens_from_text
from wsagent.ai_services.services.openai.utils.dict_to_messages_format import format_chat_messages_responses
from wsagent.data_format.data_format import DataFormatInterface
from wsagent.data_format.data_format_enum import DataFormat
from wsagent.storages.storages_enum import Storage
from wsagent.utils.print import print_chunk_async
from datetime import datetime

class ConversationalAgent(Agent):
    
    def __init__(self, 
        name: Optional[str] = None,
        session_id: Optional[str] = None,
        #
        embedding_model: Optional[Union[Enum,str]] = None,
        llm_model: Optional[Union[Enum,str]] = None,
        # storage
        ai_service_params: Optional[dict] = None,
        memory_storage_type: Optional[type] = None,
        memory_storage_params: Optional[dict] = None,
        general_data_storage_type: Optional[type] = None,
        general_data_storage_params: Optional[dict] = None,
        # logging parameters
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
        ):
        
        if name is None: name='conv_agent'
        if log_path is None: log_path=f'.logs/{datetime.now().strftime("%Y_%m_%d_%H_%M_%S")}'
        if embedding_model is None: embedding_model = AIHelper.OpenAI.Embedding.Models.LARGE_V3
        if llm_model is None: llm_model = AIHelper.OpenAI.Chat.Models.GPT_4_O
        if memory_storage_type is None: 
            memory_storage_type = Storage.Type.LOCAL_RAM
            memory_storage_params={
                "storage_name": "memory",
                "storage_struc": self.create_data_item_for_memory,
                "storage_ident": []
            }
        if general_data_storage_type is None: 
            general_data_storage_type = Storage.Type.LOCAL_RAM
            general_data_storage_params={
                "storage_name": "general_data",
                "storage_struc": self.create_data_item_for_generaldata,
                "storage_ident": []
            }
        # Secure structure for storage agent
        memory_storage_params['storage_struc'] = self.create_data_item_for_memory
        general_data_storage_params['storage_struc'] = self.create_data_item_for_generaldata
        
        log_name=f'{name}'
        
        super().__init__(
            name=name,
            session_id=session_id,
            type_name='conversational_agent',
            description='Conversational agent is a conversable agent that uses a LLM to respond to the user request', 
            tools=[],
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )
        
        # AI Services
        self.embedding_model=embedding_model
        self.llm_model=llm_model
        
        # Storage
        self.ai_service_params=ai_service_params
        self.memory_storage_type=memory_storage_type
        self.memory_storage_params=memory_storage_params
        self.general_data_storage_type=general_data_storage_type
        self.general_data_storage_params=general_data_storage_params
        
        # Persistent storage for LocalRam
        if memory_storage_type == Storage.Type.LOCAL_RAM:
            self.storage_memory=[]
            if self.memory_storage_params is None:
                self.memory_storage_params={}
            self.memory_storage_params['storage_ident']=self.storage_memory
                
        if general_data_storage_type == Storage.Type.LOCAL_RAM:
            self.storage_general_data=[] 
            if self.general_data_storage_params is None:
                self.general_data_storage_params={}
            self.general_data_storage_params['storage_ident']=self.storage_general_data
        
    @staticmethod
    def create_data_item_for_memory(
        role: Optional[str]=None,   
        content: Optional[str]=None,  
        token_count: Optional[int]=None,
        content_vector: Optional[list]=None
    ):
        
        if role is None: raise ValueError("role must be provided")
        if content is None: raise ValueError("content must be provided")
        if token_count is None: raise ValueError("token_count must be provided")
        
        memory_item = {
            "create_at": datetime.now().timestamp(),
            "id": str(uuid.uuid4()),
            "role": role,
            "content": content,
            "content_vector": content_vector,
            "token_count": token_count,
        }
        return memory_item
    
    @staticmethod
    def create_data_item_for_generaldata(
        init_timestamp: Optional[float]=None,
        model: Optional[str]=None  
    ):
    
        if init_timestamp is None: raise ValueError("content must be provided")
        if model is None: raise ValueError("model must be provided")
        
        data_item = {
            "create_at": datetime.now().timestamp(),
            "id": str(uuid.uuid4()),
            "data": {
                "init_timestamp": init_timestamp,
                "model": model
            }
        }

        return data_item
           
    def setup_request_services(self,
        session_log_path: Optional[str] = None, 
        session_log_name: Optional[str] = None, 
        session_id: Optional[str] = None):
     
        # Set memory for agent
        self.memory=DataFormatInterface(
            ai_service_params=self.ai_service_params,
            storage_type=self.memory_storage_type,
            storage_params=self.memory_storage_params,
            session_id=session_id,
            log_name=session_log_name,
            log_path=f'{session_log_path}',
            enable_log_file=self.enable_log_file,
            enable_log_stream=self.enable_log_stream
        )
        
        # Set data_metadata for agent
        self.general_data=DataFormatInterface(
            ai_service_params=self.ai_service_params,
            storage_type=self.general_data_storage_type,
            storage_params=self.general_data_storage_params,
            session_id=session_id,
            log_name=session_log_name,
            log_path=f'{session_log_path}',
            enable_log_file=self.enable_log_file,
            enable_log_stream=self.enable_log_stream
        )

        # Set up ai model
        self.ai_service = AIServicesInterface(
            ai_service_params=self.ai_service_params,
            session_id=None,
            log_name=f'{session_log_name}',
            log_path=f'{session_log_path}',
            enable_log_file=self.enable_log_file,
            enable_log_stream=self.enable_log_stream
        )
        
    async def query_llm(self, user_query: Optional[str] = None):
                
        # Get relevant memories from agent_memory with embedding query   
        relevant_memories = await self.memory.execute(
            algorithm= DataFormat.Algorithm.Search.VECTOR_SEARCH,
            algorithm_params = {
                # AI Service parameters
                "embedding_model": self.embedding_model,
                # Storage parameters
                # "storage_ident": ".data/local_json/data.json"
                "k_top": 2,
                "return_fields": ['role','content','vector_score'],
                "input_query": user_query,
                "vector_field": "content_vector"
            }
        )
        memory_messages = format_chat_messages_responses(relevant_memories.result)
        
        # Save query to agent_memory
        vector_response = await self.ai_service.execute(
            action=AIHelper.Action.EMBEDDING,
            action_params={
                "model": self.embedding_model,
                "input": user_query,
            }
        ) 
        user_token_count=count_tokens_from_text(input_txt=user_query,model=self.llm_model)
        await self.memory.execute(
            algorithm= DataFormat.Algorithm.Insert.DEFAULT,
            algorithm_params = {
                "data": self.create_data_item_for_memory(
                    role='user',
                    content=user_query,
                    token_count=user_token_count,
                    content_vector=vector_response.result
                )
            }
        )

        # LLM response
        messages = memory_messages + [{'role': 'user', 'content': user_query}]
        response = await self.ai_service.execute(
            action=AIHelper.Action.CHAT,
            action_params={  
                "model": self.llm_model,
                "messages": messages,
                "stream": True,
                "callback": print_chunk_async
            }
        )     
        assistant_response = response.result[0]
        
        # Get vector assistant response 
        vector_assistant_response = await self.ai_service.execute(
            action=AIHelper.Action.EMBEDDING,
            action_params={
                "model": self.embedding_model,
                "input": user_query,
            }
        )    
        
        # Save assistant response to agent_memory
        assistant_token_count=count_tokens_from_text(input_txt=assistant_response,model=self.llm_model)
        await self.memory.execute(
            algorithm= DataFormat.Algorithm.Insert.DEFAULT,
            algorithm_params = {
                "data": self.create_data_item_for_memory(
                    role='assistant',
                    content=assistant_response,
                    token_count=assistant_token_count,
                    content_vector=vector_assistant_response.result
                )
            }
        )
        
        # Save another values form response to another storage
        await self.general_data.execute(
            algorithm = DataFormat.Algorithm.Insert.DEFAULT,
            algorithm_params = {
                "data": self.create_data_item_for_generaldata(
                    init_timestamp=response.init_timestamp,
                    model= self.llm_model.value if isinstance(self.llm_model, Enum) else self.llm_model
                )
            }
        )
        
        # End of your functionality      
        return assistant_response

    async def core_functionality(self, 
        query: Optional[str] = None,
        session_id: Optional[str] = None,
        session_log_name: Optional[str] = None, 
        session_log_path: Optional[str] = None):
        
        # define your functionality here
        self.log.info(f'Agent: {self.name} is running...')
        self.log.info(f'User query: {query}')
        
        # Use the determined model type and name for agent_memory
        assistant_response = await self.query_llm(query)

        # End of your functionality
        self.log.info(f"Assistant: {assistant_response}")

        return assistant_response