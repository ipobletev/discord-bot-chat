import json
from typing import List, Optional
import uuid
from wsagent.agent.base import Agent
from wsagent.agent.type.convknow_agent.prompt import CHAT_MEMORY_LONGTERM_PROMPT, CHAT_SHORTERM_PROMPT, KNOWLEDGE_LONGTERM_PROMPT, SYSTEM_PROMPT_PREFIX, USER_PROMPT_SUFFIX
from wsagent import AIServices
from wsagent.ai_services.services.openai.utils.count import count_tokens_from_text
from wsagent.ai_services.services.openai.utils.dict_to_messages_format import format_chat_messages_responses
from wsagent.data_format.type.general_data import GeneralData
from datetime import datetime
from wsagent.storages.storages import StorageType
from wsagent.utils.print import print_chunk_async

###########################################################################

# Conversable and Knowledgeable Agent
class ConvKnowAgent(Agent):
    
    def __init__(self, 
        name: Optional[str] = None,
        api_key: Optional[str] = None,
        id: Optional[str] = None,
        # storage
        knowledge_memory_storage_type: Optional[str] = None,
        chat_memory_storage_type: Optional[str] = None,
        knowledge_memory_storage_params: Optional[str] = None,
        chat_memory_storage_params: Optional[str] = None,
        # agent parameters
        k_top_knowledge: Optional[int] = 5,
        k_top_chat: Optional[int] = 5,
        # logging parameters
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False,
        *args, **kwargs
        ):
        
        if name is None: name='ConvKnowAgent'
        if log_path is None: log_path=f'.logs/{datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}/{name}'
        if chat_memory_storage_type is None: chat_memory_storage_type = StorageType.Storage.LocalRam
        if knowledge_memory_storage_type is None: knowledge_memory_storage_type = StorageType.Storage.LocalRam
        
        log_name=f'{name}'
        
        super().__init__(
            name=name,
            type_name='conversational_knowledge_agent',
            description='Conversational and Knowledge agent is a conversable agent with a chat memory and external knowledge memory that uses a LLM to respond to the user request', 
            id=id,
            tools=[],
            api_key=api_key,
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream,
            *args, **kwargs
        )

        self.knowledge_memory_storage_type=knowledge_memory_storage_type
        self.knowledge_memory_storage_params=knowledge_memory_storage_params
        self.chat_memory_storage_type=chat_memory_storage_type
        self.chat_memory_storage_params=chat_memory_storage_params
        self.log_name=log_name
        self.log_path=log_path
        
        self.k_top_knowledge=k_top_knowledge
        self.k_top_chat=k_top_chat

        # Persistent storage for LocalRam
        if chat_memory_storage_type == StorageType.Storage.LocalRam:
            self.chat_memory_data=[]
            if self.chat_memory_storage_params is None: self.chat_memory_storage_params={}
            self.chat_memory_storage_params['external_ram_storage']=self.chat_memory_data
                
        if knowledge_memory_storage_type == StorageType.Storage.LocalRam:
            self.knowledge_memory_data=[] 
            if self.knowledge_memory_storage_params is None: self.knowledge_memory_storage_params={}
            self.knowledge_memory_storage_params['external_ram_storage']=self.knowledge_memory_data
        
    def setup_request_services(self,session_log_path, session_log_name,*args, **kwargs):

        def item_chat_index_schema( 
            role: Optional[str]=None,   
            content: Optional[str]=None,  
            content_vector: Optional[str]=None,
            token_count: Optional[int]=None,
            tags: Optional[str]=None,
        ):
            
            if role is None: raise ValueError("role must be provided")
            if content is None: raise ValueError("content must be provided")
            if token_count is None: raise ValueError("token_count must be provided")
            if tags is None: raise ValueError("tags must be provided")
            if content_vector is None: raise ValueError("content_vector must be provided")
            
            data_item = {
                "create_at": datetime.now().timestamp(),
                "id": str(uuid.uuid4()),
                "role": role,
                "content": content,
                "token_count": token_count,
                "tags": tags,
                "content_vector": content_vector
            }
            return data_item

        def item_knowledge_index_schema(
            title: Optional[float]=None,
            title_vector: Optional[str]=None,
            content: Optional[str]=None,
            content_vector: Optional[str]=None,
            source: Optional[str]=None,
            tags: Optional[str]=None
        ):
        
            if title is None: raise ValueError("title must be provided")
            if title_vector is None: raise ValueError("title_vector must be provided")
            if content is None: raise ValueError("content must be provided")
            if content_vector is None: raise ValueError("content_vector must be provided")
            if source is None: raise ValueError("source must be provided")
            if tags is None: raise ValueError("tags must be provided")
            
            data_item = {
                "create_at": datetime.now().timestamp(),
                "id": str(uuid.uuid4()),
                "title": title,
                "title_vector": title_vector,
                "content": content,
                "content_vector": content_vector,
                "source": source,
                "tags": tags
            }

            return data_item
    
        # Set memory for agent
        self.chat_memory=GeneralData(
            storage_name="chat_memory",
            storage_type=self.chat_memory_storage_type,
            storage_params=self.chat_memory_storage_params,
            create_data_item_func=item_chat_index_schema,
            log_name=session_log_name,
            log_path=f'{session_log_path}/storages',
            enable_log_file=self.enable_log_file,
            enable_log_stream=self.enable_log_stream,
            *args, **kwargs
        )
        
        # Set data_metadata for agent
        self.knowledge_memory=GeneralData(
            storage_name="knowledge_memory",
            storage_type=self.knowledge_memory_storage_type,
            storage_params=self.knowledge_memory_storage_params,
            create_data_item_func=item_knowledge_index_schema,
            log_name=session_log_name,
            log_path=f'{session_log_path}/storages',
            enable_log_file=self.enable_log_file,
            enable_log_stream=self.enable_log_stream,
            *args, **kwargs
        )
        
    def knowledge_str_format(self, knowledge):
        str_knowledge = ''
        for item in knowledge:
            str_knowledge += f'{item["content"]}\nsource: {item["source"]}\n'
        return str_knowledge

    async def query_llm(self, 
            query: Optional[str] = None
        ):
        
        lt_knowledge_mem=[]
        st_chat_messages=[]
        lt_chat_messages=[]

        # Creates embedding vector from user query
        response, status = await self.ai_service.i_execute(
            action=AIServices.OpenAI.Action.Embeddings.CREATE,
            model=AIServices.OpenAI.Feature.Embeddings.Model.LARGE_V3,
            input=query
        )
        query_embedding = response.result
    
        # save query to chat_memory
        await self.chat_memory.add_data(
            # user_id=self.agent_id,
            role='user',
            content=query,
            content_vector=query_embedding,
            token_count=count_tokens_from_text(query,AIServices.OpenAI.Feature.LLM.Model.Text.GPT_4_1106_PREVIEW),
            tags=""
        )

        # Get Chat memory and knowledge 
        #######################################################################
        
        # Get long term knowledge (Static Knowledge)
        lt_knowledge_mem, status = await self.knowledge_memory.get_data(
            k_top=self.k_top_knowledge
        )
        #print(f'lt_knowledge_mem: {lt_knowledge_mem}')
        
        # Get short term chat memory 
        st_chat_mem, status = await self.chat_memory.get_data(
            k_top=self.k_top_chat
        )
        #print(f'st_chat_mem: {st_chat_mem}')

        st_chat_messages = format_chat_messages_responses(st_chat_mem)
        #print(f'st_chat_messages: {st_chat_messages}')

        # Get long term chat memory
        if (len(st_chat_mem) >= self.k_top_chat):
            lt_chat_mem, status = await self.chat_memory.get_data(
                # prefix=self.agent_id,
                # query_embedding=query_embedding,
                n=self.k_top_chat,
                # filter_fields=[
                #     # Filter by user_id tag
                #     {
                #         "field_name": "user_id",
                #         "value": self.agent_id,
                #         "type": "tag"
                #     }
                # ]
            )
            lt_chat_messages = format_chat_messages_responses(lt_chat_mem)
            
        # print(f'lt_knowledge_mem: {lt_knowledge_mem}')
        # print(f'st_chat_messages: {st_chat_messages}')
        # print(f'lt_chat_messages: {lt_chat_messages}')
              
        # Make the llm messages format
        #######################################################################
        # Prefix system prompt
        llm_messages = [{"role": "system","content": SYSTEM_PROMPT_PREFIX}]  
        
        # Add long term knowledge
        llm_messages += [{"role": "user","content": KNOWLEDGE_LONGTERM_PROMPT}]  
        llm_messages += [{"role": "user","content": self.knowledge_str_format(lt_knowledge_mem)}]
        
        # Add long term chat memory
        llm_messages += [{"role": "user","content": CHAT_MEMORY_LONGTERM_PROMPT}]  
        llm_messages += lt_chat_messages
        
        # Add short term chat memory
        llm_messages += [{"role": "user","content": CHAT_SHORTERM_PROMPT}]  
        llm_messages += st_chat_messages
        
        # Suffix system prompt
        llm_messages += [{"role": "user","content": USER_PROMPT_SUFFIX}] 
        
        self.log.info(f'llm_messages: {llm_messages}')
        
        # Execute llm query
        #######################################################################
        assistant_response, status = await self.ai_service.i_execute(
            action=AIServices.OpenAI.Action.Chat.CREATE,
            model=AIServices.OpenAI.Feature.LLM.Model.Text.GPT_4_1106_PREVIEW,
            user_message=query,
            prefix_messages=llm_messages,
            stream=True,
            max_tokens=500,
            callback=print_chunk_async
        )        
        assistant_text = assistant_response.result[0]
    
        # Creates embedding vector from user query
        response, status = await self.ai_service.i_execute(
            action=AIServices.OpenAI.Action.Embeddings.CREATE,
            model=AIServices.OpenAI.Feature.Embeddings.Model.LARGE_V3,
            input=assistant_text,
        )
        assistant_embedding = response.result
        
        # save response to agent_memory
        #######################################################################
        await self.chat_memory.add_data(
            # user_id=self.agent_id,
            role='assistant',
            content=assistant_text,
            content_vector=assistant_embedding,
            token_count=count_tokens_from_text(query,AIServices.OpenAI.Feature.LLM.Model.Text.GPT_4_1106_PREVIEW),
            tags=""
        )
        
        # End of your functionality      
        return assistant_text
    
    async def core_functionality(self, 
        query: Optional[str] = None,
        user_id: Optional[str] = None,
        session_log_name: Optional[str] = None, 
        session_log_path: Optional[str] = None):
        
        # define your functionality here
        self.log.info(f'Agent: {self.name} is running...')
        self.log.info(f'User query: {query}')
        
        # Use the determined model type and name for agent_memory
        assistant_response = await self.query_llm(query)

        # End of your functionality
        self.log.info(f"Assistant: {assistant_response}")

        assistant_response=''
        return assistant_response