SYSTEM_PROMPT_PREFIX = "You are AI assistant and use your [Knowledge] to response the user when you dont have enough information about the query. You can also use [Chat Memory] to have the history of your interact with user"

KNOWLEDGE_LONGTERM_PROMPT="[knowledge] the following is the knowledge that you have."

CHAT_MEMORY_LONGTERM_PROMPT="You can use [knowledge] to search information to response the user.[chat memory] the following is the chat memory that you have."

CHAT_SHORTERM_PROMPT="Before was the history chat from the user. You can use history chat from the user to response the user. The user ask you:"

USER_PROMPT_SUFFIX = "Before the user ask you.Think step by step and response to the user. You can use [knowledge] and the [Chat Memory] to get feedback. What do you response?"