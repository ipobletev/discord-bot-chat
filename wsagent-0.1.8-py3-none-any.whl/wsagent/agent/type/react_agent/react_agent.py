# import asyncio
# from datetime import datetime
# import json
# import logging
# import traceback
# from typing import List, Optional, cast
# import uuid
# from wsagent.agent.base import Agent
# from wsagent.agent.type.react_agent.prompt import FINAL_ANSWER_INSTRUCTIONS, SELECT_TOOL_INSTRUCTIONS, SYSTEM_MESSAGE, THINK_INSTRUCTIONS
# from wsagent.ai_services.ai_services_interface import AIServicesInterface
# from wsagent.ai_services.services.openai.utils.count import count_tokens_from_text
# from wsagent import AIServices
# from wsagent.data_format.type import GeneralData
# from wsagent.storages.storages import StorageType
# from wsagent.tools.schemas.tool_response import ToolResponse
# from wsagent.tools.tools_types import ToolsTypes

# class ReactAgent(Agent):
#     def __init__(self, 
#         name: Optional[str] = None,
#         api_key: Optional[str] = None,
#         memory_storage_type: Optional[type] = None,
#         memory_storage_params: Optional[dict] = None,
#         # App parameters
#         tools: Optional[List] = None,
#         max_iterations: Optional[int] = None,
#         use_all_tools: Optional[bool] = False,
#         # logging parameters
#         log_path: Optional[str] = None,
#         enable_log_file: Optional[bool]=False,
#         enable_log_stream: Optional[bool]=False,
#         *args, **kwargs
#         ):
        
#         agent_name='ReactAgent'
#         if log_path is None: log_path=f'.logs/{datetime.now().strftime("%Y-%m-%d_%H-%M-%S")}/{agent_name}'
#         if tools is None: tools = []
#         if max_iterations is None: max_iterations = 5
#         if memory_storage_type is None: memory_storage_type = StorageType.Storage.LocalRam
        
#         # User parameters
#         self.max_iterations = max_iterations

#         self.memory_storage_type=memory_storage_type
#         self.memory_storage_params=memory_storage_params
#         self.use_all_tools=use_all_tools
        
#         super().__init__(
#             name=agent_name,
#             type_name='react_agent',
#             description='React agent that can use tools to act on the user request.', 
#             tools=tools,
#             api_key=api_key,
#             log_name=name,
#             log_path=log_path,
#             enable_log_file=enable_log_file,
#             enable_log_stream=enable_log_stream,
#             *args, **kwargs
#         )
        
#         if self.use_all_tools:
#             self.tools=ToolsTypes.get_all_tools()
        
#         # Persistent storage for LocalRam
#         if memory_storage_type == StorageType.Storage.LocalRam:
#             self.storage_memory=[]
#             if self.memory_storage_params is None:
#                 self.memory_storage_params={}
#             self.memory_storage_params['external_ram_storage']=self.storage_memory
            
#     def setup_request_services(self,
#         session_log_path: Optional[str]=None,
#         session_log_name: Optional[str]=None,
#     *args, **kwargs):

#         def create_data_item_for_memory( 
#             role: Optional[str]=None,   
#             content: Optional[str]=None,  
#             token_count: Optional[int]=None,
#             embedding: Optional[list]=None
#         ):
            
#             if role is None: raise ValueError("role must be provided")
#             if content is None: raise ValueError("content must be provided")
#             if token_count is None: raise ValueError("token_count must be provided")
            
#             memory_item = {
#                 "create_at": datetime.now().timestamp(),
#                 "id": str(uuid.uuid4()),
#                 "role": role,
#                 "content": content,
#                 "token_count": token_count,
#                 "embedding": embedding
#             }
#             return memory_item
        
#         # Set memory for agent
#         self.memory=GeneralData(
#             storage_name="agent_memory",
#             storage_type=self.memory_storage_type,
#             storage_params=self.memory_storage_params,
#             create_data_item_func=create_data_item_for_memory,
#             log_name=session_log_name,
#             log_path=f'{session_log_path}/storages',
#             enable_log_file=self.enable_log_file,
#             enable_log_stream=self.enable_log_stream,
#             *args, **kwargs
#         )
    
#     @staticmethod
#     async def think(
#         log: Optional[logging.Logger] = None,
#         ai_service: Optional[AIServicesInterface] = None,
#         query: Optional[str] = None,
#         str_tools: Optional[List] = None,
#         scratchpad: Optional[str] = None
#     ):
#         if ai_service is None: raise ValueError("ai_service must be provided")
#         if query is None: raise ValueError("query must be provided")
#         if scratchpad is None: raise ValueError("scratchpad must be provided")
#         if log is None: log=logging.getLogger(__name__)

#         # Make prompt
#         tool_final_answer_schema = {"name": "final_answer", "description": "Use this function when you have all necessary information to resolve the Goal or no additional tools are required.", "parameters": {"type": "object", "properties": {}, "required": []}}
        
#         messages=[
#             {"role": "system", "content": SYSTEM_MESSAGE},
#             {"role": "user", "content": f"[GOAL]\n{query}\n\n"},
#             {"role": "user", "content": f"[SCRATCHPAD]\n{scratchpad}\n\n"},
#             {"role": "user", "content": f"[TOOLS]\n{str_tools}\n{json.dumps(tool_final_answer_schema)}\n\n"},
#             {"role": "user", "content": THINK_INSTRUCTIONS},
#             {"role": "user", "content": "Thought:"}
#         ]
        
#         log.info(f"think_messages: {messages}")
        
#         # Use the determined model type and name for llm
#         chat_response, status = await ai_service.i_execute(
#             action=AIServices.OpenAI.Action.Chat.CREATE,
#             model=AIServices.OpenAI.Feature.LLM.Model.Vision.GPT_4_TURBO,
#             messages=messages,
#             max_tokens=500,
#             stop=["Action:", "Final Answer:"],
#             stream=True
#         )

#         log.info(f"Thought: {chat_response.result[0]}")

#         return chat_response.result[0]

#     @staticmethod
#     async def select_tool(
#         log: Optional[logging.Logger] = None,
#         ai_service: Optional[AIServicesInterface] = None,
#         tools_enums: Optional[List] = None,
#         indications: Optional[str] = None              
#     ):
        
#         if log is None: log=logging.getLogger(__name__)
#         if ai_service is None: raise ValueError("ai_service must be provided")
#         if tools_enums is None: raise ValueError("tools_enums must be provided")
#         if indications is None: raise ValueError("indications must be provided")

#         log.info(f"Selecting tool...")

#         tools=[]
#         for tool_enum in tools_enums:
#             tool_instance = tool_enum.value()
#             tools.append(tool_instance.get_schema())
#         tool_final_answer_schema = {"type": "function", "function": {"name": "final_answer", "description": "Use this function when you have all necessary information to resolve the Goal or no additional tools are required.", "parameters": {"type": "object", "properties": {}, "required": []}}} 
#         tools.append(tool_final_answer_schema)

#         log.info(f"tools: {tools}")
        
#         # Make prompt
#         messages=[
#             {"role": "user", "content": f"{indications}"},
#             {"role": "user", "content": f"Before was the indication and context to choose the next tool to use. Select the tool to use."},
#         ]
        
#         log.info(f"select_tool_messages: {messages}")

#         chat_response, status = await ai_service.i_execute(
#             action=AIServices.OpenAI.Action.Chat.CREATE,
#             model=AIServices.OpenAI.Feature.LLM.Model.Vision.GPT_4_TURBO,
#             messages=messages,
#             stream=False,
#             tool_choice='auto',
#             tools=tools
#         )
#         # bad tools request, bad prompting response
#         if chat_response.result == []:
#             return f"ERROR: Failed to select tool. No tool was selected. Try again with the same tool request."
        
#         log.info(f"Selected Tool: {chat_response.result[0]}")

#         return chat_response.result[0]

#     @staticmethod
#     async def act(
#         log: Optional[logging.Logger] = None,
#         input_json: Optional[dict] = None,
#         tools_enums: Optional[List] = None,
#         log_name: Optional[str] = None,
#         log_path: Optional[str] = None,
#         enable_log_file: Optional[bool] = False,
#     ):

#         func_name = input_json.get("tool_name", "")
#         if func_name == None:  return "ERROR: Unable to parse tool function from action input."
#         args_dict = input_json.get("tool_input", {})
#         if args_dict == None: return "ERROR: Unable to parse tool arguments from action input."

#         if isinstance(args_dict, str):
#             args_dict = json.loads(args_dict)

#         tool_instance = None
#         for tool_enum in tools_enums:
#             temp_instance = tool_enum.value()
#             if temp_instance.name == func_name:
#                 tool_instance = tool_enum.value(
#                     log_name=log_name,
#                     log_path=log_path,
#                     enable_log_file=enable_log_file,
#                 )
#                 break
#         if not tool_instance:
#             return f"ERROR: No tool found with func_name '{func_name}'"

#         try:
#             # Use asyncio.gather to execute the async function
#             result = await asyncio.gather(tool_instance.execute(**args_dict))
#             tool_response = cast(ToolResponse, result[0])
#             result_string = tool_response.result.get("string_llm_rep",None)
#             return result_string
#         except Exception as e:
#             log.error(traceback.format_exc())
#             return f"ERROR: Failed executing {func_name}: {e}"

#     @staticmethod
#     async def final_answer(
#         log: Optional[logging.Logger] = None,
#         query: Optional[str] = None,
#         ai_service: Optional[AIServicesInterface] = None,
#         relevant_memories: Optional[str] = None,
#         scratchpad: Optional[str] = None     
#     ):

#         log.info(f"Final Answer...")

#         # Make prompt
#         messages=[
#             {"role": "system", "content": SYSTEM_MESSAGE},
#             {"role": "user", "content": f"[HISTORY]\nHere is the conversation history between you and the user:\n{relevant_memories}\n\n"},
#             {"role": "user", "content": f"[GOAL]\n{query}\n\n"},
#             {"role": "user", "content": f"[SCRATCHPAD]\n{scratchpad}\n\n"},
#             {"role": "user", "content": FINAL_ANSWER_INSTRUCTIONS}
#         ]
        
#         log.info(f"final_answer_messages: {messages}")
        
#         chat_response, status = await ai_service.i_execute(
#             action=AIServices.OpenAI.Action.Chat.CREATE,
#             model=AIServices.OpenAI.Feature.LLM.Model.Vision.GPT_4_TURBO,
#             messages=messages,
#             stream=False
#         )
#         log.info(f"Final Answer: {chat_response.result[0]}")
#         return chat_response.result[0]

#     async def process_query_get_memory(self,
#         query: Optional[str] = None,
#     ):
#         ## Process Query
#         #Get embedding for query
#         embedding_response, status = await self.ai_service.i_execute(
#             action=AIServices.OpenAI.Action.Embeddings.CREATE,
#             model=AIServices.OpenAI.Feature.Embeddings.Model.LARGE_V3,
#             input=query
#         )
#         # Add to memory the user query
#         await self.memory.add_data(
#             role="user", 
#             content=query,
#             token_count=count_tokens_from_text(input_txt=query, model=AIServices.OpenAI.Feature.LLM.Model.Text.GPT_3_5_TURBO_1106),
#             embedding=embedding_response.result
#         )

#         # Get the relevant memories based by the user query
#         relevant_memories, status = await self.memory.get_data()
        
#         return relevant_memories

#     async def process_assistant_response(self,
#         final_answer: Optional[str] = None,
#     ):
#         #Get embedding for query
#         embedding_response, status = await self.ai_service.i_execute(
#             action=AIServices.OpenAI.Action.Embeddings.CREATE,
#             model=AIServices.OpenAI.Feature.Embeddings.Model.ADA_V2,
#             input=final_answer
#         )
        
#         # Add to memory the final answer
#         await self.memory.add_data(
#             role="assistant", 
#             content=final_answer,
#             token_count=count_tokens_from_text(input_txt=final_answer, model=AIServices.OpenAI.Feature.LLM.Model.Text.GPT_3_5_TURBO_1106),
#             embedding=embedding_response.result
#         )

#     async def core_functionality(self, 
#         query: Optional[str] = None,
#         session_log_name: Optional[str] = None,
#         session_log_path: Optional[str] = None):
        
#         # define your functionality here
#         self.log.info(f'Agent: {self.name} is running...')
#         self.log.info(f'User query: {query}')

#         # # Start of your functionality
#         scratchpad = "Goal: " + query
#         final_answer = ""
        
#         relevant_memories = await self.process_query_get_memory(query=query)
#         # Start the iteration and agent processing
#         for iteration in range(self.max_iterations):
            
#             # Think about the the tool to use
#             self.log.info(f"Thinking...")
#             thought = await self.think(log=self.log,
#                 ai_service=self.ai_service,
#                 query=query,
#                 str_tools=self.get_tools_schema_str(),
#                 scratchpad=scratchpad
#             )
#             print(f"\n\n# STEP {iteration+1}")
#             print(f"- Thought: {thought}")
#             scratchpad += f"\n# STEP {iteration+1}"
#             scratchpad += f"\n- Thought: {thought}"
            
#             # Select the tool to use
#             chosen_tool = await self.select_tool(log=self.log,
#                 ai_service=self.ai_service,
#                 tools_enums=self.tools,
#                 indications=thought
#             )
#             print(f"- Action: {chosen_tool}")
#             scratchpad += f"\n- Action: {chosen_tool}"
            
#             # Action the tool
#             if chosen_tool is None or chosen_tool.get("tool_name","") == 'final_answer':
#                 break
            
#             observation = await self.act(log=self.log,
#                 input_json=chosen_tool,
#                 tools_enums=self.tools,
#                 log_name=session_log_name,
#                 log_path=session_log_path,
#                 enable_log_file=self.enable_log_file
#             )
#             self.log.info(f"Observation: {observation}")
#             scratchpad += f"\n- Observation: The tool {chosen_tool} was execute and the result was {observation}"
#             print(f"- Observation: {observation}")

#         final_answer = await self.final_answer(log=self.log,
#             query=query,
#             ai_service=self.ai_service,
#             relevant_memories=relevant_memories,
#             scratchpad=scratchpad
#         )
#         scratchpad += f"\n\nFinal Answer: {final_answer}"
#         print(f"\n\nFinal Answer: {final_answer}")
        
#         await self.process_assistant_response(final_answer=final_answer)

#         return final_answer