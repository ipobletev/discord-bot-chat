from abc import ABC, abstractmethod
from datetime import datetime
import os
from typing import Dict, List, Optional, cast
from enum import Enum
from time import perf_counter
import uuid
from wsagent.ai_services.ai_services_interface import AIServicesInterface
from wsagent.tools.base import Tool
from wsagent.utils.logs import PrintAndLog
import traceback

class AgentStatus(Enum):
    IDLE = "idle"
    WORKING = "working"

class Agent(ABC):
    """Base class for all agents"""
    
    def __init__(
        self,
        name: Optional[str] = None,
        type_name: Optional[str] = None,
        description: Optional[str] = None,
        session_id: Optional[str] = None,
        tools: Optional[List] = None,
        api_key: Optional[str] = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: bool=False,
        enable_log_stream: bool=False,
        *args, **kwargs
    ) -> None:
        
        if session_id is None: session_id=str(uuid.uuid4())[-8:]
        
        self._name = name
        self._type_name = type_name
        self._description = description
        self._session_id = session_id
        self._status = AgentStatus.IDLE
        self.api_key = api_key
        
        self.tools = tools if tools is not None else []
        self.tools_loggers = []
        
        self.base_kwargs = kwargs
        self.base_args = args
        
        self.log_name = f'{session_id}.{log_name}'
        self.log_path = f'{log_path}/{session_id}'
        self.enable_log_file=enable_log_file
        self.enable_log_stream=enable_log_stream

        # Set up all loggers for agent
        PrintAndLog(
            log_name=self.log_name,
            log_path=self.log_path,
            enable_log_file=self.enable_log_file,
            enable_log_stream=self.enable_log_stream
        ).logger

    @property
    def name(self) -> Optional[str]:
        """Gets the agent's name."""
        return self._name

    @property   
    def type_name(self) -> Optional[str]:
        """Gets the agent's type name."""
        return self._type_name
    
    @property
    def session_id(self) -> Optional[str]:
        """Gets the agent's description."""
        return self._session_id
    
    @property
    def agent_description(self) -> Optional[str]:
        """Gets the agent's description."""
        return self._description
    
    @property   
    def status(self) -> AgentStatus:
        """Gets the agent's status."""
        return self._status

    def get_tools_schema(self) -> List:
        """
        Retrieves a list of schemas for the tools available to the agent.
        Returns:
            list: A list of tool schemas.
        """
        tools=[]
        for tool_enum in self.tools:
            temp_instance = tool_enum.value()
            if hasattr(temp_instance, "get_schema"):
                tools.append(temp_instance.get_schema())
        return tools

    def get_tools_schema_str(self) -> str:
        """
        Retrieves a string representation of the tools' schemas available to the agent.
        Returns:
            str: A string that concatenates all tool schemas separated by newlines.
        """
        str_tools = ''
        for tool_enum in self.tools:
            temp_instance = tool_enum.value()
            if hasattr(temp_instance, "get_schema"):
                str_tools+= f"{temp_instance.get_schema()}\n" 
        return str_tools
    
    def get_inspect(self) -> Dict:
        """
        Retrieves an inspection dictionary for the agent.
        Returns:
            dict: A dictionary containing the id, agent_description, and tools' schemas.
        """
        return {
            "id": self.session_id,
            "agent_name": self.name,
            "agent_type": self.type_name,
            "agent_description": self.agent_description,
            "tools": self.get_tools_schema()
        }
        
    async def run(self, 
        query: Optional[str] = None, 
    ) -> Optional[str]:
        
        """
        Executes the given goal in the provided context.
        Args:
            goal (str): The goal the agent is set to achieve.
        Returns:
            The result of the core functionality after it's been executed.
        """
        self._status = AgentStatus.WORKING
        start_time = perf_counter()  

        session_id = str(uuid.uuid4())  # Creating a unique ID for each interaction
        datetime_part = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
        session_log_path = os.path.join(self.log_path,f"{datetime_part}-{session_id[-8:]}")
        session_log_name = f"{self.session_id}.{self.name}.{session_id[-8:]}"

        # Set up log request details
        self.log = PrintAndLog(
                log_name=f'{session_log_name}',
                log_path=session_log_path,
                enable_log_file=self.enable_log_file,
                enable_log_stream=self.enable_log_stream
            ).logger

        # Set up agent log request
        self.log = PrintAndLog(
                log_name=f'{session_log_name}.agent',
                log_path=session_log_path,
                enable_log_file=self.enable_log_file,
                enable_log_stream=self.enable_log_stream
            ).logger
        
        # Set up for user request services
        self.setup_request_services(
            session_id=self.session_id,
            session_log_path=session_log_path,
            session_log_name=session_log_name
        )
        result=None
        try:
            result = await self.core_functionality(
                query=query,
                session_id=self.session_id,
                session_log_path=session_log_path,
                session_log_name=session_log_name,
            )
        except Exception as e:
            self.log.error(traceback.format_exc())
            self.log.error(f"Error executing goal: {e}")
            raise e
        finally:
            time_taken = perf_counter() - start_time
            self._status = AgentStatus.IDLE

            minutes, seconds = divmod(time_taken, 60)
            self.log.info(
                f"Time Spent: {int(minutes)} minutes and {seconds:.2f} seconds"
            )

        return result
    
    @abstractmethod    
    async def core_functionality(self,
        query: Optional[str] = None,
        session_id: Optional[str] = None,
        session_log_name: Optional[str] = None,
        session_log_path: Optional[str] = None
    ) -> Optional[str]:
        """
        (Abstract async method) Execute the core algorithm of the agent.
        Must be overridden by implementations of this class.
        """
        pass
    
    @abstractmethod    
    async def setup_request_services(self,
        session_id: Optional[str] = None,
        session_log_name: Optional[str]=None,
        session_log_path: Optional[str]=None):
        """
        (Abstract async method) Execute the setup services of the agent.
        Must be overridden by implementations of this class.
        """
        pass