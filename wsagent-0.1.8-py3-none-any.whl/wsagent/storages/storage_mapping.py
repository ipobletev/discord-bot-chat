from typing import Dict, Type
from wsagent.storages.base import StorageBase
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.redis import RedisDB
from wsagent.storages.type.local_ram.local_ram import LocalRam
from wsagent.storages.type.local_json.local_json import LocalJson

class StorageRegistry:
    _registry: Dict[Storage.Type, Type[StorageBase]] = {}
    
    @classmethod
    def register_storage(cls, storage_type: Storage.Type, storage_class: Type[StorageBase]) -> None:
        if storage_type in cls._registry:
            raise ValueError(f"Storage type '{storage_type}' is already registered.")
        cls._registry[storage_type] = storage_class

    @classmethod
    def get_storage(cls, storage_type: Storage.Type) -> Type[StorageBase]:
        if storage_type not in cls._registry:
            raise ValueError(f"Storage type '{storage_type}' is not registered.")
        return cls._registry[storage_type]
    
StorageRegistry.register_storage(Storage.Type.REDIS, RedisDB)
StorageRegistry.register_storage(Storage.Type.LOCAL_JSON, LocalJson)
StorageRegistry.register_storage(Storage.Type.LOCAL_RAM, LocalRam)