from enum import Enum, auto

# Master Storage definitions
class Storage:
    
    class Type(Enum):
        REDIS = auto()
        """
        ### Brief

        Redis storage type.
        
        ### Parameters of storage_params
        - "host": "str: Redis host to connect."
        - "password": "str: Redis password to connect."
        - "port": "int: Redis port to connect."
        - "db": "int: Redis db to connect."
        - "storage_name": "str: Index name to create the storage, used in log and internal names. "
        - "storage_ident": "str: Index name to create the storage. "
        - "index_schema": "list: Redis Index schema to create the index."
        - "index_schema_config": "dict: Index schema configuration."
        - "prefix": "list: Prefix tag of default data."
        - "use_id_from_data": "bool: If True, use the data to get the key id in field "key_id_field" . If False, use a random uuid to generate a key name id."
        - "key_id_field": "str or None: Use with 'use_id_from_data' to get a uuid name in insert methods to name the key of data."
        
        ### Algorithm parameters to use:
        ```

        storage_params={
            # Redis connection parameters
            "host": "localhost",
            "password": "",
            "port": 6379,
            "db": 0,
            # Redis index configuration
            "storage_name": "redis_idx",
            "storage_ident": "redis_idx",
            "index_schema": [RedisSchema], # if not use it is auto generate schema by storage_struc param
            "index_schema_config": {
                "vector_dim": 3072,
                "vector_distance_metric": "COSINE",
                "vector_type": "FLOAT32"
            },
            "prefix": ['prefix_name'],
            # Redis key uuid generation
            "use_id_from_data": False,
            "key_id_field": None
        }
        ```
        """
        LOCAL_JSON = auto()
        
        """
        ### Brief

        Json storage type.
        
        ### Parameters of storage_params
        - "storage_name": "str: storage name to use with autogen unique_key and log folders."
        - "storage_ident": "Identity str url_path to create the json file storage"
        
        ### Algorithm parameters to use:
        ```    
        storage_params={
            "storage_name": "json_storage",
            "storage_ident": ".data/local_json/data.json",
        }
        ```
        """
        LOCAL_RAM = auto()
        
        """
        ### Brief

        Ram storage type.
        
        ### Parameters of storage_params
        - "storage_name": "str: storage name to use with autogen unique_key and log folders."
        - "storage_ident": "Identity list to create the external ram storage for multi user persistant data."
        
        ### Algorithm parameters to use:
        ```
        local_ram_storage=[ ]
        
        storage_params={
            "storage_name": "json_storage",
            "storage_ident": ".data/local_json/data.json",
        }
        ```
        """

    class Algorithm:
        class Search(Enum):
            RAW_SEARCH = auto()
            """
            ### Brief

            Raw search specific by storage type.
            
            ### Parameters of storage_params
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "others": "Any: Other parameters to use in the search by Storage specifics."
            """
            
            GET_SPECIFIC_DATA = auto()
            """
            ### Brief

            Get especific data from the fiel 'data_field' storage.
            
            ### Parameters of storage_params
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "id_field": " Get the Id in this field. This not is required in DBs like redis."
            - "id_value": "str: Id of the data to get."
            - "return_fields": "List[str]: of fields to return."
            
            ### Algorithm parameters to use:
            ```
            algorithm_params = {
                "storage_ident": "redis_idx",
                "id_field": " Get the data in this field.",
                "id_value": " Get the data with this value." 
                "return_fields": ['email','age'],
            }
            ```
            """
            
            LAST_ELEMENTS = auto()
            """
            ### Brief

            Search and sort element in numeric field "sort_by". 
            
            ### Parameters of storage_params
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "sort_by": "str: Field to sort the results."
            - "sort_order_asc": "bool: Order of the sort. False for descending, True for ascending."
            
            ### Algorithm parameters to use:
            ```
            algorithm_params = {
                "storage_ident": "redis_idx",
                "k_top": 5,
                "return_fields": ['email','age'],
                "sort_by": "age",
                "sort_order_asc": True
            }
            ```
            """
            
            VECTOR_SEARCH = auto()
            """
            ### Brief

            Vector search element with a vector_value in vector_field.
            
            ### Parameters of storage_params
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "input_query": "str: Text objetive to execute the vector search."
            - "vector_field": "str: Field to search the vector."
            
            ### Algorithm parameters to use:
            ```
            algorithm_params = {
                # "storage_ident": ".data/local_json/data.json"
                "k_top": 2,
                "return_fields": ['title','id','uuid', "timestamp", 'vector_score'],
                "vector_value": input_vector,
                "vector_field": "title_vector"
            }
            ```
            """
            
            HYBRID_SEARCH = auto()
            """
            ### Brief

            Hybrid search element with a vector and text search.
            
            ### Parameters of storage_params
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "vector_value": "List[float]: Vector to search in storage."
            - "vector_field": "str: Field to search the vector."
            - "text_search_value": "str: Text to search in storage."
            - "text_search_field": "str: Field to search the text."
            - "k_sim": "float: Weight of the similarity text. Redis Storage not use this parameter."
            - "k_sem": "float: Weight of the semantic vector. Redis Storage not use this parameter."
            
            ### Algorithm parameters to use:
            ```
            algorithm_params = {
                "storage_ident": "redis_idx",
                "k_top": 5,
                "return_fields": ['email','age'],
                "vector_value": [0,0,0,0,0,0,0,0,0,0,...],
                "vector_field": "content_vector",
                "text_search_value": "John",
                "text_search_field": "name",
                "k_sim": 0.3,
                "k_sem": 0.7
            }
            ```
            """
            
        class Insert(Enum):
            DEFAULT = auto()
            """
            ### Brief

            Insert data to the storage identity.
            
            ### Parameters
            
            - "unique_key": "Unique key to insert the data. Default is auto generate a unique key = f'{storage_name}:{uuid.uuid4()}'."
            - "data": "Dict data to insert."
            
            ### Algorithm parameters to use:
            #### Ram storage:
            ```
            algorithm_params = {
                "data": {"key": "value"}
            }
            ```
            #### Json storage:
            ```
            algorithm_params = {
                "unique_key": "json_storage:uuid",
                "data": {"key": "value"}
            }
            ```
            #### Redis storage:
            ```
            algorithm_params = {
                "data": {"key": "value"}
            }
            ```
            """
            
        class Storage(Enum):
            CREATE_STORAGE = auto()
            """
            ### Brief

            Create a storage identity according to the storage type (table, index or file).
            
            ### Parameters
            
            - "storage_ident": "Identity to create the storage. It could be a path (for JSON), an index (for Redis), or a table (for SQL)."
            
            ### Algorithm parameters to use:
            #### Ram storage:
            
            Storage actions are not supported by LocalRam storage.
            
            #### Json storage:
            ```
            algorithm_params = {
                "storage_ident": ".data/data.json"
            }
            ```
            #### Redis storage:
            ```
            algorithm_params = {
                "storage_ident": "your_index_name"
            }
            ```
            """
            
            CHECK_STORAGE = auto()
            """
            ### Brief

            Check if exist a storage identity according to the storage type (table, index or file).
            
            ### Parameters
            
            - "storage_ident": "Identity to check the storage file."
            
            ### Algorithm parameters to use:
            #### Ram storage:
            
            Storage actions are not supported by LocalRam storage.
            
            #### Json storage:
            ```
            algorithm_params = {
                "storage_ident": ".data/data.json"
            }
            ```
            #### Redis storage:
            ```
            algorithm_params = {
                "storage_ident": "your_index_name"
            }
            ```
            """
            
    @classmethod
    def list_type_storages(cls):
        return [action.name for action in cls.Type]
    
    @classmethod
    def list_search_algorithms(cls):
        return [action.name for action in cls.Algorithm.Search]

    @classmethod
    def list_insert_algorithms(cls):
        return [action.name for action in cls.Algorithm.Insert]

    @classmethod
    def list_storage_algorithms(cls):
        return [action.name for action in cls.Algorithm.Storage]