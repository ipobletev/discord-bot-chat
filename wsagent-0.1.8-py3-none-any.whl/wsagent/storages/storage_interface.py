from typing import Dict, Optional, Union
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.storages.storage_mapping import StorageRegistry
from wsagent.storages.storages_enum import Storage
from wsagent.storages.base import Storage, StorageBase
from wsagent.utils.validate_args import validate_required_args

class StorageInterface:
    
    """### StorageInterface
    A class that serves as an interface for various storage systems.

    The StorageInterface class provides a unified interface for interacting with different types of storage systems such as Redis, Local JSON, and Local RAM. It uses the StorageType enums to specify the type of storage and execute the appropriate actions.

    #### Attributes:
        - storage_type (Optional[StorageType]): The type of the storage system. Use the StorageType enums (e.g., StorageType.REDIS, StorageType.LOCAL_JSON, StorageType.LOCAL_RAM).
        - storage_params (Optional[Dict]): The parameters required for the specific storage type. Refer to the StorageType enum documentation for the required parameters for each storage type.
        - ai_service_params (Optional[Dict]): The parameters required for the AI service like api keys.
        - session_id (Optional[str]): The user ID associated with the storage.
        - log_name (Optional[str]): The name of the log file.
        - log_path (Optional[str]): The path where the log file is stored.
        - enable_log_file (bool): A flag to enable or disable logging to a file.
        - enable_log_stream (bool): A flag to enable or disable logging to a stream.

    #### Methods:
        - __init__: Initializes the StorageInterface with the specified parameters.
        
        - execute: Executes a specified algorithm with the provided parameters on the storage. The algorithm to be executed is determined by the Storage.Algorithm enums.
        
        - standalone_execute: A static method that allows executing an algorithm on a specified storage type without the need to initialize the StorageInterface. This method also uses the StorageType and Storage.Algorithm enums to specify the storage type and the algorithm to be executed.
    
    #### Example to use the StorageInterface class:
    ```
    async def main():
        
        storage = StorageInterface(
            # Storage parameters
            storage_type=StorageType.LOCAL_JSON,
            storage_params={
                "storage_name": "local_json",
                "storage_ident": "./data/local_json/data.json",
            },
            ai_service_params={
                "openai_api_key": OPENAI_API_KEY,
                "groq_api_key": GROQ_API_KEY,
                "anthropic_api_key": ANTHROPIC_API_KEY,
            },
            session_id="session_id",
            # Logging parameters
            log_name="log_name",
            log_path=".data/log_path",
            enable_log_file=True
        )

        insert_response = await storage.execute(
            algorithm=Storage.Algorithm.Insert.DEFAULT,
            algorithm_params={
                "data": {"key": "value"}
            }
        )

        print(insert_response.result)

        search_response  = await storage.execute(
            algorithm=Storage.Algorithm.Search.LAST_ELEMENTS,
            algorithm_params = {
                "k_top": 5
            }
        )

        print(search_response.result)

    asyncio.run(main())
    ```
    """
    @validate_required_args
    def __init__(self, 
        storage_type: Optional[Storage.Type] = None, 
        storage_params: Optional[Dict] = None,
        session_id: Optional[str] = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: bool = False,
        enable_log_stream: bool = False
    ) -> None:
        
        if storage_type is None: storage_type = Storage.Type.LOCAL_JSON
        
        if session_id:
            self.log_name = f'{log_name}.{session_id}.si'
            self.log_path = f'{log_path}/{session_id}/si'
        else:
            self.log_name=f'{log_name}.si'
            self.log_path=f'{log_path}/si'
            
        self.enable_log_file = enable_log_file
        self.enable_log_stream = enable_log_stream
        
        storage_class = StorageRegistry.get_storage(storage_type)
        self.storage: StorageBase = storage_class(
            storage_params=storage_params,
            session_id=None,
            log_name=self.log_name,
            log_path=self.log_path,
            enable_log_file=self.enable_log_file,
            enable_log_stream=self.enable_log_stream
        )

    @validate_required_args
    async def execute(self, 
        algorithm: Optional[Union[Storage.Algorithm.Insert,Storage.Algorithm.Search,Storage.Algorithm.Storage]] = None, 
        algorithm_params: Optional[Dict] = None
    ) -> StorageResponse:
        
        if algorithm is None: raise ValueError("algorithm must be provided.")
        if algorithm_params is None: ValueError("algorithm_params must be provided.")

        return await self.storage.execute(algorithm,algorithm_params)

    @staticmethod
    @validate_required_args
    async def standalone_execute(
        storage_params: Optional[Dict] = None,
        session_id: Optional[str] = None,
        # Storage parameters
        storage_type: Optional[Storage.Type] = None,
        algorithm: Optional[Union[Storage.Algorithm.Insert,Storage.Algorithm.Search,Storage.Algorithm.Storage]] = None, 
        algorithm_params: Optional[Dict] = None,
        # Logging parameters
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: bool = False,
        enable_log_stream: bool = False
    ) -> StorageResponse:
        
        if algorithm is None: raise ValueError("algorithm must be provided.")
        if algorithm_params is None: ValueError("algorithm_params must be provided.")

        # Get the storage class from the registry using the provided storage type.
        storage_class = StorageRegistry.get_storage(storage_type)

        # Create an instance of the storage class.
        storage_instance: StorageBase = storage_class(
            storage_params=storage_params,
            session_id=session_id,
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )

        # Execute the requested action on the storage instance.
        return await storage_instance.execute(algorithm, algorithm_params)