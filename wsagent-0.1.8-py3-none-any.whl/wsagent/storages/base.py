from datetime import datetime
from typing import Optional, Union
from abc import ABC, abstractmethod
import uuid
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.storages.storages_enum import Storage
from wsagent.utils.logs import PrintAndLog

class StorageBase(ABC):
    def __init__(self, 
        storage_service_name: Optional[str] = None,
        storage_params: Optional[dict] = None,
        session_id: Optional[str] = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ) -> None:
        
        if storage_params is None: storage_params={}
        
        storage_name = storage_params.get('storage_name', None)
        
        if storage_name is None: raise ValueError("storage_name must be provided")
        if storage_service_name is None: raise ValueError("storage_service_name must be provided")

        self.storage_name=storage_name
        self.storage_service_name=storage_service_name     
        self.storage_params=storage_params   
        self.session_id=session_id
        self.log_name=log_name
        self.log_path=log_path
        self.enable_log_file=enable_log_file
        self.enable_log_stream=enable_log_stream
    
    async def execute(self,
        algorithm: Optional[Union[Storage.Algorithm.Insert,Storage.Algorithm.Search,Storage.Algorithm.Storage]] = None, 
        algorithm_params: Optional[dict] = None
    ) -> StorageResponse:
        
        execution_id = str(uuid.uuid4())[:8]
        
        if self.session_id:
            log_name = f'{self.log_name}.{self.session_id}.{self.storage_service_name}.{execution_id}'
            log_path = f'{self.log_path}/{self.session_id}/{self.storage_service_name}/{datetime.now().strftime("%m-%d-%Y-%H-%M-%S")}-{execution_id}'
        else:
            log_name=f'{self.log_name}.{self.storage_service_name}.{execution_id}'
            log_path=f'{self.log_path}/{self.storage_service_name}/{datetime.now().strftime("%m-%d-%Y-%H-%M-%S")}-{execution_id}'
            
        self.log=PrintAndLog(
            log_name=log_name,
			log_path=log_path,
            enable_log_file=self.enable_log_file,
            enable_log_stream=self.enable_log_stream
        ).logger
    
        return await self.internal_execute(algorithm,algorithm_params)

    @abstractmethod
    async def internal_execute(self,
        action: Optional[Union[Storage.Algorithm.Insert,Storage.Algorithm.Search,Storage.Algorithm.Storage]] = None,
        action_params: Optional[dict] = None,
    ) -> StorageResponse:
        pass