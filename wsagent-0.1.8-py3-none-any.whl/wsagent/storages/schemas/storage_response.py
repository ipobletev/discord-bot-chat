from enum import Enum
import time
from typing import Any, Optional, Union
from wsagent.utils.validate_args import validate_required_args
from typing import Any, Optional, Union


class StorageResponse:
    @validate_required_args
    def __init__(self,
        result: Any,
        additional_data: Any,
        algorithm: Enum,
        algorithm_params: dict,
        init_timestamp: Optional[Union[float,int]] = None,
    ):
        
        self._algorithm=algorithm
        self._algorithm_params=algorithm_params
        self._init_timestamp=init_timestamp
        self._result=result
        self._additional_data=additional_data
        
        if algorithm is None: raise ValueError("algorithm must be provided")
        if algorithm_params is None: algorithm_params={}
        if init_timestamp is None: raise ValueError("init_timestamp is required")
        if result is None: raise ValueError("result is required")
        
        self._time_exec=time.time() - init_timestamp
    
    @property
    def result(self):
        return self._result
    
    @property
    def additional_data(self):
        return self._additional_data
    
    @property
    def algorithm(self):
        return self._algorithm
    
    @property
    def algorithm_params(self):
        return self._algorithm_params
    
    @property
    def init_timestamp(self):
        return self._init_timestamp
    
    @property
    def time_exec(self):
        return self._time_exec
    
    def to_json(self):
        def serialize(obj):
            if hasattr(obj, "to_dict"):
                return obj.to_dict()
            elif isinstance(obj, list):
                return [serialize(item) for item in obj]
            elif isinstance(obj, dict):
                return {key.lstrip('_'): serialize(value) for key, value in obj.items()}
            elif isinstance(obj, (int, float, str, bool, type(None))):  # check for basic types
                return obj
            else:
                return str(obj)  # default to string for any other types that are not recognized

        return {key.lstrip('_'): serialize(value) for key, value in self.__dict__.items()}