
from enum import Enum

class RedisDBEnums:
    
    class Scoring():
        
        class FullText(Enum):
            #https://redis.io/docs/interact/search-and-query/advanced-concepts/scoring/
            
            BM25            = "BM25"
            TFIDF           = "TFIDF"
            TFIDF_DOCNORM   = "TFIDF.DOCNORM"
            DISMAX          = "DISMAX"
            DOCSCORE        = "DOCSCORE"
            HAMMING         = "HAMMING"