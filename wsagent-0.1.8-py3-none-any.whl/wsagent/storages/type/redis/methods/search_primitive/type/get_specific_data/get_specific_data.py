from datetime import datetime
import logging
from typing import Optional
import redis
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.methods.redis_handle.redis_search.redis_search import redis_handle_search
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def get_specific_data(
    algorithm: Optional[Storage.Algorithm.Search] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
        
    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## algorithm_params
    storage_ident = algorithm_params.get('storage_ident', None)
    id_value = algorithm_params.get('id_value', None)
    ## storage_params
    storage_ident = algorithm_params.get('storage_ident', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident')
    
    # Check if all required parameters are provided
    if id_value is None: raise ValueError("id_value is required for search operation.")

    return await redis_handle_search(
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        storage_params=storage_params,
        log=log
    )