from datetime import datetime
import logging
from typing import List, Optional
import redis
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.methods.redis_handle.redis_search.redis_search import redis_handle_search
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def hydrid_search(
    algorithm: Optional[Storage.Algorithm.Search] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    
    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## algorithm_params
    storage_ident: str = algorithm_params.get('storage_ident', None)
    vector_value = algorithm_params.get('vector_value', None)
    vector_field = algorithm_params.get('vector_field', None)
    text_search_value = algorithm_params.get('text_search_value', None)
    text_search_field = algorithm_params.get('text_search_field', None)
    return_fields: List[str] = algorithm_params.get('return_fields', None)
    k_top = algorithm_params.get('k_top', None)
    # max_tokens = algorithm_params.get('max_tokens', None)
    # token_field = algorithm_params.get('token_field', None)
    ## storage_params
    storage_ident = algorithm_params.get('storage_ident', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident', None)
    
    # Check if all required parameters are provided
    if storage_ident is None: raise ValueError("storage_ident is required")
    if vector_value is None: raise ValueError("vector_value must be provided")
    if vector_field is None: raise ValueError("vector_field must be provided")
    if text_search_value is None: raise ValueError("text_search_value must be provided")
    if text_search_field is None: raise ValueError("text_search_field must be provided")
    if k_top is None: k_top = 5
    # if max_tokens is not None and token_field is None: raise ValueError('token_field is required')
        
    return await redis_handle_search(
        algorithm=algorithm,
        algorithm_params={
            'storage_ident': storage_ident,
            'vector_value': vector_value,
            'vector_field': vector_field,
            'text_search_value': text_search_value,
            'text_search_field': text_search_field,
            'return_fields': return_fields,
            'k_top': k_top
        },
        storage_params=storage_params,
        log=log
    )