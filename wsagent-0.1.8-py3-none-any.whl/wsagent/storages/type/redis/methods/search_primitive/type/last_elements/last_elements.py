import logging
from typing import List, Optional
import redis
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.methods.redis_handle.redis_search.redis_search import redis_handle_search
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def last_elements(
    algorithm: Optional[Storage.Algorithm.Search] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    
    # All parameters for this method
    ## algorithm_params
    storage_ident: str = algorithm_params.get('storage_ident', None)
    return_fields: List[str] = algorithm_params.get('return_fields', None)
    k_top = algorithm_params.get('k_top', None)
    sort_by: str = algorithm_params.get('sort_by', None)
    sort_order_asc: bool = algorithm_params.get('sort_order_asc', False)
    # max_tokens = algorithm_params.get('max_tokens', None)
    # token_field = algorithm_params.get('token_field', None)
    ## storage_params
    redis_client: redis.Redis = storage_params.get('redis_client', None)
    storage_ident = algorithm_params.get('storage_ident', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident', None)
    
    # Check if all required parameters are provided
    if redis_client is None: raise ValueError("Redis client is required.")
    if storage_ident is None: raise ValueError("storage_ident is required")
    if k_top is None: k_top = 5
    # if max_tokens is not None and token_field is None: raise ValueError('token_field is required')

    return await redis_handle_search(
        algorithm=algorithm,
        algorithm_params={
            'storage_ident': storage_ident,
            'text_search_value': "*",
            'return_fields': return_fields,
            'sort_by': sort_by,
            'sort_order_asc': sort_order_asc,
            'k_top': k_top
        },
        storage_params=storage_params,
        log=log
    )