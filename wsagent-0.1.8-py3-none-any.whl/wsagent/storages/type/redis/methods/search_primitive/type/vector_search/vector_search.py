import logging
from typing import List, Optional
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.methods.redis_handle.redis_search.redis_search import redis_handle_search
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def vector_search(
    algorithm: Optional[Storage.Algorithm.Search] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    storage_ident: str = algorithm_params.get('storage_ident', None)
    ## algorithm_params
    vector_field: str = algorithm_params.get('vector_field', None)
    vector_value: List[float] = algorithm_params.get('vector_value', None)
    return_fields: List[str] = algorithm_params.get('return_fields', None)
    k_top: int = algorithm_params.get('k_top', None)
    ## storage_params
    if storage_ident is None: storage_ident = storage_params.get('storage_ident', None)
    
    # Check if all required parameters are provided
    if storage_ident is None: raise ValueError("storage_ident is required")
    if k_top is None: k_top=5
    if vector_field is None: raise ValueError('vector_field is required')
    if vector_value is None: raise ValueError('vector_value is required') 

    return await redis_handle_search(
        algorithm=algorithm,
        algorithm_params={
            'storage_ident': storage_ident,
            'return_fields': return_fields,
            'vector_value': vector_value,
            'vector_field': vector_field,
            'k_top': k_top
        },
        storage_params=storage_params,
        log=log
    )