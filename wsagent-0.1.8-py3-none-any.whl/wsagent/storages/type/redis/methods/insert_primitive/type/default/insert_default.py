import logging
from typing import Optional
import uuid
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.methods.redis_handle.redis_insert.redis_insert import redis_handle_insert
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def insert_default(
    algorithm: Optional[Storage.Algorithm.Insert] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):

    # All parameters for this method
    ## algorithm
    data = algorithm_params.get('data',None)
    unique_key = algorithm_params.get('unique_key',None)
    ## storage_params
    storage_ident = algorithm_params.get('storage_ident',None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident',None)
    
    # Check if all required parameters are provided
    if data is None: raise ValueError("Data is required for insert operation.")
    if storage_ident is None: raise ValueError("Storage ident is required for insert operation.")
    if unique_key is None: unique_key = f'{storage_ident}:{uuid.uuid4()}'

    # Set field for framework compatibility
    data['unique_key'] = unique_key
        
    return await redis_handle_insert(
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        storage_params=storage_params,
        log=log
    )