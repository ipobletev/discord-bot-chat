# Dispatch dictionary LocalRam
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.methods.search_primitive.type.get_specific_data.get_specific_data import get_specific_data
from wsagent.storages.type.redis.methods.redis_handle.redis_search.redis_search import redis_handle_search
from wsagent.storages.type.redis.methods.search_primitive.type.last_elements.last_elements import last_elements
from wsagent.storages.type.redis.methods.search_primitive.type.vector_search.vector_search import vector_search
from wsagent.storages.type.redis.methods.search_primitive.type.hybrid_search.hybrid_search import hydrid_search
from wsagent.storages.type.redis.methods.storage_primitive.type.check_storage.check_storage import check_storage
from wsagent.storages.type.redis.methods.storage_primitive.type.create_storage.create_storage import create_storage
from wsagent.storages.type.redis.methods.insert_primitive.type.default.insert_default import insert_default

redis_algorithm_function_map = {
    # Insert
    Storage.Algorithm.Insert.DEFAULT: insert_default,
    # Search
    Storage.Algorithm.Search.RAW_SEARCH: redis_handle_search,
    Storage.Algorithm.Search.LAST_ELEMENTS: last_elements,
    Storage.Algorithm.Search.VECTOR_SEARCH: vector_search,
    Storage.Algorithm.Search.HYBRID_SEARCH: hydrid_search,
    Storage.Algorithm.Search.GET_SPECIFIC_DATA: get_specific_data,
    # Storage
    Storage.Algorithm.Storage.CHECK_STORAGE: check_storage,
    Storage.Algorithm.Storage.CREATE_STORAGE: create_storage
}