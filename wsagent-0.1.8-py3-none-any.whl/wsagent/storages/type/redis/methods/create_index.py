import logging
import traceback
from typing import Optional
from wsagent.storages.type.redis.methods.redis_handle.redis_create_index.redis_create_index import redis_handle_create_index
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def create_index(
    log: Optional[logging.Logger] = None,
    *args, **kwargs):

    log.info("Creating Index Redis ...")

    try:           
        output = await redis_handle_create_index(
            log=log,
            *args, **kwargs
        )
        return output
        
    except Exception as e:
        log.error(f"Creating Index Failed. An error occurred: {traceback.format_exc()}")
    
    return None
    