import logging
from typing import Optional
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.methods.redis_handle.redis_create_index.redis_create_index import redis_handle_create_index
# from wsagent.utils.validate_args import async_validate_required_args

# @async_validate_required_args
async def create_storage(
    algorithm: Optional[Storage.Algorithm.Storage] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):

    return await redis_handle_create_index(
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        storage_params=storage_params,
        log=log
    )