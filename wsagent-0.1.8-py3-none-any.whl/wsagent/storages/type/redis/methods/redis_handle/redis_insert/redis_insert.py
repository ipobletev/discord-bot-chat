from datetime import datetime
import logging
import traceback
from typing import List, Optional
import uuid
import redis
from redis.commands.search.field import Field
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse
from redis.commands.json.path import Path
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def redis_handle_insert(
    algorithm: Optional[Storage.Algorithm.Insert] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    init_timestamp=datetime.now().timestamp()

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## algorithm
    data: dict = algorithm_params.get('data')
    unique_key: str = algorithm_params.get('unique_key', None)
    storage_ident: str = algorithm_params.get('storage_ident', None)
    path: Path = algorithm_params.get('path', None)
    prefix: List[str] = algorithm_params.get('prefix', None)
    ## storage_params
    redis_client: redis.Redis = storage_params.get('redis_client', None)
    index_schema: List[Field] = storage_params.get('index_schema', None)
    use_id_from_data: bool = storage_params.get('use_id_from_data', False)
    key_id_field: str = storage_params.get('key_id_field', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident')
    if prefix is None: prefix = storage_params.get('prefix', None)
    
    # Check if all required parameters are provided
    if redis_client is None: raise ValueError("Redis client is required for create_index operation.")
    if index_schema is None: raise ValueError("Index schema is required for create_index operation.")
    if prefix is None: raise ValueError("Prefix is required for create_index operation.")
    if path is None: path=Path.root_path()
    if data is None: raise ValueError("Data is required for insert operation.")   
    if storage_ident is None: raise ValueError("Index name is required for insert operation.")
     
    inserted=False
     
    # Execute the algorithm
    
    # If unique_key is not provided, generate a new one automatically with uuid
    if unique_key is None:
        if use_id_from_data == False:
            unique_key=f'{storage_ident}:{uuid.uuid4()}'
        else:
            key_id=data.get(key_id_field,None)
            if key_id == None:
                raise ValueError("use_data_id key error data must have an id")
            unique_key=f'{storage_ident}:{key_id}'
        
    # Check if the data already exists
    if redis_client.exists(f'{unique_key}'):
        log.info(f"Not loaded {unique_key} already exists, skipping insert.")
        inserted = False
    else:
        # Insert the data
        redis_client.json().set(unique_key, path, data)
        inserted=True
        
    return StorageResponse(
        result=inserted,
        additional_data=None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        init_timestamp=init_timestamp,
    )