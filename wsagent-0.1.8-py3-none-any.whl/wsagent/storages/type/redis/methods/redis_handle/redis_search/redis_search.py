from datetime import datetime
import json
import logging
from typing import Optional
import numpy as np
import redis
from redis.commands.search.query import Query
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.enum import RedisDBEnums
from wsagent.storages.type.redis.utils.redis_utils import format_fields_value_filters 
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def redis_handle_search(
    algorithm: Optional[Storage.Algorithm.Search] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    """
    ### Brief

    Redis handle search method. This method is used to search elements in a Redis storage.
    
    ### Parameters of storage_params
    - storage_ident: str = Storage ident to use.
    - redis_client: redis.Redis = Redis client to use.
    - text_search_value: str = Text to search.
    - fuzzy_search: Optional[int] = Fuzzy search value.
    - k_top: Optional[int] = Number of top results to return.
    - return_fields: Optional[list] = List of fields to return.
    - redis_return_fields: Optional[list] = List of redis client fields to return.
    - limit_fields: Optional[list] = List of fields to limit.
    - fields_value_filters: Optional[list] = List of fields value filters.
    - vector_value: Optional[list] = Vector value to search.
    - vector_field: Optional[str] = Vector field to search.
    - sort_by: Optional[str] = Field to sort by.
    - sort_order_asc: Optional[bool] = Sort order.
    - add_filter: Optional[list] = List of redis filters to add.
    - raw_query: Optional[str] = Raw query to execute.
    - raw_params_dict: Optional[dict] = Raw query parameters.
    - id_value: Optional[str] = Get key.
    
    ### Algorithm parameters to use:
    ```
    algorithm_params = {
        "storage_ident": "redis_storage",
        "text_search_value": "search_value",
        "fuzzy_search": 1,
        "k_top": 10,
        "return_fields": ["field1","field2"],
        "redis_return_fields": ["field1","field2"],
        "limit_fields": ["field1","field2"],
        "fields_value_filters": ["field1:value1","field2:value2"],
        "vector_value": [0.1,0.2,0.3,...],
        "vector_field": "vector_field",
        "sort_by": "field1",
        "sort_order_asc": True,
        "add_filter": [...],
        "raw_query": "Redis query",
        "raw_params_dict": {...},
        "id_value": "key:uuid",
        "scorer": RedisDBEnums.Scoring.FullText.BM25.value
    }
    ```
    """
    
    init_timestamp=datetime.now().timestamp()
    
    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")
    
    # All parameters for this method
    ## parameters
    storage_ident: str = algorithm_params.get('storage_ident', None)
    # custom search
    text_search_value = algorithm_params.get('text_search_value', None)
    fuzzy_search: Optional[int] = algorithm_params.get('fuzzy_search', None)
    k_top: Optional[int] = algorithm_params.get('k_top', None)
    return_fields:  Optional[list] = algorithm_params.get('return_fields', None)
    redis_return_fields: Optional[list] = algorithm_params.get('redis_return_fields', None)
    limit_fields: Optional[list] = algorithm_params.get('limit_fields', None)
    fields_value_filters: Optional[list] = algorithm_params.get('fields_value_filters', None)
    # Vector
    vector_value: Optional[list] = algorithm_params.get('vector_value', None)
    vector_field: Optional[str] = algorithm_params.get('vector_field', None)
    # Sort numeric
    sort_by: Optional[str] = algorithm_params.get('sort_by', None)
    sort_order_asc: Optional[bool] = algorithm_params.get('sort_order_asc', None)
    # add filter
    add_filter: Optional[list] = algorithm_params.get('add_filter', None)
    # raw query
    raw_query: Optional[str] = algorithm_params.get('raw_query', None)
    raw_params_dict: Optional[dict] = algorithm_params.get('raw_params_dict', None)
    # get key
    id_value: Optional[str] = algorithm_params.get('id_value', None)
    #Scorer
    scorer: Optional[str] = algorithm_params.get('scorer', None)
    
    ## storage_params
    redis_client: redis.Redis = storage_params.get('redis_client', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident')
    
    if redis_client is None: raise ValueError("Redis client is required for search operation.")
    if storage_ident is None: raise ValueError("Storage ident is required for search operation.")
    
    # default values
    if scorer is None: scorer = RedisDBEnums.Scoring.FullText.BM25.value
    if redis_return_fields is None: redis_return_fields = []
    
    # Execute the algorithm
    
    query_str=''
    params_dict={}
    content=[]
    total_results=0
    results=None

    # Raw query
    if id_value:
        log.info("Get key")
        log.info(f"id_value: {id_value}")
        try:
            results: dict = redis_client.execute_command('JSON.GET', id_value, *redis_return_fields)
        except redis.exceptions.ResponseError as e:
            results = None
        
        if results is None:
            results = []
        else:
            results = [json.loads(results.decode('utf-8'))]
    
    elif raw_query is not None: 
        log.info("Raw query search")
        log.info(f"raw_query: {raw_query}")
        query = (
            Query(raw_query)
        )
        log.info(f"Query: {query.get_args()}")
        log.info(f"Params: {raw_params_dict}")
        results = redis_client.ft(storage_ident).search(query,raw_params_dict)
    
    # Exact Text search or "All" search "*"
    elif fuzzy_search == None and vector_value is None:
        log.info("Exact text search")
        
        filter_query=''
        if fields_value_filters:
            if text_search_value == '*':
                raise ValueError("text_search_value can not be * when using fields_value_filters, not sense")
            filter_query += f' {format_fields_value_filters(fields_value_filters)}'

        query_str = text_search_value + filter_query
        
    # Fuzzy search
    elif fuzzy_search is not None and vector_value is None:
        log.info("Fuzzy text search")
        fuzzy_query_str=''
        filter_query=''
        
        fuzzy_query_str += f"{'%' * fuzzy_search}{text_search_value}{'%' * fuzzy_search} " if fuzzy_search > 0 else text_search_value
        
        if fields_value_filters:
            if text_search_value == '*':
                raise ValueError("text_search_value can not be * when using fields_value_filters, not sense")
            filter_query += f' {format_fields_value_filters(fields_value_filters)}'
            
        query_str = fuzzy_query_str + filter_query
    
    # Vector search
    elif vector_value is not None:
        log.info("Redis vector search")
        
        filter_query=''
        if fields_value_filters:
            if text_search_value == '*':
                raise ValueError("text_search_value can not be * when using fields_value_filters, not sense")
            filter_query += f' {format_fields_value_filters(fields_value_filters)}'
            
        if text_search_value == None and filter_query == '':
            text_search_value = '*'
        
        # Secure text_search_value to one word
        if text_search_value is not None:
            text_search_value = text_search_value.split(' ')[0]
        
        query_str = f'{text_search_value} {filter_query}=>[KNN {k_top} @{vector_field} $query_vector AS vector_score]'
        params_dict = {"query_vector": np.array(vector_value, dtype=np.float32).tobytes()}
        
    else:
        raise ValueError("Invalid search type or parameters")
    

    if id_value is None:
        query = (
            Query(query_str)
        )
        query.with_scores()
        if scorer:
            query.scorer(scorer)
        if redis_return_fields:
            query.redis_return_fields(*redis_return_fields)
        if k_top:
            query.paging(0, k_top)
        if limit_fields:
            query.limit_fields(*limit_fields) 
        if add_filter:
            query.add_filter(*add_filter)
        if sort_by:
            query.sort_by(field=sort_by,asc=sort_order_asc)
        if vector_value is not None:
            query.sort_by("vector_score")
            query.dialect(2)
        
        query_args = query.get_args()
        log.info(f"Query: {query_args}")
        
        results = redis_client.ft(storage_ident).search(query,params_dict)
        log.info(f"results: {results}")
    
        # Get only return fields
        if redis_return_fields:
            content = [doc.__dict__ for doc in results.__dict__.get('docs',[])]
            total_results = results.__dict__.get('total',0)
        # Get all data
        else:            
            for doc in results.docs:
                data = json.loads(doc.__dict__.get('json'))
                del doc.__dict__['json']
                doc_dict = json.dumps(doc.__dict__)
                doc_json = json.loads(doc_dict)
                doc_json.update(data)
                if 'vector_score' in doc_json: doc_json['vector_score'] = float(doc_json['vector_score'])
                content.append(doc_json)
            total_results = len(content)
    
    if id_value:
        content = results
        total_results = len(content)
        
    # manual filter to return_fields
    if return_fields is not None:
        for idx, item in enumerate(content):
            filtered_item = {}
            for field in return_fields:
                nested_keys = field.split('.')
                value = item
                for key in nested_keys:
                    value = value.get(key, None)
                    if value is None:
                        break
                if value is not None:
                    current_dict = filtered_item
                    for key in nested_keys[:-1]:
                        if key not in current_dict:
                            current_dict[key] = {}
                        current_dict = current_dict[key]
                    current_dict[nested_keys[-1]] = value
            content[idx] = filtered_item
    
    # change score vector if exist to 1- vector_score (redis use 0 as more similar). it will change to 1 as more similar
    if vector_value is not None:
        for item in content:
            if 'vector_score' in item:
                item['vector_score'] = 1 - float(item['vector_score'])

    log.info(f"redis_search ouput: {content}")
    log.info(f"total_results: {total_results}")

    return StorageResponse(
        result=content,
        additional_data={
            "total_results": total_results
        },
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        init_timestamp=init_timestamp,
    )