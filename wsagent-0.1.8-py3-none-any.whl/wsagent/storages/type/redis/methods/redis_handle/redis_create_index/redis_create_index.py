from datetime import datetime
import logging
from typing import List, Optional
import redis
from redis.commands.search.field import Field
from redis.commands.search.indexDefinition import IndexDefinition, IndexType
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse
# from wsagent.utils.validate_args import async_validate_required_args

# @async_validate_required_args
async def redis_handle_create_index(
    algorithm: Optional[Storage.Algorithm.Storage] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    init_timestamp=datetime.now().timestamp()

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## parameters
    storage_ident: str = algorithm_params.get('storage_ident', None)

    ## storage_params
    redis_client: redis.Redis = storage_params.get('redis_client', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident', None)
    index_schema: List[Field] = storage_params.get('index_schema', None)
    prefix: List[str] = storage_params.get('prefix', None)
    
    # Check if all required parameters are provided
    if redis_client is None: raise ValueError("Redis client is required for create_index operation.")
    if index_schema is None: raise ValueError("Index schema is required for create_index operation.")
    if prefix is None: raise ValueError("Prefix is required for create_index operation.")
    if storage_ident is None: raise ValueError("Storage ident is required for create_index operation.")
    
    created=False
    
    try:
        # Check if index exists
        redis_client.ft(storage_ident).info()
        log.info("Index already exists")
    # If index does not exist, create it    
    except:

        # Create the index
            response = redis_client.ft(storage_ident).create_index(
                fields=index_schema,
                definition=IndexDefinition(prefix=prefix, index_type=IndexType.JSON)
            )
            created = True
            log.info(f"Index created: {storage_ident}")

    return StorageResponse(
        result=created,
        additional_data=None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        init_timestamp=init_timestamp,
    )