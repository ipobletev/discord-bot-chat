from typing import List

def normalize_score(
    documents: List[dict], 
    field_score: str, 
    inverse: bool = False
):
    max_score = float(max(doc[field_score] for doc in documents))
    min_score = float(min(doc[field_score] for doc in documents))

    if max_score == min_score:
        for doc in documents:
            doc['score_normalize'] = max_score
        return

    def norm_score(score, min, max):
        if inverse:
            return (max - score) / (max - min)
        else:
            return (score - min) / (max - min)

    for doc in documents:
        score = float(doc[field_score])
        doc['score_normalize'] = norm_score(score, min_score, max_score)