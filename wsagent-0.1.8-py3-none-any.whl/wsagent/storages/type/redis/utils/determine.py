from enum import Enum
from wsagent.storages.storages import StorageType

def is_action_in_storage(action, aimodel_class=None):
    def retrieve_enum_classes(cls):
        enum_classes = set()
        # Search for Enum classes within the top-level class (members and subclasses)
        for attr in dir(cls):
            # Skip special attributes
            if attr.startswith('__'):
                continue

            attr_value = getattr(cls, attr)
            if isinstance(attr_value, Enum):
                enum_classes.add(attr_value.__class__) # Add the class of the enum member
            elif isinstance(attr_value, type) and issubclass(attr_value, Enum):
                enum_classes.add(attr_value) # Add the enum class
            elif hasattr(attr_value, "__dict__"): # If it's a class-like, explore further
                enum_classes |= retrieve_enum_classes(attr_value) # Union assignment

        return enum_classes

    # Find all Enum classes within OpenAIEnums
    aimodel_class_enum_classes = retrieve_enum_classes(aimodel_class)
    # Check if action's class is in the retrieved set of enum classes
    return action.__class__ in aimodel_class_enum_classes


def determine_storage_class(action):
    for name in dir(StorageType):
        
        # Retrieve the attribute from AIModel
        attr_value = getattr(StorageType, name)

        if is_action_in_storage(action, attr_value):
            return attr_value  # Return the matching enum class
        
    # Return None if the action does not belong to any AIModel enum class
    return None