from enum import Enum
from wsagent.storages.storages import StorageType

def format_fields_value_filters(fields):
    def fields_value_filter(field,value,type):
        if type == "tag":
            return f'@{field}:' + '{' f'{value}' + '}'
        elif type == "text":
            return f"@{field}:{value}"
        else:
            raise ValueError("type must be tag or text")

    if fields is None:
        return "*"
    else:
        return " ".join([fields_value_filter(field['field_name'], field['value'], field['type']) for field in fields])

