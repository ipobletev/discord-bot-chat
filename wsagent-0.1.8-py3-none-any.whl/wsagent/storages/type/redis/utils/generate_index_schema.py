import inspect
from typing import Any, Optional, get_origin, get_args, Union, List, Dict
import typing
from redis.commands.search.field import NumericField, TextField, TagField, VectorField

def flatten_dict(data, parent_key='', sep='.'):
    """Flatten nested dictionaries into a single dictionary with dotted keys."""
    items = []
    for k, v in data.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):  # Recursively flatten dictionaries
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)

def auto_generate_index_schema(
    create_data_item_func: Optional[callable] = None,
    index_schema_config: Optional[dict] = None
):
    """Dynamically generates index schema handling complex structures.
    
    ### Example Usage:
    ```
    storage_struc: Callable = A function that generates a structure for storage identity.
        
        def data_item_func(
            title: Optional[str] = None,
            content: Optional[str] = None,
            title_vector: Optional[List[float]] = None,
            content_vector: Optional[List[float]] = None,
            uuid: Optional[str] = None,
            id: Optional[str] = None,
            url: Optional[str] = None,
            doc_name: Optional[str] = None,
            doc_ref: Optional[str] = None,
            doc_ind: Optional[str] = None,
            timestamp: Optional[float] = None
        ):

            return{
                "title": title,
                "content": content,
                "title_vector": title_vector,
                "content_vector": content_vector,
                "uuid": uuid,
                "id": id,
                "timestamp": timestamp,
                "source": {
                    "url": url,
                    "doc_name": doc_name,
                    "doc_ref": doc_ref,
                    "doc_ind": doc_ind,
                }
            }
    
    index_schema_config = {
        "vector_dim": 3072,
        "vector_distance_metric": "COSINE",
        "vector_type": "FLOAT32"
        "vector_idx_algorithm": "FLAT"
    }
    ```
    """
    
    vector_dim=None
    vector_distance_metric=None
    vector_type=None
    vector_idx_algorithm=None
    
    # get index_schema_config
    if index_schema_config is not None:        
        vector_dim = index_schema_config.get("vector_dim", None)
        vector_distance_metric = index_schema_config.get("vector_distance_metric", None)
        vector_type = index_schema_config.get("vector_type", None)
    
    # Default values if index_schema_config is not provided
    if vector_dim is None: vector_dim = 3072
    if vector_distance_metric is None: vector_distance_metric = "COSINE"
    if vector_type is None: vector_type = "FLOAT32"
    if vector_idx_algorithm is None: vector_idx_algorithm = "FLAT"
    
    sig = inspect.signature(create_data_item_func)
    
    args = {}
    for name, param in sig.parameters.items():
        param_type = param.annotation
        base_type = get_origin(param_type) or param_type
        if base_type is Union:
            inner_types = get_args(param_type)
            base_type = next(t for t in inner_types if t is not type(None))
            
        if base_type is str:
            args[name] = "sample"
        elif base_type is int:
            args[name] = 1
        elif base_type is float:
            args[name] = 1.0
        elif base_type is list or base_type is List or List[Any]:
            args[name] = []
        elif base_type is dict or base_type is Dict:
            args[name] = {}
        else:
            args[name] = "unknown"

    sample_item = create_data_item_func(**args)
    sample_item = flatten_dict(sample_item)  # Flatten in case there are nested dicts
    
    index_schema = []
    for key, value in sample_item.items():
        if isinstance(value, list) and "vector" in key:
            index_schema.append(VectorField(name=f'$.{key}', as_name=key,
                algorithm=vector_idx_algorithm,
                attributes={
                    "TYPE": vector_type,
                    "DIM": vector_dim,
                    "DISTANCE_METRIC": vector_distance_metric
                }
            ))
        elif isinstance(value, str) and "tag" in key:
            index_schema.append(TagField(f'$.{key}', as_name=key))
        elif isinstance(value, int):
            index_schema.append(NumericField(f'$.{key}', as_name=key))
        elif isinstance(value, str):
            index_schema.append(TextField(f'$.{key}', as_name=key))
        elif isinstance(value, float):
            index_schema.append(NumericField(f'$.{key}', as_name=key))
        # Handling nested structures or lists might require customized logic here

    return index_schema