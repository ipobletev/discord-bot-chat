# Dispatch dictionary
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.methods.storage import storage
from wsagent.storages.type.redis.methods.insert import insert
from wsagent.storages.type.redis.methods.search import search

redis_function_action_mapping = {
    Storage.Algorithm.Insert: insert,
    Storage.Algorithm.Search: search,
    Storage.Algorithm.Storage: storage,
}