import asyncio
from typing import Optional, Union
import redis
from wsagent.storages.base import Storage, StorageBase
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.redis.function_action_mapping import redis_function_action_mapping
from wsagent.storages.type.redis.methods.storage_primitive.type.check_storage.check_storage import check_storage
from wsagent.storages.type.redis.methods.storage_primitive.type.create_storage.create_storage import create_storage
from wsagent.storages.type.redis.utils.generate_index_schema import auto_generate_index_schema
from wsagent.utils.validate_args import validate_required_args

class RedisDB(StorageBase):

    @validate_required_args
    def __init__(self, 
        storage_params: Optional[dict]=None,
        session_id: Optional[str] = None,
        # Log configuration
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ) -> None:

        # redis configuration
        self.redis_host             = storage_params.get("host"    , "localhost")
        self.redis_port             = storage_params.get("port"    , 6379       )
        self.redis_password         = storage_params.get("password", ""         )
        self.redis_db               = storage_params.get("db"      , 0          )

        # Redis client
        self.redis_client: redis.Redis = None
        
        # Check if index schema is provided. If not, auto generate it
        storage_params['index_schema'] = storage_params.get('index_schema', None)
        if storage_params['index_schema'] is None: 
            storage_struc = storage_params.get('storage_struc', None)
            index_schema_config = storage_params.get('index_schema_config', None)
            if storage_struc is not None:
                storage_params['index_schema'] = auto_generate_index_schema(storage_struc, index_schema_config)
            else:
                raise ValueError("index_schema not was provided and could not auto generate index schema. storage_struc is required.")
                        
        storage_service_name = f'redis_db'
        
        """Initialize the Storage model."""
        super().__init__(
            storage_service_name=storage_service_name,
            storage_params=storage_params,
            session_id=session_id,
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )

    @validate_required_args
    def connect(self,redis_host,redis_port,redis_password,redis_db):
        
        def establish_connection():
            self.redis_client = redis.Redis(
                host=redis_host,
                port=redis_port,
                password=redis_password,
                db=redis_db
            )
            self.redis_client.ping()
            self.storage_params["redis_client"] =self.redis_client
            
            return True

        # First time connection
        if self.redis_client is None: 
            return establish_connection()
        
        # Check if connection is alive
        else:
            if not self.redis_client.ping():
                return establish_connection()
            return True
    
    def disconnect(self):
        self.redis_client.close()
    
    @validate_required_args
    async def internal_execute(self,
        algorithm: Optional[Union[Storage.Algorithm.Insert,Storage.Algorithm.Search,Storage.Algorithm.Storage]] = None, 
        algorithm_params: Optional[dict] = None
    ) -> StorageResponse:

        if algorithm is None:
            self.log.error("algorithm must be provided")
            raise ValueError("algorithm must be provided")

        # Check redis connection
        if not self.connect(self.redis_host,self.redis_port,self.redis_password,self.redis_db):
            self.log.error("Could not connect to redis")
            raise ValueError("Could not connect to redis")

        # Check if physical storage exists
        check_storage_response: StorageResponse = await check_storage(
            algorithm=Storage.Algorithm.Storage.CHECK_STORAGE,
            algorithm_params=algorithm_params,
            storage_params=self.storage_params,
            log=self.log
        )
        # If physical storage does not exist, create it
        if not check_storage_response.result:
            self.log.info("Physical storage does not exist. Creating it.")
            create_storage_response: StorageResponse = await create_storage(
                algorithm=Storage.Algorithm.Storage.CREATE_STORAGE,
                algorithm_params=algorithm_params,
                storage_params=self.storage_params,
                log=self.log
            )
            if not create_storage_response.result:
                self.log.error("Physical storage could not be created")
                raise ValueError("Physical storage could not be created")
        
        # Get the action to be executed
        if isinstance(algorithm, Storage.Algorithm.Search):
            action = Storage.Algorithm.Search

        if isinstance(algorithm, Storage.Algorithm.Insert):
            action = Storage.Algorithm.Insert

        if isinstance(algorithm, Storage.Algorithm.Storage):
            action = Storage.Algorithm.Storage

        # Get the function to call
        function_to_call = redis_function_action_mapping.get(action)
        
        if function_to_call == None:
            self.log.error(f"Function to call not found action: {action}")
            raise ValueError(f"Function to call not found action: {action}")
        
        # Check if function_to_call is a coroutine function
        if asyncio.iscoroutinefunction(function_to_call):
            output = await function_to_call( 
                log=self.log,
                algorithm=algorithm,
                algorithm_params=algorithm_params,
                storage_params=self.storage_params)
        else:
            # Execute synchronously if it's not a coroutine
            output = function_to_call( 
                log=self.log,
                algorithm=algorithm,
                algorithm_params=algorithm_params,
                storage_params=self.storage_params)
            
        return output