class ExceptionAlreadyExist(Exception):
    """Raised when a key already exists in the database"""
    pass