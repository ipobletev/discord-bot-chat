from enum import Enum

class LocalRamEnums:
    
    pass