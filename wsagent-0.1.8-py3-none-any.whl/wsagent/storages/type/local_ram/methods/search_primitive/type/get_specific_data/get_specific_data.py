from datetime import datetime
import logging
from typing import Optional
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def get_specific_data(
    algorithm: Optional[Storage.Algorithm.Search] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    init_timestamp=datetime.now().timestamp()

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## algorithm_params
    storage_ident = algorithm_params.get('storage_ident', None)
    id_field = algorithm_params.get('id_field', None)
    id_value = algorithm_params.get('id_value', None)
    return_fields = algorithm_params.get('return_fields', None)
    ## storage_params
    storage_ident = algorithm_params.get('storage_ident', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident')
    
    # Check if all required parameters are provided
    if id_field is None: raise ValueError("id_field is required for search operation.")
    if id_value is None: raise ValueError("id_value is required for search operation.")

    # Execute the algorithm
    retrieval_data=[]
        
    # Open the file and load the data
    ram_storage = storage_ident

    # Get the element
    for element in ram_storage:
        if element.get(id_field) == id_value:
            retrieval_data.append(element)
            break

    # filter return_fields
    if return_fields is not None:
        for idx, item in enumerate(retrieval_data):
            filtered_item = {}
            for field in return_fields:
                nested_keys = field.split('.')
                value = item
                for key in nested_keys:
                    value = value.get(key, None)
                    if value is None:
                        break
                if value is not None:
                    current_dict = filtered_item
                    for key in nested_keys[:-1]:
                        if key not in current_dict:
                            current_dict[key] = {}
                        current_dict = current_dict[key]
                    current_dict[nested_keys[-1]] = value
            retrieval_data[idx] = filtered_item

    return StorageResponse(
        result=retrieval_data,
        additional_data=None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        init_timestamp=init_timestamp,
    )