from datetime import datetime
import logging
from typing import List, Optional
from wsagent.storages.storages_enum import Storage
from wsagent.utils.json_utils import get_nested_value
from wsagent.utils.math_vector import vector_similarity
from wsagent.utils.normalize import math_normalize
from wsagent.storages.schemas.storage_response import StorageResponse
from rank_bm25 import BM25Okapi
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def hybrid_search(
    algorithm: Optional[Storage.Algorithm.Search] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    init_timestamp=datetime.now().timestamp()

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## algorithm_params
    vector_value = algorithm_params.get('vector_value', None)
    vector_field = algorithm_params.get('vector_field', None)
    text_search_value = algorithm_params.get('text_search_value', None)
    text_search_field = algorithm_params.get('text_search_field', None)
    return_fields: List[str] = algorithm_params.get('return_fields', None)
    k_sem = algorithm_params.get('k_sem', None)
    k_sim = algorithm_params.get('k_sim', None)
    k_top = algorithm_params.get('k_top', None)
    ## storage_params
    storage_ident = algorithm_params.get('storage_ident', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident', None)
    
    # Check if all required parameters are provided
    if storage_ident is None: raise ValueError("Storage ident is required for insert operation.")
    if k_top is None: k_top = 5
    if vector_value is None: raise ValueError("vector_value must be provided")
    if vector_field is None: raise ValueError("vector_field must be provided")
    if k_sem is None: k_sem = 0.7
    if text_search_value is None: raise ValueError("text_search_value must be provided")
    if text_search_field is None: raise ValueError("text_search_field must be provided")
    if k_sim is None: k_sim = 0.3
    # if max_tokens is not None and token_field is None: raise ValueError('token_field is required')
    
    filtered_idx_data=[]
    retrieval_data=[]
        
    # Give to elements the storage data
    elements = storage_ident
    
    if len(elements) > 0:

        #### ALGORITHM ####
        # Vector search
        vector_idx_data = []
        for idx, item in enumerate(elements):
            vector_score = vector_similarity(vector_value, get_nested_value(item,vector_field))
            vector_idx_data.append((idx, vector_score))
        # vector_idx_data = sorted(vector_idx_data, key=lambda x: x[1], reverse=True)
        
        # Text search BM25
        corpus = [get_nested_value(item,text_search_field) for item in elements]
        tokenized_corpus = [doc.split(" ") for doc in corpus]
        tokenized_query = text_search_value.split(" ")
        bm25 = BM25Okapi(tokenized_corpus)
        text_search_raw_score = bm25.get_scores(tokenized_query)
        text_search_idx_data = math_normalize(
            scores=text_search_raw_score,
            min_val=0.0,
            max_val=1.0,
            reverse=False # False 1 more similar
        )

        # Combine scores from vector and text search with weights k_sem and k_sim at same idx
        combined_idx_data = set()
        for idx, item in enumerate(elements):
            text_score = text_search_idx_data[idx]                      # 0-1, 1 More text similar
            vector_score = vector_idx_data[idx][1]                      # 0-1, 1 More similar
            combined_score = k_sem * vector_score + k_sim * text_score  # 0-1, 1 More similar
            combined_idx_data.add((idx, combined_score, vector_score, text_score))
        combined_idx_data = sorted(combined_idx_data, key=lambda x: x[1], reverse=True)
        combined_idx_data = combined_idx_data[:k_top]
        
        ####################

        # retrieve data
        for idx, combined_score, vector_score, text_score in combined_idx_data:
            element = elements[idx]
            element['final_score'] = combined_score
            element['vector_score'] = vector_score
            element['text_score'] = text_score
            retrieval_data.append(element)

        # filter return_fields
        if return_fields is not None:
            for idx, item in enumerate(retrieval_data):
                filtered_item = {}
                for field in return_fields:
                    nested_keys = field.split('.')
                    value = item
                    for key in nested_keys:
                        value = value.get(key, None)
                        if value is None:
                            break
                    if value is not None:
                        current_dict = filtered_item
                        for key in nested_keys[:-1]:
                            if key not in current_dict:
                                current_dict[key] = {}
                            current_dict = current_dict[key]
                        current_dict[nested_keys[-1]] = value
                retrieval_data[idx] = filtered_item
                    
        log.info(f"retrieval_data: {retrieval_data}")       
        
    return StorageResponse(
        result=retrieval_data,
        additional_data=None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        init_timestamp=init_timestamp,
    )