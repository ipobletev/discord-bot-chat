from datetime import datetime
import logging
from typing import Optional
import uuid
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def insert_default(
    algorithm: Optional[Storage.Algorithm.Insert] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    init_timestamp=datetime.now().timestamp()

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## algorithm
    data = algorithm_params.get('data',None)
    unique_key = algorithm_params.get('unique_key',None)
    ## storage_params
    storage_ident = storage_params.get('storage_ident',None)
    storage_name = storage_params.get('storage_name',None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident',None)
    
    # Check if all required parameters are provided
    if data is None: raise ValueError("Data is required for insert operation.")
    if storage_ident is None: raise ValueError("Storage ident is required for insert operation.")
    if unique_key is None: unique_key = f'{storage_name}:{uuid.uuid4()}'

    # Set field for framework compatibility
    data['unique_key'] = unique_key
    
    # Execute the algorithm    
    storage_ident: list = storage_ident.append(data)
    
    return StorageResponse(
        result=True,
        additional_data=None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        init_timestamp=init_timestamp,
    )