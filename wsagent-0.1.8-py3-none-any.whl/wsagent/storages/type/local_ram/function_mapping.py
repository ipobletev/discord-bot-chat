# Dispatch dictionary LocalRam
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.local_ram.methods.insert import  insert
from wsagent.storages.type.local_ram.methods.search import search

local_ram_function_map = {
    Storage.Algorithm.Insert: insert,
    Storage.Algorithm.Search: search,
}