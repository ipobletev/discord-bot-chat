import asyncio
from typing import Optional, Union
import uuid
from wsagent.storages.base import Storage, StorageBase
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.local_ram.function_mapping import local_ram_function_map
from wsagent.utils.validate_args import validate_required_args

class LocalRam(StorageBase):
    @validate_required_args
    def __init__(self, 
        storage_params: Optional[dict]=None,
        session_id: Optional[str] = None,
        # Log configuration
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ) -> None:
        
        if storage_params is None: storage_params = {}
        
        # Use a external ram storage if provided
        # Set self.ram_storage to an empty list if not provided
        self.ram_storage= []
        storage_ident: dict = storage_params.get("storage_ident", None)
        if storage_ident is None:
            storage_params.update({"storage_ident": self.ram_storage})
        
        storage_service_name="local_ram"
        
        super().__init__(
            storage_service_name=storage_service_name,
            storage_params=storage_params,
            session_id=session_id,
            log_name=log_name,
			log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )

    @validate_required_args
    async def internal_execute(self,
        algorithm: Optional[Union[Storage.Algorithm.Insert,Storage.Algorithm.Search,Storage.Algorithm.Storage]] = None, 
        algorithm_params: Optional[dict] = None
    ) -> StorageResponse:

        if algorithm is None:
            self.log.error("algorithm must be provided")
            raise ValueError("algorithm must be provided")
        
        # Get the action to be executed
        if isinstance(algorithm, Storage.Algorithm.Search):
            action = Storage.Algorithm.Search

        if isinstance(algorithm, Storage.Algorithm.Insert):
            action = Storage.Algorithm.Insert

        if isinstance(algorithm, Storage.Algorithm.Storage):
            raise ValueError("Storage actions are not supported by LocalRam storage.")
            
        # Get the function to call
        function_to_call = local_ram_function_map.get(action)
        
        if function_to_call == None:
            self.log.error(f"Function to call not found action: {action}")
            raise ValueError(f"Function to call not found action: {action}")
        
        # Check if function_to_call is a coroutine function
        if asyncio.iscoroutinefunction(function_to_call):
            output = await function_to_call( 
                log=self.log,
                algorithm=algorithm,
                algorithm_params=algorithm_params,
                storage_params=self.storage_params)
        else:
            # Execute synchronously if it's not a coroutine
            output = function_to_call( 
                log=self.log,
                algorithm=algorithm,
                algorithm_params=algorithm_params,
                storage_params=self.storage_params)
            
        return output