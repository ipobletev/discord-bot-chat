from datetime import datetime
import logging
import os
from typing import Optional
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def check_storage(
    algorithm: Optional[Storage.Algorithm.Storage] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    init_timestamp=datetime.now().timestamp()

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## storage_params
    storage_ident = algorithm_params.get('storage_ident', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident', None)
    
    # Check if all required parameters are provided
    if storage_ident is None: raise ValueError("Storage ident is required for insert operation.")

    # Execute the algorithm
    raw_response={}
    exist=False
    
    if not os.path.isfile(storage_ident):
        raw_response['status'] = exist
        log.info(f"Physical storage does not exist at {storage_ident}")
    else:
        exist = True
        raw_response['status'] = exist
        log.info(f"Physical storage exists at {storage_ident}")

    return StorageResponse(
        result=exist,
        additional_data=None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        init_timestamp=init_timestamp,
    )