from datetime import datetime
import json
import logging
import os
from typing import Optional
import uuid
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def insert_default(
    algorithm: Optional[Storage.Algorithm.Insert] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    init_timestamp=datetime.now().timestamp()

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## algorithm
    data = algorithm_params.get('data',None)
    unique_key = algorithm_params.get('unique_key',None)
    ## storage_params
    storage_ident = storage_params.get('storage_ident',None)
    storage_name = storage_params.get('storage_name',None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident',None)
    
    # Check if all required parameters are provided
    if data is None: raise ValueError("Data is required for insert operation.")
    if storage_ident is None: raise ValueError("Storage ident is required for insert operation.")
    if unique_key is None: unique_key = f'{storage_name}:{uuid.uuid4()}'
    if not isinstance(data, dict): raise ValueError("Data must be a dictionary.")
        
    # Set field for framework compatibility
    data['unique_key'] = unique_key
    
    # Execute the algorithm
 
    ## Initialize as an empty list if the file doesn't exist or is empty
    existing_data = []
    
    ## Check if the file exists and has content
    if os.path.isfile(storage_ident) and os.path.getsize(storage_ident) > 0:
        with open(storage_ident, 'r',encoding='utf-8') as json_file:
            ## Load the existing data
            existing_data = json.load(json_file)
            
            ## Ensure the existing data is a list before appending
            if not isinstance(existing_data, list):
                raise ValueError(f"JSON content of {storage_ident} is not a list. Append operation not supported.")


    ## Append the new data to the list
    existing_data.append(data)
    
    ## Write the updated data back to the file
    with open(storage_ident, 'w', encoding='utf-8') as json_file:
        json.dump(existing_data, json_file, indent=4, ensure_ascii=False)

    log.info(f"Data successfully appended to {storage_ident}")
        
    return StorageResponse(
        result=True,
        additional_data=None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        init_timestamp=init_timestamp,
    )