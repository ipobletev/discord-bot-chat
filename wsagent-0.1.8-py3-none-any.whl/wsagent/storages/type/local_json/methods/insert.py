import asyncio
import logging
from typing import Optional
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.local_json.methods.json_mapping import local_json_algorithm_function_map
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def insert( 
    algorithm: Optional[Storage.Algorithm.Insert] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    
    log.info("Insert action data to JSON file...")
    
    function_to_call = local_json_algorithm_function_map.get(algorithm)
    if function_to_call == None:
        log.error(f"Function to call not found: {algorithm}")
        raise ValueError(f"Function to call not found: {algorithm}")
        
    # Check if function_to_call is a coroutine function
    if asyncio.iscoroutinefunction(function_to_call):
        output = await function_to_call( 
            log=log,
            algorithm=algorithm,
            algorithm_params=algorithm_params,
            storage_params=storage_params)
    else:
        # Execute synchronously if it's not a coroutine
        output = function_to_call( 
            log=log,
            algorithm=algorithm,
            algorithm_params=algorithm_params,
            storage_params=storage_params)
    
    return output