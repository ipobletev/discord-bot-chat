from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.local_json.methods.insert_primitive.type.default.insert_default import insert_default
from wsagent.storages.type.local_json.methods.storage_primitive.type.check_storage.check_storage import check_storage
from wsagent.storages.type.local_json.methods.storage_primitive.type.create_storage.create_storage import create_storage
from wsagent.storages.type.local_json.methods.search_primitive.type.raw_search.raw_search import raw_search
from wsagent.storages.type.local_json.methods.search_primitive.type.last_element.last_element import last_elements
from wsagent.storages.type.local_json.methods.search_primitive.type.hybrid_search.hybrid_search import hybrid_search
from wsagent.storages.type.local_json.methods.search_primitive.type.vector_search.vector_search import vector_search
from wsagent.storages.type.local_json.methods.search_primitive.type.get_specific_data.get_specific_data import get_specific_data

local_json_algorithm_function_map = {
    # Insert
    Storage.Algorithm.Insert.DEFAULT: insert_default,
    #Search
    Storage.Algorithm.Search.RAW_SEARCH: raw_search,
    Storage.Algorithm.Search.LAST_ELEMENTS: last_elements,
    Storage.Algorithm.Search.HYBRID_SEARCH: hybrid_search,
    Storage.Algorithm.Search.VECTOR_SEARCH: vector_search,
    Storage.Algorithm.Search.GET_SPECIFIC_DATA: get_specific_data,
    # Storage
    Storage.Algorithm.Storage.CREATE_STORAGE: create_storage,
    Storage.Algorithm.Storage.CHECK_STORAGE: check_storage
}