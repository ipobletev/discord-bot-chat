from datetime import datetime
import json
import logging
from typing import List, Optional
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def last_elements(
    algorithm: Optional[Storage.Algorithm.Search] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    init_timestamp=datetime.now().timestamp()

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## algorithm_params
    k_top = algorithm_params.get('k_top', None)
    return_fields: List[str] = algorithm_params.get('return_fields', None)
    sort_by: str = algorithm_params.get('sort_by', None)
    sort_order_asc: bool = algorithm_params.get('sort_order_asc', None)
    ## storage_params
    storage_ident = algorithm_params.get('storage_ident', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident')
    
    # Check if all required parameters are provided
    if storage_ident is None: raise ValueError("Storage ident is required for insert operation.")
    if sort_by is None: raise ValueError("sort_by is required for search operation.")
    if sort_order_asc is None: sort_order_asc = False
    if k_top is None: k_top = 5

    # Execute the algorithm
    retrieval_data=[]
    elements=[]
        
    # Open the file and load the data
    with open(storage_ident, 'r',encoding='utf-8') as json_file:
        elements = json.load(json_file)

    if k_top > len(elements):
        k_top = len(elements)

    for i in range(1, k_top+1):
        element = elements[-i]
        retrieval_data.append(element)

            
    # Order by sort_by field
    retrieval_data = sorted(retrieval_data, key=lambda x: x[sort_by], reverse=not sort_order_asc)
    
    # filter return_fields
    if return_fields is not None:
        for idx, item in enumerate(retrieval_data):
            filtered_item = {}
            for field in return_fields:
                nested_keys = field.split('.')
                value = item
                for key in nested_keys:
                    value = value.get(key, None)
                    if value is None:
                        break
                if value is not None:
                    current_dict = filtered_item
                    for key in nested_keys[:-1]:
                        if key not in current_dict:
                            current_dict[key] = {}
                        current_dict = current_dict[key]
                    current_dict[nested_keys[-1]] = value
            retrieval_data[idx] = filtered_item
        
    return StorageResponse(
        result=retrieval_data,
        additional_data=None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        init_timestamp=init_timestamp,
    )