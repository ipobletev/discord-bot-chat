from datetime import datetime
import logging
from typing import Optional
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def raw_search(
    algorithm: Optional[Storage.Algorithm.Search] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    init_timestamp=datetime.now().timestamp()

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## algorithm_params
    k_top = algorithm_params.get('k_top', None)
    ## storage_params
    storage_ident = algorithm_params.get('storage_ident', None)
    if storage_ident is None: 
        log.info(f"storage_ident is not provided. Using default storage_ident from storage_params.")
        storage_ident = storage_params.get('storage_ident')

    if k_top is None: k_top = 5

    # # Execute the algorithm
    # retrieval_data=[]
    # elements=[]
        
    raise NotImplementedError("This method is not implemented yet.")

    # return StorageResponse(
    #     result=retrieval_data,
    #     additional_data=None,
    #     algorithm=algorithm,
    #     algorithm_params=algorithm_params,
    #     init_timestamp=init_timestamp,
    # )