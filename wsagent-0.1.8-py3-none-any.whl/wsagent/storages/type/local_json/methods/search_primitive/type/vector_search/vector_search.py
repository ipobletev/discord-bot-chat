from datetime import datetime
import json
import logging
from typing import List, Optional
from wsagent.storages.storages_enum import Storage
from wsagent.utils.json_utils import get_nested_value
from wsagent.utils.math_vector import vector_similarity
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def vector_search(
    algorithm: Optional[Storage.Algorithm.Search] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
):
    init_timestamp=datetime.now().timestamp()

    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")

    # All parameters for this method
    ## algorithm_params
    vector_value: List[float] = algorithm_params.get('vector_value', None)
    vector_field: str = algorithm_params.get('vector_field', None)
    return_fields: List[str] = algorithm_params.get('return_fields', None)
    k_top: int = algorithm_params.get('k_top', None)
    
    ## storage_params
    storage_ident = algorithm_params.get('storage_ident', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident')
    
    # Check if all required parameters are provided
    if storage_ident is None: raise ValueError("Storage ident is required for insert operation.")
    if k_top is None: k_top = 5
    if vector_field is None: raise ValueError('vector_field is required')
    if vector_value is None: raise ValueError('vector_value is required')
    
    # Execute the algorithm

    # total_tokens=0
    filtered_idx_data=[]
    retrieval_data=[]
    
    # Open the file and load the data
    with open(storage_ident, 'r',encoding='utf-8') as json_file:
        elements = json.load(json_file)
    
    idx_data = set()
    for idx, item in enumerate(elements):
        item_vector = get_nested_value(item,vector_field)
        vector_score = vector_similarity(vector_value, item_vector)
        idx_data.add((idx, vector_score))
    idx_data = sorted(idx_data, key=lambda x: x[1], reverse=True)
    
    # filter idx_data by k_top
    filtered_idx_data = idx_data[:k_top]
    
    # retrieve data
    retrieval_data = []
    for idx, score in filtered_idx_data:
        element = elements[idx]
        element['vector_score'] = score  # Add vector_score to the element
        retrieval_data.append(element)
        
    # filter return_fields
    if return_fields is not None:
        for idx, item in enumerate(retrieval_data):
            filtered_item = {}
            for field in return_fields:
                nested_keys = field.split('.')
                value = item
                for key in nested_keys:
                    value = value.get(key, None)
                    if value is None:
                        break
                if value is not None:
                    current_dict = filtered_item
                    for key in nested_keys[:-1]:
                        if key not in current_dict:
                            current_dict[key] = {}
                        current_dict = current_dict[key]
                    current_dict[nested_keys[-1]] = value
            retrieval_data[idx] = filtered_item
            
    log.info(f"retrieval_data: {retrieval_data}")        

    return StorageResponse(
        result=retrieval_data,
        additional_data=None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        init_timestamp=init_timestamp,
    )