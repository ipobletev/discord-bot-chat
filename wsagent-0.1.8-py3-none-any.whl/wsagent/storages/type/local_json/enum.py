# local_json_enum.py

from enum import Enum

class LocalJsonEnums:

    pass