# Dispatch dictionary LocalJson
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.local_json.methods.insert import  insert
from wsagent.storages.type.local_json.methods.search import search
from wsagent.storages.type.local_json.methods.storage import storage

local_json_function_map = {
    Storage.Algorithm.Insert: insert,
    Storage.Algorithm.Search: search,
    Storage.Algorithm.Storage: storage
}