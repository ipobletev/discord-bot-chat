import asyncio
from typing import Optional, Union
import uuid
from wsagent.storages.base import StorageBase
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.storages.storages_enum import Storage
from wsagent.storages.type.local_json.function_mapping import local_json_function_map
from wsagent.storages.type.local_json.methods.storage_primitive.type.check_storage.check_storage import check_storage
from wsagent.storages.type.local_json.methods.storage_primitive.type.create_storage.create_storage import create_storage
from wsagent.utils.validate_args import validate_required_args

class LocalJson(StorageBase):
    
    @validate_required_args
    def __init__(self, 
        storage_params: Optional[dict]=None,
        session_id: Optional[str] = None,
        # Log configuration
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ) -> None:
        
        if storage_params is None: storage_params = {}        
        storage_service_name="local_json"
        
        super().__init__(
            storage_service_name=storage_service_name,
            storage_params=storage_params,
            session_id=session_id,
            log_name=log_name,
			log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )
    
    @validate_required_args
    async def internal_execute(self,
        algorithm: Optional[Union[Storage.Algorithm.Insert,Storage.Algorithm.Search,Storage.Algorithm.Storage]] = None, 
        algorithm_params: Optional[dict] = None
    ) -> StorageResponse:
        
        if algorithm is None:
            self.log.error("algorithm must be provided")
            raise ValueError("algorithm must be provided")
        
        # Check if physical storage exists
        check_storage_response: StorageResponse = await check_storage(
            algorithm=Storage.Algorithm.Storage.CHECK_STORAGE,
            storage_params=self.storage_params,
            log=self.log
        )
        # If physical storage does not exist, create it
        if not check_storage_response.result:
            self.log.info("Physical storage does not exist. Creating it.")
            create_storage_response: StorageResponse = await create_storage(
                algorithm=Storage.Algorithm.Storage.CREATE_STORAGE,
                storage_params=self.storage_params,
                log=self.log
            )
            if not create_storage_response.result:
                self.log.error("Physical storage could not be created")
                raise ValueError("Physical storage could not be created")
        
        # Get the action to be executed
        if isinstance(algorithm, Storage.Algorithm.Search):
            action = Storage.Algorithm.Search

        if isinstance(algorithm, Storage.Algorithm.Insert):
            action = Storage.Algorithm.Insert

        if isinstance(algorithm, Storage.Algorithm.Storage):
            action = Storage.Algorithm.Storage

        # Get the function to call
        function_to_call = local_json_function_map.get(action)
        if function_to_call == None:
            self.log.error(f"Function to call not found action: {action}")
            raise ValueError(f"Function to call not found action: {action}")
        
        # Check if function_to_call is a coroutine function
        if asyncio.iscoroutinefunction(function_to_call):
            output = await function_to_call( 
                log=self.log,
                algorithm=algorithm,
                algorithm_params=algorithm_params,
                storage_params=self.storage_params)
        else:
            # Execute synchronously if it's not a coroutine
            output = function_to_call( 
                log=self.log,
                algorithm=algorithm,
                algorithm_params=algorithm_params,
                storage_params=self.storage_params)
            
        return output
            