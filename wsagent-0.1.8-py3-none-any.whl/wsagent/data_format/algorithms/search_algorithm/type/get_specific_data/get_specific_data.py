from datetime import datetime
import logging
from typing import Optional
from wsagent.data_format.schemas.data_format_response import DataFormatResponse
from wsagent.storages.storage_interface import StorageInterface
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse

async def get_specific_data(
    storage_type: Optional[Storage.Type] = None,
    ai_service_params: Optional[dict] = None,
    algorithm: Optional[Storage.Algorithm.Insert] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log_name: Optional[str] = None,
    log_path: Optional[str] = None,
    enable_log_file: Optional[bool] = False,
    enable_log_stream: Optional[bool] = False,
    log: Optional[logging.Logger] = None
):
    
    init_timestamp = datetime.now().timestamp()
    
    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")
    if storage_type is None: raise ValueError("storage_type must be provided")

    storage_interface = StorageInterface(
        storage_type=storage_type,
        storage_params=storage_params,
        session_id=None,
        log_name=log_name,
        log_path=log_path,
        enable_log_file=enable_log_file,
        enable_log_stream=enable_log_stream
    )
    
    output: StorageResponse = await storage_interface.execute(
        algorithm=Storage.Algorithm.Search.GET_SPECIFIC_DATA,
        algorithm_params=algorithm_params
    )

    return DataFormatResponse(
        result=output.result,
        additional_data = None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        storage_params=storage_params,
        init_timestamp=init_timestamp,
    )