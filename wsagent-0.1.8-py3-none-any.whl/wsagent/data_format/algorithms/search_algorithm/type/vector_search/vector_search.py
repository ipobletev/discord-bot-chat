from datetime import datetime
import logging
from typing import Optional
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_helper.ai_helper_interface import AIHelperInterface
from wsagent.ai_services.ai_services_enum import AIServices
from wsagent.ai_services.ai_services_interface import AIServicesInterface
from wsagent.data_format.schemas.data_format_response import DataFormatResponse
from wsagent.storages.storage_interface import StorageInterface
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse

async def vector_search(
    storage_type: Optional[Storage.Type] = None,
    ai_service_params: Optional[dict] = None,
    algorithm: Optional[Storage.Algorithm.Insert] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log_name: Optional[str] = None,
    log_path: Optional[str] = None,
    enable_log_file: Optional[bool] = False,
    enable_log_stream: Optional[bool] = False,
    log: Optional[logging.Logger] = None
):
    
    init_timestamp = datetime.now().timestamp()
    
    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")
    if storage_type is None: raise ValueError("storage_type must be provided")
    
    # All parameters for this method
    ## algorithm_params
    embedding_model = algorithm_params.get('embedding_model', None)
    input_query = algorithm_params.get('input_query', None)
    k_top = algorithm_params.get('k_top', None)
    return_fields = algorithm_params.get('return_fields', None)
    vector_field = algorithm_params.get('vector_field', None)
    storage_ident = algorithm_params.get('storage_ident', None)
    
    ## storage_params
    if storage_ident is None: storage_ident = storage_params.get('storage_ident', None)
    
    ## Check if all required parameters are provided
    if storage_ident is None: raise ValueError("Storage ident is required for insert operation.")
    if input_query is None: raise ValueError("input_query must be provided")
    if vector_field is None: raise ValueError("vector_field must be provided")

    # Check if all optional parameters are provided
    if embedding_model is None: embedding_model = AIServices.OpenAI.Feature.Embeddings.Model.LARGE_V3
    if k_top is None: k_top = 5

    storage_interface = StorageInterface(
        storage_type=storage_type,
        storage_params=storage_params,
        session_id=None,
        log_name=log_name,
        log_path=log_path,
        enable_log_file=enable_log_file,
        enable_log_stream=enable_log_stream
    )
    
    # Create an instance of the AI Services Interface
    aihelper_service = AIHelperInterface(
        ai_service_params=ai_service_params,
        log_name=log_name,
        log_path=log_path,
        enable_log_file=enable_log_file,
        enable_log_stream=enable_log_stream,
    )
    
    # Get the vector value for the input_user_query   
    responses = aihelper_service.execute(
        action=AIHelper.Action.EMBEDDING,
        action_params={
            "model": embedding_model,
            "input": input_query,
        }
    )
    async for input_response in responses:
        vector_value = input_response.result
    
    output: StorageResponse = await storage_interface.execute(
        algorithm=Storage.Algorithm.Search.VECTOR_SEARCH,
        algorithm_params={
            "storage_ident": storage_ident,
            "k_top": k_top,
            "return_fields": return_fields,
            "vector_value": vector_value,
            "vector_field": vector_field
        }
    )

    return DataFormatResponse(
        result=output.result,
        additional_data = None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        storage_params=storage_params,
        init_timestamp=init_timestamp,
    )