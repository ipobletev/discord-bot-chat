import copy
from datetime import datetime
import logging
from typing import Optional
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_helper.ai_helper_interface import AIHelperInterface
from wsagent.ai_services.ai_services_enum import AIServices
from wsagent.data_format.schemas.data_format_response import DataFormatResponse
from wsagent.storages.storage_interface import StorageInterface
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse

async def vector_search_llmenrich_nb(
    storage_type: Optional[Storage.Type] = None,
    ai_service_params: Optional[dict] = None,
    algorithm: Optional[Storage.Algorithm.Insert] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log_name: Optional[str] = None,
    log_path: Optional[str] = None,
    enable_log_file: Optional[bool] = False,
    enable_log_stream: Optional[bool] = False,
    log: Optional[logging.Logger] = None
):
    
    init_timestamp=datetime.now().timestamp()
    
    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")
    if storage_type is None: raise ValueError("storage_type must be provided")

    # Get the parameters from the algorithm_params    
    messages = algorithm_params.get('messages', None)
    k_top = algorithm_params.get('k_top', None)
    return_fields = algorithm_params.get('return_fields', None)
    vector_field = algorithm_params.get('vector_field', None)
    tool_enrichment = algorithm_params.get('tool_enrichment', None)
    tool_user_query_field = algorithm_params.get('tool_user_query_field', None)
    llm_model = algorithm_params.get('llm_model', None)
    embedding_model = algorithm_params.get('embedding_model', None)
    k_nb = algorithm_params.get('k_nb', None)
    k_nb_p = algorithm_params.get('k_nb_p', None)
    k_nb_n = algorithm_params.get('k_nb_n', None)
    k_nb_decay = algorithm_params.get('k_nb_decay', None)
    doc_idx_field = algorithm_params.get('doc_idx_field', None)
    doc_idx_size_field = algorithm_params.get('doc_idx_size_field', None)
    # Get the parameters from the storage_params
    storage_ident = storage_params.get('storage_ident', None)
    
    # Check if all the required parameters are provided
    if storage_ident is None: raise ValueError("storage_ident must be provided")
    if storage_type is None: raise ValueError("storage_type must be provided")
    if messages is None: raise ValueError("messages must be provided")
    if tool_enrichment is None: raise ValueError("tool_enrichment must be provided")
    if return_fields is None: raise ValueError("return_fields must be provided")
    if vector_field is None: raise ValueError("vector_field must be provided")
    if tool_user_query_field is None: raise ValueError("tool_user_query_field must be provided")
    if doc_idx_field is None: doc_idx_field = "doc_idx"
    if doc_idx_size_field is None: doc_idx_size_field = "doc_idx_size"
    # Set default values to optional parameters
    if k_top is None: k_top=5
    if llm_model is None: llm_model = AIServices.OpenAI.Feature.LLM.Model.GPT_4_O
    if embedding_model is None: embedding_model = AIServices.OpenAI.Feature.Embeddings.Model.LARGE_V3
    if k_nb is None: k_nb = 3
    if k_nb_p is None: k_nb_p = k_nb
    if k_nb_n is None: k_nb_n = k_nb
    if k_nb_decay is None: k_nb_decay = 0.01

    storage_interface = StorageInterface(
        storage_type=storage_type,
        storage_params=storage_params,
        session_id=None,
        log_name=log_name,
        log_path=log_path,
        enable_log_file=enable_log_file,
        enable_log_stream=enable_log_stream
    )
    
    # Create an instance of the AI Services Interface
    aihelper_service = AIHelperInterface(
        ai_service_params=ai_service_params,
        log_name=log_name,
        log_path=log_path,
        enable_log_file=enable_log_file,
        enable_log_stream=enable_log_stream,
    )

    # Function calling
    responses = aihelper_service.execute(
        action=AIHelper.Action.CHAT,
        action_params={
            "model": llm_model,
            "messages": messages,
            "tools": tool_enrichment,
            "tool_choice": 'required'
        }
    )
    async for llmenrich_response in responses:
        tool_input: dict = llmenrich_response.result[0].get('tool_input')
    
    enrich_query=tool_input.get(tool_user_query_field)
        
    # Get the vector value for the input_user_query   
    responses = aihelper_service.execute(
        action=AIHelper.Action.EMBEDDING,
        action_params={
            "model": embedding_model,
            "input": enrich_query,
        }
    )
    enrich_query_vector=None
    async for enrich_query_response in responses:
        enrich_query_vector = enrich_query_response.result
    
    # Get the documents from the storage    
    content_docs: StorageResponse = await storage_interface.execute(
        algorithm=Storage.Algorithm.Search.VECTOR_SEARCH,
        algorithm_params={
            # "storage_ident": storage_ident,
            "return_fields": None,
            "vector_value": enrich_query_vector,
            "vector_field": vector_field,
            "k_top": k_top
        },
    )    
    log.info(f"content_docs: {content_docs.result}")

    content_docs_result = content_docs.result
    
    #########################################################################################################
    
    # Initialize an empty list to store all neighbours of the current chunk
    all_content_w_neighbours = []
        
    # Neighbourhood processing
    for curr_chunk in content_docs_result:
        
        # Get the current chunk index, size and vector_score
        curr_main_chunk_idx = int(curr_chunk.get(doc_idx_field))
        curr_main_chunk_idx_size = int(curr_chunk.get(doc_idx_size_field))
        main_chunk_vector_score = float(curr_chunk.get('vector_score'))
        main_chunk_ident_nb_key = curr_chunk.get('unique_key')                      # Redis format key to identify the chunk key / same for json and ram
        ident_nb_key = ":".join(main_chunk_ident_nb_key.split(":")[:-1]) # Remove the last part of the key to get the main key
        
        # Set the initial values for the main neighbour
        curr_chunk['nb_score']=main_chunk_vector_score
        curr_chunk['nb_idx']=0
        curr_chunk['base_nb_key']=""
        
        # get the positive neighbours
        negative_neighbours=[]
        for neg_idx in range(k_nb_p):
            curr_nb_idx = curr_main_chunk_idx - k_nb_n + neg_idx
            if curr_nb_idx <= 0:
                continue
            
            # Get the document from the storage    
            unique_key_to_search=f"{ident_nb_key}:{curr_nb_idx}-{curr_main_chunk_idx_size}"
            
            nb_chunk_response: StorageResponse = await storage_interface.execute(
                algorithm=Storage.Algorithm.Search.GET_SPECIFIC_DATA,
                algorithm_params={
                    # "storage_ident": storage_ident,
                    "id_field": "unique_key",
                    "id_value": unique_key_to_search,
                    "return_fields": None,
                },
            )
            neg_nb_chunk_result = copy.deepcopy(nb_chunk_response.result[0])
            neg_abs_nb_idx = (curr_main_chunk_idx - curr_nb_idx)
            neg_penalty_score = k_nb_decay * neg_abs_nb_idx
            # Set the neighbour score and idx
            neg_nb_chunk_result['nb_score']    =   main_chunk_vector_score - neg_penalty_score
            neg_nb_chunk_result['nb_idx']      =   neg_abs_nb_idx  * -1
            neg_nb_chunk_result['base_nb_key'] =   main_chunk_ident_nb_key
            
            negative_neighbours.append(neg_nb_chunk_result)

        # get the positive neighbours
        positive_neighbours=[]
        for pos_idx in range(k_nb_p):
            curr_nb_idx = curr_main_chunk_idx + pos_idx + 1
            if curr_nb_idx > curr_main_chunk_idx_size:
                continue
            
            # Get the document from the storage    
            unique_key_to_search=f"{ident_nb_key}:{curr_nb_idx}-{curr_main_chunk_idx_size}"
            
            pos_chunk_response: StorageResponse = await storage_interface.execute(
                algorithm=Storage.Algorithm.Search.GET_SPECIFIC_DATA,
                algorithm_params={
                    # "storage_ident": storage_ident,
                    "id_field": "unique_key",
                    "id_value": unique_key_to_search,
                    "return_fields": None,
                },
            )
            pos_nb_chunk_result = copy.deepcopy(pos_chunk_response.result[0])
            pos_abs_nb_idx = (curr_nb_idx - curr_main_chunk_idx)
            pos_penalty_score = k_nb_decay * pos_abs_nb_idx
            # Set the neighbour score and idx
            pos_nb_chunk_result['nb_score']    =   main_chunk_vector_score - pos_penalty_score
            pos_nb_chunk_result['nb_idx']      =   pos_abs_nb_idx
            pos_nb_chunk_result['base_nb_key'] =   main_chunk_ident_nb_key
            
            positive_neighbours.append(pos_nb_chunk_result)

        log.info(f"curr_chunk: {curr_chunk}")
        log.info(f"positive_neighbours: {positive_neighbours}")
        log.info(f"negative_neighbours: {negative_neighbours}")
        
        all_current_doc = negative_neighbours + [curr_chunk] + positive_neighbours
        
        log.info(f"all_current_doc: {all_current_doc}")
            
        all_content_w_neighbours.append(all_current_doc)

    log.info(f"all_content_w_neighbours: {all_content_w_neighbours}")

    #########################################################################################################
    
    # Make content_w_neighbours_docs_result to a single list
    list_dict_content_w_neighbours = [doc for sublist in all_content_w_neighbours for doc in sublist]
    
    log.info(f"list_dict_content_w_neighbours: {list_dict_content_w_neighbours}")
    
    # Filter to remove all duplicates, keeping only the document with the highest score among duplicates. If there are N duplicates, the duplicate score should be nb_dupl_score=father_nb_score*(1+N*k_decay)
    # Make nb_dupl_score = nb_score to the no duplilcates elements.
    from collections import defaultdict

    # Create a dictionary to store documents by their unique key. This keep duplicates per unique key list
    doc_dict = defaultdict(list)
    for doc in list_dict_content_w_neighbours:
        doc_dict[doc['unique_key']].append(doc)

    # Filter duplicates and calculate nb_dupl_score
    content_w_neighbours_wout_duplicates = []
    for key, docs in doc_dict.items():
        number_duplicates = len(docs)
        score_doc = docs[0]
        
        if number_duplicates > 1:
            # Keep the document with most recent nb_score
            # Get the father unique_key
            unique_key_to_search=score_doc['base_nb_key']
            father_nb_score=None
            
            # the father content is duplicate
            if unique_key_to_search == "":
                father_nb_score=score_doc['nb_score']
            # the neighbour content is duplicate
            else:
                # Get the father_nb_score from main document score
                for main_doc in content_docs_result:
                    if main_doc['base_nb_key'] == "" and main_doc['unique_key'] == unique_key_to_search:
                        father_nb_score = main_doc['nb_score']
                        break   
            
            # set the nb_dupl_score            
            score_doc['nb_dupl_score'] = float(father_nb_score) * (1 - number_duplicates * k_nb_decay)
        else:
            score_doc['nb_dupl_score'] = float(score_doc['nb_score'])

        content_w_neighbours_wout_duplicates.append(score_doc)
        
    log.info(f"content_w_neighbours_wout_duplicates: {content_w_neighbours_wout_duplicates}")

    # Order content_w_neighbours_wout_duplicates by nb_dupl_score the minor value is the best
    fixed_score_woutdupl_content = sorted(content_w_neighbours_wout_duplicates, key=lambda x: x['nb_dupl_score'], reverse=True)[:k_top]
    
    log.info(f'fixed_score_woutdupl_content: {fixed_score_woutdupl_content}')
    
    #########################################################################################################
    
    # filter return_fields
    if return_fields is not None:
        #filter all_content_w_neighbours
        for content in all_content_w_neighbours:
            for idx, item in enumerate(content):
                filtered_item = {}
                for field in return_fields:
                    nested_keys = field.split('.')
                    value = item
                    for key in nested_keys:
                        value = value.get(key, None)
                        if value is None:
                            break
                    if value is not None:
                        current_dict = filtered_item
                        for key in nested_keys[:-1]:
                            if key not in current_dict:
                                current_dict[key] = {}
                            current_dict = current_dict[key]
                        current_dict[nested_keys[-1]] = value
                content[idx] = filtered_item
        #filter content_w_neighbours_order_per_final_score
        for idx, item in enumerate(fixed_score_woutdupl_content):
            filtered_item = {}
            for field in return_fields:
                nested_keys = field.split('.')
                value = item
                for key in nested_keys:
                    value = value.get(key, None)
                    if value is None:
                        break
                if value is not None:
                    current_dict = filtered_item
                    for key in nested_keys[:-1]:
                        if key not in current_dict:
                            current_dict[key] = {}
                        current_dict = current_dict[key]
                    current_dict[nested_keys[-1]] = value
            fixed_score_woutdupl_content[idx] = filtered_item
            
        #filter content_w_neighbours_order_per_final_score
        for idx, item in enumerate(content_docs_result):
            filtered_item = {}
            for field in return_fields:
                nested_keys = field.split('.')
                value = item
                for key in nested_keys:
                    value = value.get(key, None)
                    if value is None:
                        break
                if value is not None:
                    current_dict = filtered_item
                    for key in nested_keys[:-1]:
                        if key not in current_dict:
                            current_dict[key] = {}
                        current_dict = current_dict[key]
                    current_dict[nested_keys[-1]] = value
            content_docs_result[idx] = filtered_item
            
    return DataFormatResponse(
        result =  all_content_w_neighbours,  # all content per chunk with neighbours 
        additional_data = {
            "tool_input": tool_input,
            "main_content_docs": content_docs_result,
            "fixed_score_woutdupl_content": fixed_score_woutdupl_content # only the best scores with a fixed score by number of duplicates
        },
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        storage_params=storage_params,
        init_timestamp=init_timestamp,
    )