from datetime import datetime
import logging
from typing import Optional
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_helper.ai_helper_interface import AIHelperInterface
from wsagent.ai_services.ai_services_enum import AIServices
from wsagent.ai_services.ai_services_interface import AIServicesInterface
from wsagent.data_format.schemas.data_format_response import DataFormatResponse
from wsagent.storages.storage_interface import StorageInterface
from wsagent.storages.storages_enum import Storage
from wsagent.storages.schemas.storage_response import StorageResponse

async def vector_search_llmenrich(
    storage_type: Optional[Storage.Type] = None,
    ai_service_params: Optional[dict] = None,
    algorithm: Optional[Storage.Algorithm.Insert] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log_name: Optional[str] = None,
    log_path: Optional[str] = None,
    enable_log_file: Optional[bool] = False,
    enable_log_stream: Optional[bool] = False,
    log: Optional[logging.Logger] = None
):
    
    init_timestamp=datetime.now().timestamp()
    
    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")
    if storage_type is None: raise ValueError("storage_type must be provided")

    # Get the parameters from the algorithm_params
    messages = algorithm_params.get('messages', None)
    k_top = algorithm_params.get('k_top', None)
    return_fields = algorithm_params.get('return_fields', None)
    vector_field = algorithm_params.get('vector_field', 'vector')
    tool_enrichment = algorithm_params.get('tool_enrichment', None)
    tool_user_query_field = algorithm_params.get('tool_user_query_field', None)
    llm_model = algorithm_params.get('llm_model', None)
    embedding_model = algorithm_params.get('embedding_model', None)
    # Get the parameters from the storage_params
    storage_ident = storage_params.get('storage_ident', None)
    
    # Check if all the required parameters are provided and set default to optional parameters
    if storage_ident is None: raise ValueError("storage_ident must be provided")
    if storage_type is None: raise ValueError("storage_type must be provided")
    if messages is None: raise ValueError("messages must be provided")
    if tool_enrichment is None: raise ValueError("tool_enrichment must be provided")
    if return_fields is None: raise ValueError("return_fields must be provided")
    if vector_field is None: raise ValueError("vector_field must be provided")
    if tool_user_query_field is None: raise ValueError("tool_user_query_field must be provided")
    # Set default values
    if k_top is None: k_top=5
    if llm_model is None: llm_model = AIServices.OpenAI.Feature.LLM.Model.GPT_4_O
    if embedding_model is None: embedding_model = AIServices.OpenAI.Feature.Embeddings.Model.LARGE_V3

    storage_interface = StorageInterface(
        storage_type=storage_type,
        storage_params=storage_params,
        session_id=None,
        log_name=log_name,
        log_path=log_path,
        enable_log_file=enable_log_file,
        enable_log_stream=enable_log_stream
    )
    
    # Create an instance of the AI Services Interface
    aihelper_service = AIHelperInterface(
        ai_service_params=ai_service_params,
        log_name=log_name,
        log_path=log_path,
        enable_log_file=enable_log_file,
        enable_log_stream=enable_log_stream,
    )

    # Function calling
    responses = aihelper_service.execute(
        action=AIHelper.Action.CHAT,
        action_params={
            "model": llm_model,
            "messages": messages,
            "tools": tool_enrichment,
            "tool_choice": 'required'
        }
    )
    async for llmenrich_response in responses:
        tool_input: dict = llmenrich_response.result[0].get('tool_input')
    
    enrich_query=tool_input.get(tool_user_query_field)
        
    # Get the vector value for the input_user_query   
    responses = aihelper_service.execute(
        action=AIHelper.Action.EMBEDDING,
        action_params={
            "model": embedding_model,
            "input": enrich_query,
        }
    )
    async for enrich_query_response in responses:
        enrich_query_vector = enrich_query_response.result
    
    # Get the documents from the storage    
    content_docs_response: StorageResponse = await storage_interface.execute(
        algorithm=Storage.Algorithm.Search.VECTOR_SEARCH,
        algorithm_params={
            "storage_ident": storage_ident,
            "return_fields": None,
            "vector_value": enrich_query_vector,
            "vector_field": vector_field,
            "k_top": k_top
        },
    )
    content_docs_result = content_docs_response.result
    
    log.info(f"content_docs_result: {content_docs_result}")
        
    # Get vector_score for content_docs_result to calculate and add the final_score
    for data in content_docs_result:  data['final_score'] = float(data['vector_score'])

    log.info(f"content_docs_result: {content_docs_result}")

    # order the knowledge by final_score
    out_docs = sorted(content_docs_result, key=lambda x: x['final_score'], reverse=False)
    
    #filter the knowledge by k_top
    out_docs = out_docs[:k_top]
    
    # filter return_fields
    if return_fields is not None:
        for idx, item in enumerate(out_docs):
            filtered_item = {}
            for field in return_fields:
                nested_keys = field.split('.')
                value = item
                for key in nested_keys:
                    value = value.get(key, None)
                    if value is None:
                        break
                if value is not None:
                    current_dict = filtered_item
                    for key in nested_keys[:-1]:
                        if key not in current_dict:
                            current_dict[key] = {}
                        current_dict = current_dict[key]
                    current_dict[nested_keys[-1]] = value
            out_docs[idx] = filtered_item

    return DataFormatResponse(
        result=out_docs,
        additional_data = {
            "tool_input": tool_input
        },
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        storage_params=storage_params,
        init_timestamp=init_timestamp,
    )