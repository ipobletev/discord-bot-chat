from datetime import datetime
import logging
from typing import Optional
import uuid
from wsagent.data_format.schemas.data_format_response import DataFormatResponse
from wsagent.storages.schemas.storage_response import StorageResponse
from wsagent.storages.storage_interface import StorageInterface
from wsagent.storages.storages_enum import Storage

async def file_chunk(
    storage_type: Optional[Storage.Type] = None,
    ai_service_params: Optional[dict] = None,
    algorithm: Optional[Storage.Algorithm.Insert] = None,
    algorithm_params: Optional[dict] = None,
    storage_params: Optional[dict]=None,
    log_name: Optional[str] = None,
    log_path: Optional[str] = None,
    enable_log_file: Optional[bool] = False,
    enable_log_stream: Optional[bool] = False,
    log: Optional[logging.Logger] = None
):
    
    init_timestamp=datetime.now().timestamp()
    
    if algorithm is None: raise ValueError("algorithm must be provided")
    if log is None: log=logging.getLogger(__name__)
    if algorithm_params is None: algorithm_params={}
    if storage_params is None: raise ValueError("storage_params must be provided")
    if storage_type is None: raise ValueError("storage_type must be provided")
    
    # Get parameters from the algorithm_params
    list_data = algorithm_params.get('data', None)
    unique_key = algorithm_params.get('unique_key', None)
    storage_ident = algorithm_params.get('storage_ident', None)
    # Get parameters from the storage_params
    storage_name = storage_params.get('storage_name', None)
    if storage_ident is None: storage_ident = storage_params.get('storage_ident', None)
    
    # Check if all the required parameters are provided
    if storage_ident is None: raise ValueError("storage_ident must be provided")
    if storage_name is None: raise ValueError("storage_name must be provided")
    if list_data is None: raise ValueError("list_data must be provided")
    # Default values
    if unique_key is None: unique_key = f'{storage_name}:{uuid.uuid4()}'
    
    storage_interface = StorageInterface(
        storage_type=storage_type,
        storage_params=storage_params,
        session_id=None,
        log_name=log_name,
        log_path=log_path,
        enable_log_file=enable_log_file,
        enable_log_stream=enable_log_stream
    )
    
    nb_idx_size= len(list_data)
    
    ref_unique_key = unique_key
    for idx, data in enumerate(list_data):
        
        # Add fields to data json to format neightbour file compatibility
        nb_idx= idx + 1
        data['doc_idx']= nb_idx
        data['doc_idx_size'] = nb_idx_size
        unique_key = f'{ref_unique_key}:{nb_idx}-{nb_idx_size}'
        
        # Insert the data into the storage
        response: StorageResponse = await storage_interface.execute(
            algorithm=Storage.Algorithm.Insert.DEFAULT,
            algorithm_params={
                "unique_key": unique_key,
                'data': data
            }
        )

    return DataFormatResponse(
        result=response.result,
        additional_data=None,
        algorithm=algorithm,
        algorithm_params=algorithm_params,
        storage_params=storage_params,
        init_timestamp=init_timestamp,
    )