from wsagent.data_format.algorithms.insert_algorithm.type.default.insert_default import insert_default
from wsagent.data_format.algorithms.insert_algorithm.type.file_chunk.file_chunk import file_chunk
from wsagent.data_format.algorithms.search_algorithm.type.raw_search.raw_search import raw_search
from wsagent.data_format.algorithms.search_algorithm.type.get_specific_data.get_specific_data import get_specific_data
from wsagent.data_format.algorithms.search_algorithm.type.last_element.last_element import last_elements
from wsagent.data_format.algorithms.search_algorithm.type.vector_search.vector_search import vector_search
from wsagent.data_format.algorithms.search_algorithm.type.hybrid_search.hybrid_search import hybrid_search
from wsagent.data_format.algorithms.search_algorithm.type.vector_search_llmenrich.vector_search_llmenrich import vector_search_llmenrich
from wsagent.data_format.algorithms.search_algorithm.type.hybrid_search_llmenrich.hybrid_search_llmenrich import hybrid_search_llmenrich
from wsagent.data_format.algorithms.search_algorithm.type.vector_search_llmenrich_nb.vector_search_llmenrich_nb import vector_search_llmenrich_nb
from wsagent.data_format.algorithms.search_algorithm.type.hybrid_search_llmenrich_nb.hybrid_search_llmenrich_nb import hybrid_search_llmenrich_nb
from wsagent.data_format.data_format_enum import DataFormat

dataformat_algorithm_function_map = {
    # Insert algorithms
    DataFormat.Algorithm.Insert.DEFAULT: insert_default,
    DataFormat.Algorithm.Insert.FILE_CHUNK: file_chunk,
    # Search algorithms
    DataFormat.Algorithm.Search.RAW_SEARCH: raw_search,
    DataFormat.Algorithm.Search.GET_SPECIFIC_DATA: get_specific_data,
    DataFormat.Algorithm.Search.LAST_ELEMENTS: last_elements,
    DataFormat.Algorithm.Search.HYBRID_SEARCH: hybrid_search,
    DataFormat.Algorithm.Search.VECTOR_SEARCH: vector_search,
    DataFormat.Algorithm.Search.VECTOR_SEARCH_LLMENRICH: vector_search_llmenrich,
    DataFormat.Algorithm.Search.HYBRID_SEARCH_LLMENRICH: hybrid_search_llmenrich,
    DataFormat.Algorithm.Search.VECTOR_SEARCH_LLMENRICH_NB: vector_search_llmenrich_nb,
    DataFormat.Algorithm.Search.HYBRID_SEARCH_LLMENRICH_NB: hybrid_search_llmenrich_nb,
}