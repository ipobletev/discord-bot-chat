import asyncio
from typing import Optional, Union
import uuid
from wsagent.data_format.schemas.data_format_response import DataFormatResponse
from wsagent.storages.storage_interface import StorageInterface
from wsagent.storages.storages_enum import Storage
from wsagent.data_format.algorithms.algorithm_mapping import dataformat_algorithm_function_map
from wsagent.utils.logs import PrintAndLog

class DataFormatInterface:
    """   
    ### Brief

    class manage a storage type with multiples algorithms to execute. 
    See DataFormat enums class (wsagent/data_format/data_format.py)
    
    ### Parameters of storage_params
    - "ai_service_params": "dict: AI services api key parameters to use in the storage."
    - "storage_name": "str: Storage name to use like defaults name and logs."
    - "storage_ident": "str:  Storage identity to initialize the storage. 
        - LocalRam can use it like a external ram list.
        - LocalJson use the path to output file.
        - Redis is a index name. 
    - "storage_struc": "method: Data input arguments and return json structure to use in the storage."
    - ... (others_parameters by storage)

    ### Init example to use:
    #### Ram storage:
    ```
    data_fmt = DataFormatInterface(
        storage_type=Storage.Type.LOCAL_RAM,
        storage_params={
            "storage_name": "ram_storage",
            "storage_struc": data_item_func,
            "storage_ident": storage_ident,
        },   
        ai_service_params={
            "openai_api_key": OPENAI_API_KEY,
            "groq_api_key": GROQ_API_KEY,
            "anthropic_api_key": ANTHROPIC_API_KEY,
        }
    )
    ```
    #### Json storage:
    ```
    data_fmt = DataFormatInterface(
        storage_type=Storage.Type.LOCAL_JSON,
        storage_params={
            "storage_name": "json_storage",
            "storage_struc": data_item_func,
            "storage_ident": storage_ident,
        },   
        ai_service_params={
            "openai_api_key": OPENAI_API_KEY,
            "groq_api_key": GROQ_API_KEY,
            "anthropic_api_key": ANTHROPIC_API_KEY,
        }
    )
    ```
    #### Redis storage:
    ```
    data_fmt = DataFormatInterface(
        storage_type=Storage.Type.REDIS,
        storage_params={
            # Redis connection parameters
            "host": "localhost",
            "password": REDIS_PASS,
            "port": 6379,
            "db": 0,
            # Redis index configuration
            "storage_struc": data_item_func,
            "storage_name": storage_prefix_name,
            "storage_ident": storage_ident,
            # "index_schema": [RedisSchema], # auto generate schema by data_item_func
            # "index_schema_config": {
            #     "vector_dim": 3072,
            #     "vector_distance_metric": "COSINE",
            #     "vector_type": "FLOAT32"
            # },
            "prefix": [storage_prefix_name],
            # Redis key uuid generation
            # "use_id_from_data": False,
            # "key_id_field": None
        },
        ai_service_params={
            "openai_api_key": OPENAI_API_KEY,
            "groq_api_key": GROQ_API_KEY,
            "anthropic_api_key": ANTHROPIC_API_KEY,
        }
    )
    ```
    """

    def __init__(self, 
        ai_service_params: Optional[dict]=None,
        storage_type: Optional[Storage.Type]=None,
        storage_params: Optional[dict]=None,
        session_id: Optional[str]=None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ):
        # Get storage parameters
        storage_name=storage_params.get('storage_name', None)
        
        # Check if all required parameters are provided
        if storage_type is None: raise ValueError("storage_type must be provided")
        if storage_name is None: raise ValueError("storage_name must be provided")
        
        # Set default values
        if storage_params is None: storage_params={}
        
        self.storage_type=storage_type
        self.storage_params=storage_params
        self.ai_service_params=ai_service_params

        if session_id:
            self.log_name = f'{log_name}.{session_id}'
            self.log_path = f'{log_path}/{session_id}'
        else:
            self.log_name=f'{log_name}'
            self.log_path=f'{log_path}'
        
        self.enable_log_file=enable_log_file
        self.enable_log_stream=enable_log_stream
        self._storage_name=storage_name 
        self._storage_type=storage_type 
        self.session_id = session_id
        
    @property
    def storage_name(self) -> Optional[str]:
        """Gets the agent's name."""
        return self._storage_name

    @property   
    def type(self) -> Optional[str]:
        """Gets the agent's type name."""
        return self._storage_type

    async def execute(self,
        algorithm: Optional[Union[Storage.Algorithm.Insert,Storage.Algorithm.Search]] = None,
        algorithm_params: Optional[dict] = None,
    ) -> DataFormatResponse:
        
        execution_id = str(uuid.uuid4())[:8]
        log_name=f'{self.log_name}.{execution_id}.df'
        log_path=f'{self.log_path}/{execution_id}/df'
        
        function_to_call = dataformat_algorithm_function_map.get(algorithm)
        if function_to_call == None:
            raise ValueError(f"Function to call not found: {algorithm}")
            
        # Check if function_to_call is a coroutine function
        output = None
        if asyncio.iscoroutinefunction(function_to_call):
            output = await function_to_call( 
                storage_type=self.storage_type,
                ai_service_params=self.ai_service_params,
                algorithm=algorithm,
                algorithm_params=algorithm_params,
                storage_params=self.storage_params,
                log_name=log_name,
                log_path=log_path,
                enable_log_file=self.enable_log_file,
                enable_log_stream=self.enable_log_stream)
        else:
            # Execute synchronously if it's not a coroutine
            output = function_to_call( 
                storage_type=self.storage_type,
                ai_service_params=self.ai_service_params,
                algorithm=algorithm,
                algorithm_params=algorithm_params,
                storage_params=self.storage_params,
                log_name=log_name,
                log_path=log_path,
                enable_log_file=self.enable_log_file,
                enable_log_stream=self.enable_log_stream)
        return output