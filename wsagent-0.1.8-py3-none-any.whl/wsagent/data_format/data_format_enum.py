from enum import Enum, auto

# Master Storage definitions
class DataFormat:

    class Type(Enum):
        REDIS = auto()
        """
        ### Brief

        Redis storage type.
        
        ### Parameters of storage_params
        - "host": "str: Redis host to connect."
        - "password": "str: Redis password to connect."
        - "port": "int: Redis port to connect."
        - "db": "int: Redis db to connect."
        - "storage_name": "str: Index name to create the storage, used in log and internal names. "
        - "storage_ident": "str: Index name to create the storage. "
        - "index_schema": "list: Redis Index schema to create the index."
        - "index_schema_config": "dict: Index schema configuration."
        - "prefix": "list: Prefix tag of default data."
        - "use_id_from_data": "bool: If True, use the data to get the key id in field "key_id_field" . If False, use a random uuid to generate a key name id."
        - "key_id_field": "str or None: Use with 'use_id_from_data' to get a uuid name in insert methods to name the key of data."
        
        ### Algorithm parameters to use:
        ```

        storage_params={
            # Redis connection parameters
            "host": "localhost",
            "password": "",
            "port": 6379,
            "db": 0,
            # Redis index configuration
            "storage_name": "redis_idx",
            "storage_ident": "redis_idx",
            "index_schema": [RedisSchema], # if not use it is auto generate schema by storage_struc param
            "index_schema_config": {
                "vector_dim": 3072,
                "vector_distance_metric": "COSINE",
                "vector_type": "FLOAT32"
            },
            "prefix": ['prefix_name'],
            # Redis key uuid generation
            "use_id_from_data": False,
            "key_id_field": None
        }
        ```
        """
        LOCAL_JSON = auto()
        
        """
        ### Brief

        Json storage type.
        
        ### Parameters of storage_params
        - "storage_name": "str: storage name to use with autogen unique_key and log folders."
        - "storage_ident": "Identity str url_path to create the json file storage"
        
        ### Algorithm parameters to use:
        ```    
        storage_params={
            "storage_name": "json_storage",
            "storage_ident": ".data/local_json/data.json",
        }
        ```
        """
        LOCAL_RAM = auto()
        
        """
        ### Brief

        Ram storage type.
        
        ### Parameters of storage_params
        - "storage_name": "str: storage name to use with autogen unique_key and log folders."
        - "storage_ident": "Identity list to create the external ram storage for multi user persistant data."
        
        ### Algorithm parameters to use:
        ```
        local_ram_storage=[ ]
        
        storage_params={
            "storage_name": "json_storage",
            "storage_ident": ".data/local_json/data.json",
        }
        ```
        """

    class Algorithm:
        class Search(Enum):
            RAW_SEARCH = auto()
            """
            ### Brief

            Raw search specific by storage type. Only in Redis Storage is implemented.
            
            ### Parameters of storage_params
            **** Storage parameters ****
            
            ### Example to use:
            ```
            response: DataFormatResponse = await data_fmt.execute(
                algorithm= DFStorage.Algorithm.Search.RAW_SEARCH,
                algorithm_params = {
                    **** others paramethers ****
                }
            )
            ```
            """
            
            GET_SPECIFIC_DATA = auto()
            """
            ### Brief

            Get especific data from the fiel 'data_field' storage.
            
            ### Parameters of storage_params
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "id_field": " Get the Id in this field. This not is required in DBs like redis."
            - "id_value": "str: Id of the data to get."
            - "return_fields": "List[str]: of fields to return."
            
            ### Example to use:
            ```
            response = await data_fmt.execute(
                algorithm= DataFormat.Algorithm.Search.GET_SPECIFIC_DATA,
                algorithm_params = {
                    # "storage_ident": storage_ident, # Optional if not use. Default value is storage_ident from storage_params
                    "id_field": "unique_key", # redis not used this
                    "id_value": f"{storage_name}:{uuid}",
                    "return_fields": ['title','id','uuid'],
                }
            )
            ```
            """
            
            LAST_ELEMENTS = auto()
            """
            ### Brief

            Search and sort element in numeric field "sort_by". 
            
            ### Parameters of storage_params
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "sort_by": "str: Field to sort the results."
            - "sort_order_asc": "bool: Order of the sort. False for descending, True for ascending."
            
            ### Example to use:
            ```
            response = await data_fmt.execute(
                algorithm= DataFormat.Algorithm.Search.LAST_ELEMENTS,
                algorithm_params = {
                    # "storage_ident": storage_ident
                    "k_top": 2,
                    "return_fields": ['title','id','uuid', "timestamp"],
                    "sort_by": "timestamp",
                    "sort_order_asc": True
                }
            )
            ```
            """
            
            VECTOR_SEARCH = auto()
            """
            ### Brief

            Vector search element with a vector_value in vector_field.
            
            ### Parameters of storage_params
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "input_query": "str: Text to get embedding and search vector in storage."
            - "vector_field": "str: Field to search the vector."
            - "embedding_model": "str: OpenAI model to use."
            
            ### Example to use:
            ```
            response = await data_fmt.execute(
                algorithm= DataFormat.Algorithm.Search.VECTOR_SEARCH,
                algorithm_params = {
                    # AI Service parameters
                    "embedding_model": AIHelper.Models.OpenAI.Embedding.LARGE_V3,
                    # Storage parameters
                    # "storage_ident": storage_ident
                    "k_top": 2,
                    "return_fields": ['title','id','uuid', "timestamp", 'vector_score'],
                    "input_query": input_query,
                    "vector_field": "content_vector"
                }
            )
            ```
            """
            
            HYBRID_SEARCH = auto()
            """
            ### Brief

            Hybrid search element with a vector and text search.
            
            ### Parameters of storage_params
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "input_query": "str: Text to get embedding and search vector in storage."
            - "vector_field": "str: Field to search the vector."
            - "text_search_value": "str: Text to search in storage."
            - "text_search_field": "str: Field to search the text."
            - "k_sim": "float: Weight of the similarity text. Redis Storage not use this parameter."
            - "k_sem": "float: Weight of the semantic vector. Redis Storage not use this parameter."
            - "embedding_model": "str: OpenAI model to use."
            
            ### Example to use:
            ```
            response = await data_fmt.execute(
                algorithm= DataFormat.Algorithm.Search.HYBRID_SEARCH,
                algorithm_params = {
                    # AI Service parameters
                    "embedding_model": AIHelper.Models.OpenAI.Embedding.LARGE_V3,
                    # Storage parameters
                    # "storage_ident": storage_ident
                    "k_top": 2,
                    "return_fields": ['title','id','uuid', "timestamp", 'text_score','vector_score', 'final_score'],
                    "input_query": input_query,
                    "vector_field": "content_vector",
                    "text_search_value": "game",
                    "text_search_field": "content",
                    "k_sim": 0.3,
                    "k_sem": 0.7
                }
            )
            ```
            """
            
            VECTOR_SEARCH_LLMENRICH = auto()
            """
            ### Brief

            Hybrid search element with a vector and text search.
            
            ### Parameters of storage_params
            
            #### AI Service parameters:
            - "embedding_model": "str: OpenAI model to use."
            - "llm_model": "str: OpenAI model to use."
            - "messages": "list: List of messages to make the prompt to send to the model for enrich user query."
            - "tool_enrichment": "Dict: Tool enrichment to use in the model."
            - "tool_user_query_field": "str: Field to get the new query enrich from tool_enrichment."
            #### Storage parameters:
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "vector_field": "str: Field to search the vector."
            
            - "text_search_field": "str: Field to search the text."

            ### Example to use:
            ```
            response = await data_fmt.execute(
                algorithm= DataFormat.Algorithm.Search.VECTOR_SEARCH_LLMENRICH,
                algorithm_params = {
                    # AI Service parameters
                    "llm_model": AIHelper.Models.OpenAI.Chat.GPT_4_O,
                    "embedding_model": AIHelper.Models.OpenAI.Embedding.LARGE_V3,
                    "messages": messages,
                    "tool_enrichment": TOOLS_VECTOR_SEARCH,
                    "tool_user_query_field": "new_query", # output field from tool_enrichment
                    # Storage parameters
                    # "storage_ident": storage_ident
                    "k_top": 5,
                    "return_fields": ['title','id','uuid', "timestamp", 'vector_score'],
                    "vector_field": "content_vector",
                }
            )
            ```
            """

            HYBRID_SEARCH_LLMENRICH = auto()
            """
            ### Brief

            Hybrid search element with a vector and text search.
            
            ### Parameters of storage_params
            
            #### AI Service parameters:
            - "llm_model": "str: OpenAI LLM model to use."
            - "embedding_model": "str: OpenAI Embeddings model to use in value of 'tool_user_query_field' like "new_query"."
            - "messages": "list: List of messages to make the prompt to send to the model for enrich user query."
            - "tool_enrichment": "Dict: Tool enrichment to use in the model."
            - "tool_user_query_field": "str: Field to get the new query enrich."
            - "tool_text_search_field": "str: Field to get the text search."
            #### Storage parameters:
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "vector_field": "str: Field to search the vector."
            - "text_search_field": "str: Field to search the text."
            - "k_sim": "float: Weight of the similarity text. Redis Storage not use this parameter."
            - "k_sem": "float: Weight of the semantic vector. Redis Storage not use this parameter."

            ### Example to use:
            ```
            response = await data_fmt.execute(
                algorithm= DataFormat.Algorithm.Search.HYBRID_SEARCH_LLMENRICH,
                algorithm_params = {
                    # AI Service parameters
                    "llm_model": AIHelper.Models.OpenAI.Chat.GPT_4_O,
                    "embedding_model": AIHelper.Models.OpenAI.Embedding.LARGE_V3,
                    "messages": messages,
                    "tool_enrichment": TOOLS_HYBRID_SEARCH,
                    "tool_user_query_field": "new_query", # output field from tool_enrichment
                    "tool_text_search_field": "text_value", # output field from tool_enrichment
                    # Storage parameters
                    # "storage_ident": storage_ident
                    "k_top": 5,
                    "return_fields": ['title','id','uuid', "timestamp", 'text_score','vector_score', 'final_score'],            
                    "vector_field": "content_vector",
                    "text_search_field": "content",
                    "k_sim": 0.3,
                    "k_sem": 0.7
                }
            )
            ```
            """

            VECTOR_SEARCH_LLMENRICH_NB = auto()
            """
            ### Brief

            Hybrid search element with a vector and text search.
            
            ### Parameters of storage_params
            
            #### AI Service parameters:
            - "llm_model": "str: OpenAI model to use."
            - "messages": "list: List of messages to make the prompt to send to the model for enrich user query."
            - "tool_enrichment": "Dict: Tool enrichment to use in the model."
            - "tool_user_query_field": "str: Field to get the new query enrich from tool_enrichment."
            - "tool_text_search_field": "str: Field to get the text search."
            #### Storage parameters:
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "vector_field": "str: Field to search the vector."
            - "text_search_field": "str: Field to search the text."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "k_sim": "float: Weight of the similarity text. Redis Storage not use this parameter."
            - "k_sem": "float: Weight of the semantic vector. Redis Storage not use this parameter."
            - "k_nb": "int: Number of elements to search in the text search."
            - "k_decay": "float: Decay of the text search. Redis Storage not use this parameter.

            ### Example to use:
            ```
            response = await data_fmt.execute(
                algorithm= DataFormat.Algorithm.Search.VECTOR_SEARCH_LLMENRICH_NB,
                algorithm_params = {
                    # AI Service parameters
                    "llm_model": AIHelper.Models.OpenAI.Chat.GPT_4_O,
                    "embedding_model": AIHelper.Models.OpenAI.Embedding.LARGE_V3,
                    "messages": messages,
                    "tool_enrichment": TOOLS_VECTOR_SEARCH,
                    "tool_user_query_field": "new_query", # output field from tool_enrichment
                    "tool_text_search_field": "text_value", # output field from tool_enrichment
                    # Storage parameters
                    # "storage_ident": storage_ident
                    "return_fields": ['title','id','uuid', "timestamp", 'nb_dupl_score'],
                    "vector_field": "content_vector",
                    "text_search_field": "content",
                    "k_top": 5,
                    "k_sim": 0.3,
                    "k_sem": 0.7,
                    "k_nb": 3,
                    #"k_decay": 0.01
                }
            )
            ```
            """

            HYBRID_SEARCH_LLMENRICH_NB = auto()
            """
            ### Brief

            Hybrid search element with a vector and text search.
            
            ### Parameters of storage_params
            
            #### AI Service parameters:
            - "llm_model": "str: OpenAI model to use."
            - "messages": "list: List of messages to make the prompt to send to the model for enrich user query."
            - "tool_enrichment": "Dict: Tool enrichment to use in the model."
            - "tool_user_query_field": "str: Field to get the new query enrich from tool_enrichment."
            - "tool_text_search_field": "str: Field to get the text search."
            #### Storage parameters:
            - "storage_ident": "Identity to search the last elements. Default is storage_params['storage_ident'] value" "
            - "return_fields": "List[str]: of fields to return."
            - "vector_field": "str: Field to search the vector."
            - "text_search_field": "str: Field to search the text."
            - "k_top": "int: Number of elements more significative to retrieve."
            - "k_sim": "float: Weight of the similarity text. Redis Storage not use this parameter."
            - "k_sem": "float: Weight of the semantic vector. Redis Storage not use this parameter."
            - "k_nb": "int: Number of elements to search in the text search."
            - "k_decay": "float: Decay of the text search. Redis Storage not use this parameter.

            ### Example to use:
            ```
            response = await data_fmt.execute(
                algorithm= DataFormat.Algorithm.Search.HYBRID_SEARCH_LLMENRICH_NB,
                algorithm_params = {
                    # AI Service parameters
                    "llm_model": AIHelper.Models.OpenAI.Chat.GPT_4_O,
                    "embedding_model": AIHelper.Models.OpenAI.Embedding.LARGE_V3,
                    "messages": messages,
                    "tool_enrichment": TOOLS_HYBRID_SEARCH,
                    "tool_user_query_field": "new_query", # output field from tool_enrichment
                    "tool_text_search_field": "text_value", # output field from tool_enrichment
                    # Storage parameters
                    # "storage_ident": storage_ident
                    "return_fields": ['title','id','uuid', "timestamp", 'vector_score', 'text_score', 'final_score'],
                    "vector_field": "title_vector",
                    "text_search_field": "content",
                    "k_top": 5,
                    "k_sim": 0.3,
                    "k_sem": 0.7,
                    "k_nb": 3,
                    #"k_decay": 0.01
                }
            )
            ```
            """
            
        class Insert(Enum):
            DEFAULT = auto()
            """
            ### Brief

            Insert data to the storage identity.
            
            ### Parameters
            
            - "data": "dict data to insert." This follow the "storage_struc" data structure from "storage_params".
            - "unique_key": "str: prefix of the final unique_key"
            - "storage_ident": "Identity to insert the data."
                - LocalRam can use it like a external ram list.
                - LocalJson use the path to output file.
                - Redis is string index name.
            
            ### Example to use:
            ```
            response = await data_fmt.execute(
                algorithm= DataFormat.Algorithm.Insert.DEFAULT,
                algorithm_params = {
                    # "storage_ident": storage_ident,                   # Optional if not use. Default value is storage_ident from storage_params
                    # "unique_key": f'ram_storage:{element["uuid"]}',   # Optional if not use. Default value is auto generate a unique key = f'{storage_name}:{uuid.uuid4()}'
                    "data": {"key": "value"},                           # Required. 
                }
            )
            ```
            """

            FILE_CHUNK = auto()
            """
            ### Brief

            Insert a File representation list of data to the storage identity with neighbour format.
            
            ### Parameters
            
            - "data": "list of dict data to insert." This data follow the "storage_struc" data structure from "storage_params".
            - "unique_key": "str: prefix of the final unique_key"
            - "storage_ident": "Identity to insert the data."
                - LocalRam can use it like a external ram list.
                - LocalJson use the path to output file.
                - Redis is string index name.
            
            ### Example to use:
            ```
            response = await data_fmt.execute(
                algorithm= DataFormat.Algorithm.Insert.DEFAULT,
                algorithm_params = {
                    # "storage_ident": storage_ident,                   # Optional if not use. Default value is storage_ident from storage_params
                    # "unique_key": f'ram_storage:{element["uuid"]}',   # Optional if not use. Default value is auto generate a unique key = f'{storage_name}:{uuid.uuid4()}'
                    "data": [{"key": "value"},{"key": "value"}],        # Required. 
                }
            )
            ```
            """

    @classmethod
    def list_type_storages(cls):
        return [action.name for action in cls.Type]
    
    @classmethod
    def list_search_algorithms(cls):
        return [action.name for action in cls.Algorithm.Search]

    @classmethod
    def list_insert_algorithms(cls):
        return [action.name for action in cls.Algorithm.Insert]