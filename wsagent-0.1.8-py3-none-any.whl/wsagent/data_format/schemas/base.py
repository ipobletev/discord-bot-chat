from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Optional, Union
from wsagent.utils.validate_args import validate_required_args

class SchemaDataFormatResponse(ABC):
    """
    Base class for all response schema in the application.
    Provides common attributes and methods that are inherited by derived classes.
    """
    @validate_required_args
    def __init__(self,
        result: Any = None,
        additional_data: Any = None,
        algorithm: Enum = None,
        algorithm_params: dict = None,
        storage_params: dict= None,
        init_timestamp: Optional[Union[float,int]] = None,
    ):
        self.algorithm=algorithm
        self.algorithm_params=algorithm_params
        self.storage_params=storage_params
        self.init_timestamp=init_timestamp
        self.result=result
        self.additional_data=additional_data
        self.time_exec=0

        if algorithm is None: raise ValueError("algorithm must be provided")
        if algorithm_params is None: algorithm_params={}
        if storage_params is None: raise ValueError("storage_params must be provided")
        if init_timestamp is None: raise ValueError("init_timestamp is required")
        if result is None: raise ValueError("result is required")
        
    @abstractmethod
    def to_json(self):
        """
        Convert properties of the class instance into a dictionary.
        This method should be overridden by subclasses if they have properties.
        """
        pass

