from enum import Enum
import time
from typing import Any, Optional, Union
from .base import SchemaDataFormatResponse
from wsagent.utils.validate_args import validate_required_args
from typing import Any, Optional, Union

class DataFormatResponse(SchemaDataFormatResponse):
    @validate_required_args
    def __init__(self,
        result: Any,
        additional_data: Any,
        algorithm: Enum,
        algorithm_params: dict,
        storage_params: dict,
        init_timestamp: Optional[Union[float,int]] = None,
    ):
        
        super().__init__(
            result=result,
            additional_data=additional_data,
            algorithm=algorithm,
            algorithm_params=algorithm_params,
            storage_params=storage_params,
            init_timestamp=init_timestamp
        )
        
        if init_timestamp is None: raise ValueError("init_timestamp is required")
        if result is None: raise ValueError("result is required")
        
        self.init_timestamp=init_timestamp
        self.time_exec=time.time() - init_timestamp
    
    def to_json(self):
        def serialize(obj):
            if hasattr(obj, "to_dict"):
                return obj.to_dict()
            elif isinstance(obj, list):
                return [serialize(item) for item in obj]
            elif isinstance(obj, dict):
                return {key: serialize(value) for key, value in obj.items()}
            elif isinstance(obj, (int, float, str, bool, type(None))):  # check for basic types
                return obj
            else:
                return str(obj)  # default to string for any other types that are not recognized

        return {key: serialize(value) for key, value in self.__dict__.items()}