def math_normalize(scores, min_val=0.0, max_val=1.0, reverse=False):
    min_score = min(scores)
    max_score = max(scores)
    
    # Avoid division by zero
    if max_score - min_score == 0:
        return [min_val if not reverse else max_val for score in scores]
    
    # Normalize from 0 to 1
    normalized_scores = [(score - min_score) / (max_score - min_score) for score in scores]
    
    # Scale to the range [min_val, max_val]
    scaled_scores = [min_val + score * (max_val - min_val) for score in normalized_scores]
    
    # Reverse the scores if reverse is True
    if reverse:
        scaled_scores = [max_val - (score - min_val) for score in scaled_scores]
    
    return scaled_scores