import functools
import inspect
from typing import Any, Callable, List, TypeVar, get_args, get_type_hints, Union, get_origin
from enum import Enum

def validate_required_args(func: Callable) -> Callable:
    """
    Decorator to validate the input arguments of an async method.
    """
    if inspect.iscoroutinefunction(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            return await _validate_and_call(func, *args, **kwargs)
    else:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return _validate_and_call(func, *args, **kwargs)
    
    return wrapper

def is_generic_var(typ):
    """ Check if `typ` is a TypeVar. """
    return isinstance(typ, TypeVar)

def is_optional_type(check_type) -> bool:
    """Check if a type is optional (i.e., can be None)."""
    origin = get_origin(check_type)
    if origin is not Union:
        return False
    return any(arg is type(None) for arg in get_args(check_type))

def get_type_name(t):
    """ Returns a human-readable name for the type, minimizing mentions of Union and List when not needed. """
    if get_origin(t) is Union:
        types = [get_type_name(arg) for arg in get_args(t) if arg is not type(None)]
        return f"[{', '.join(types)}]" if len(types) > 1 else types[0]
    elif get_origin(t) in {list, List}:
        args = get_args(t)
        if len(args) == 1 and get_origin(args[0]) is Union:
            return get_type_name(args[0])
        return f"List of {', '.join(get_type_name(arg) for arg in args)}"
    elif hasattr(t, '__qualname__'):
        return t.__qualname__
    elif hasattr(t, '__name__'):
        return t.__name__
    return str(t)
    
def is_instance_of_generic(item, generic_type):
    origin = get_origin(generic_type)
    args = get_args(generic_type)

    if generic_type is Any:
        return True  # Since Any type should accept any value
    
    if origin is Union:
        return any(is_instance_of_generic(item, arg) for arg in args)

    elif origin in {list, List}:
        if isinstance(item, List):
            return True
        if not isinstance(item, list):
            return False
        if not item:  # if the list is empty, accept it
            return True
        return all(any(is_instance_of_generic(sub_item, arg) for arg in args) for sub_item in item)
    
    elif is_generic_var(generic_type):
        # Generic type variable found. No way to validate it until it is resolved.
        # In practical applications, you may want to pass a mapping to resolved types.
        return True

    elif isinstance(generic_type, Enum):
        return isinstance(item, generic_type.__class__)

    return isinstance(item, generic_type)

def _validate_and_call(func, *args, **kwargs):
    func_signature = inspect.signature(func)
    bound_arguments = func_signature.bind(*args, **kwargs)
    bound_arguments.apply_defaults()

    hints = get_type_hints(func, include_extras=True)
    for name, value in bound_arguments.arguments.items():
        expected_type = hints.get(name)
        if expected_type is None:
            continue

        if not is_instance_of_generic(value, expected_type):
            expected_type_name = get_type_name(expected_type)
            raise TypeError(f"Expected {name} to be one of type of {expected_type_name}, got {type(value)} instead")

    return func(*bound_arguments.args, **bound_arguments.kwargs)