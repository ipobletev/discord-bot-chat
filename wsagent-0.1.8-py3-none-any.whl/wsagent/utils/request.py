import asyncio
import logging
from typing import Any, Callable, Coroutine, Dict, Optional, AsyncGenerator
import aiohttp
from aiohttp import ClientResponseError
from wsagent.ai_services.exceptions import StopException

async def request_with_exponential_backoff(
    stream: Optional[bool] = False, 
    stop_event: Optional[asyncio.Event] = None,
    url: Optional[str] = None, 
    method: Optional[str] = 'POST', 
    headers: Dict[str, str] = {},
    json: Optional[Dict] = None,
    data: Optional[Dict] = None, 
    params: Optional[Dict[str, str]] = None,  # Added params argument
    retries: Optional[int] = None,
    backoff_base: Optional[int] = None,
    log: Optional[logging.Logger] = None,
    stream_handler: Optional[Callable[[aiohttp.ClientResponse, asyncio.Event], AsyncGenerator]] = None,
    *args, **kwargs
) -> AsyncGenerator[Optional[Dict], None]:
    """
    Perform an HTTP request with exponential backoff.
    
    Args:
        url (str): URL to make the request to.
        method (str): HTTP method to use.
        headers (Dict[str, str]): Request headers.
        data (Dict): Data to send in the request.
        params (Dict[str, str]): Query parameters to include in the request.
        retries (int): Maximum retry attempts.
        backoff_base (int): Base for the exponential backoff calculation.
        log (logging.Logger): Logger instance.
        stream_handler (Callable[[aiohttp.ClientResponse, asyncio.Event], AsyncGenerator]): A coroutine for handling stream data.
    
    Yields:
        Optional[Dict]: JSON response or chunk of data from the stream.
    """
    """
    Perform an HTTP request with exponential backoff.
    
    Args:
        url (str): URL to make the request to.
        method (str): HTTP method to use.
        headers (Dict[str, str]): Request headers.
        data (Dict): Data to send in the request.
        retries (int): Maximum retry attempts.
        backoff_base (int): Base for the exponential backoff calculation.
        log (logging.Logger): Logger instance.
        stream_handler (Callable[[aiohttp.ClientResponse, asyncio.Event], AsyncGenerator]): A coroutine for handling stream data.
    
    Yields:
        Optional[Dict]: JSON response or chunk of data from the stream.
    """
    
    if retries is None: retries = 5
    if backoff_base is None: backoff_base = 2
    
    error_text = None
    
    async with aiohttp.ClientSession() as session:
        for attempt in range(1, retries + 1):
            try:                
                async with session.request(method, url, headers=headers, json=json, data=data, params=params) as response:
                    if response.status == 200:
                        if stream and stream_handler:
                            async for response_chunk in stream_handler(response, stop_event, *args, **kwargs):
                                yield response_chunk    
                        elif stream: 
                            async for response_chunk in response.content:
                                if stop_event and stop_event.is_set():
                                    raise StopException("Stop event triggered.")
                                yield response_chunk                       
                        else:
                            resp_data = await response.text()
                            yield resp_data
                        return
                    elif response.status in {400, 401, 404}: #bad request or not found, end request instantly without retrying
                        error_text = await response.text()
                        log.error(f"Server returned status {response.status}: {error_text}")
                        raise ClientResponseError(response.request_info, response.history, status=response.status, message=error_text)
                    else:
                        error_text = await response.text()
                        log.error(f"Attempt {attempt} failed. {response.status}: {error_text}. Retrying in {backoff_base ** attempt} seconds...")
                        await asyncio.sleep(backoff_base ** attempt)
            except ClientResponseError as e:
                raise e
            except aiohttp.ClientConnectionError as e:
                log.error(f"Connection error on attempt {attempt}: {str(e)}")
                if attempt == retries:
                    raise
            except aiohttp.ClientError as e:
                log.error(f"Client error on attempt {attempt}: {str(e)}")
                if attempt == retries:
                    raise
                
        raise ClientResponseError(response.request_info, response.history, status=response.status, message=error_text)