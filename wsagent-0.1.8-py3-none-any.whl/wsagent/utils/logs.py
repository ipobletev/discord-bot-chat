from datetime import datetime
import logging
from logging import Logger
import os
from typing import Optional

class PrintAndLog:
    
    def __init__(self,
        level: Optional[int] = None,
        formatter: Optional[str] = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool] = False,
        enable_log_stream: Optional[bool] = False
    ):
        
        if log_path is None: log_path = f'.logs/{datetime.now().strftime("%Y_%m_%d_%H_%M_%S")}'
        if level is None: level = logging.DEBUG
        
        self._log_name=log_name
        self._log_path=log_path
        self.enable_log_file = enable_log_file
        self.enable_log_stream = enable_log_stream
        #filter with space with -
        if enable_log_file:
            self._log_name = self._log_name.replace(' ', '_')
            self._log_path = self._log_path.replace(' ', '_')
            self._log_path = self._log_path.replace('-', '_')
            path=self._log_path
            if not os.path.exists(path):
                os.makedirs(path, exist_ok=True)
        
        # Set up a formatter
        if formatter is None:
            formatter = '[%(asctime)s][%(name)s][%(levelname)s] - %(message)s'
            
        formatter = logging.Formatter(formatter)
        
        # Set up the logger
        self._logger = logging.getLogger(self._log_name)
        self._logger.setLevel(level)
        
        # Set up file handler
        if enable_log_file:
                
            path_log=os.path.join(self._log_path, f"{self._log_name}.log")
        
            file_handler = logging.FileHandler(path_log, encoding="utf-8")
            file_handler.setFormatter(formatter)
            self._logger.addHandler(file_handler)
        
        # Set up stream handler
        if enable_log_stream:
            stream_handler = logging.StreamHandler()
            stream_handler.setFormatter(formatter)
            self._logger.addHandler(stream_handler)
    
    @staticmethod
    def determine_logger(
        logger: Optional[Logger] = None,
        level: Optional[int] = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool] = False,
    ):
        
        if level is None: level = logging.DEBUG
        
        out_logger=None
        
        # Use internal logger
        if enable_log_file == True and logger == None:
            out_logger = PrintAndLog(
                log_name=log_name,
                log_path=log_path,
                enable_log_file=enable_log_file
            ).logger
        if out_logger is None:
        # Not use internal or external, use logging
            if logger is None: 
                out_logger = logging.getLogger(__name__)
        # Use external logger
            else:
                out_logger = logger
        
        return out_logger
        
    #Get the logger name
    @property
    def log_name(self) -> str:
        return self._log_name
    
    #Get the logger
    @property
    def logger(self) -> Logger:
        return self._logger
        