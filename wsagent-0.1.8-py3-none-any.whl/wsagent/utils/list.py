def fusion_list_wout_duplicates(first_list, second_list, unique_key):
    seen = {}
    out_list = []

    # Add all items from the first list to the output and track them by unique_key
    for item in first_list:
        if item[unique_key] not in seen:
            out_list.append(item)
            seen[item[unique_key]] = True

    # Add items from the second list to the output only if they haven't been added yet
    for item in second_list:
        if item[unique_key] not in seen:
            out_list.append(item)
            seen[item[unique_key]] = True

    return out_list