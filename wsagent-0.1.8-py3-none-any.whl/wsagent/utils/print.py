async def print_chunk_async(chunk, data_type):
    """Print content data chunks asynchronously."""
    if data_type == 'data':
        end = '' if chunk else '\n'  # Don't add a newline if chunk is empty
        print(chunk, end=end, flush=True)  # Use flush to ensure output is written immediately