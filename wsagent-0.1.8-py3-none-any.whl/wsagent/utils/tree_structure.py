from collections import defaultdict

def create_json_tree(paths: list):
    tree = lambda: defaultdict(tree)
    root = tree()
    for path in paths:
        parts = path.split('/')
        current_level = root
        for part in parts:
            current_level = current_level[part]
    def dicts(t):
        return {k: dicts(t[k]) for k in t}
    return dicts(root)

def json_to_str_tree(json_data: dict, indent=0, prefix=''):
    tree_str = ""
    items = list(json_data.items())
    for i, (key, value) in enumerate(items):
        connector = '└── ' if i == len(items) - 1 else '├── '
        tree_str += "    " * indent + prefix + connector + f"{key}\n"
        if isinstance(value, dict):
            next_prefix = '│   ' if i != len(items) - 1 else '    '
            tree_str += json_to_str_tree(value, indent + 1, next_prefix)
    return tree_str