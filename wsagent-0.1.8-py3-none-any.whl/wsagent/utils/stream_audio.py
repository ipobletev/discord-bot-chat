import pyaudio
import soundfile as sf

def stream_audio(chunk_size,buffer):
    
    audio = pyaudio.PyAudio()
    
    with sf.SoundFile(buffer, 'r') as sound_file:
        format = pyaudio.paInt16
        channels = sound_file.channels
        rate = sound_file.samplerate
        stream = audio.open(format=format, channels=channels, rate=rate, output=True)
        data = sound_file.read(chunk_size, dtype='int16')
        
        while len(data) > 0:
            stream.write(data.tobytes())
            data = sound_file.read(chunk_size, dtype='int16')
    

    # Close the PyAudio stream when done
    stream.stop_stream()
    stream.close()