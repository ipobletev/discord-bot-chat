# Function to encode the image
import base64
import httpx

def b64encode_image_from_path(image_path):
  with open(image_path, "rb") as image_file:
    return base64.b64encode(image_file.read()).decode('utf-8')

def b64encode_image_from_url(image_url):
  headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0'
  }
  return base64.b64encode(httpx.get(url=image_url,headers=headers).content).decode("utf-8")