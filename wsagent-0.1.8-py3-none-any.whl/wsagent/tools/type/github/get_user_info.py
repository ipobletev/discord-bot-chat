import os
import aiohttp
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from dotenv import load_dotenv
load_dotenv()

class GetUserInfo(Tool):
    def __init__(self):
        super().__init__(
            name="get_user",
            func=self.get_user_info,
            description="Get user's Github profile information",
            arguments=[
                Parameter("username", "The username of the user.", str, required=False)
            ]
        )

    async def get_user_info(self, username=None):
        try:
            github_token = os.getenv('GITHUB_TOKEN')

            # Check if the GitHub token is available
            if github_token is None:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": "ERROR: GitHub Personal Access Token (GITHUB_TOKEN) not found in environment variables."
                }

            headers = {'Authorization': f'token {github_token}'}

            async with aiohttp.ClientSession() as session:
                user_url = f'https://api.github.com/users/{username}' if username else 'https://api.github.com/user'
                async with session.get(user_url, headers=headers) as response:
                    if response.status == 404:
                        return {
                            "status": 404,
                            "return": None,
                            "return_string": "ERROR: User information not found."
                        }

                    user_info = await response.json()                        
                    important_info = await extract_important_info(user_info)  # Await the function call
                    return_string = f"Retrieved user information:\n" + "\n".join([f"- {key}: {value}" for key, value in important_info.items()])
                    return {
                        "status": response.status,
                        "return": important_info,
                        "return_string": return_string
                    }
                
        except Exception as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: {str(e)}"
            }
        
async def extract_important_info(user_info):
    important_info = {
        'id': user_info.get('id', None),
        'username': user_info.get('login', None),
        'name': user_info.get('name', None),
        'url': user_info.get('html_url', None),
        'avatar_url': user_info.get('avatar_url', None),
        'created_at': user_info.get('created_at', None),
        'updated_at': user_info.get('updated_at', None),
        'public_repos': user_info.get('public_repos', None),
    }
    return important_info