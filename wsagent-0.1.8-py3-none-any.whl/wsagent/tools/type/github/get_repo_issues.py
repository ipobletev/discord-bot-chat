import os
import aiohttp
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from dotenv import load_dotenv

load_dotenv()

class GetRepoIssues(Tool):
    def __init__(self):
        super().__init__(
            name="get_repo_issues",
            func=self.get_repo_issues,
            description="Get a list of issues from a specific repository",
            arguments=[
                Parameter("owner", "The name of the owner of the repository.", str, required=True),
                Parameter("repo_name", "The name of the repository.", str, required=True)
            ]
        )

    async def get_repo_issues(self, owner, repo_name):
        try:
            github_token = os.getenv('GITHUB_TOKEN')

            # Check if the GitHub token is available
            if github_token is None:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": "ERROR: GitHub Personal Access Token (GITHUB_TOKEN) not found in environment variables."
                }

            headers = {'Authorization': f'token {github_token}'}

            async with aiohttp.ClientSession() as session:
                async with session.get(f'https://api.github.com/repos/{owner}/{repo_name}/issues', headers=headers) as response:
                    issues = await response.json()
                    if not issues:
                        return {
                            "status": 404,
                            "return": None,
                            "return_string": "ERROR: No issues found for the repository."
                        }
                    if (type(issues) != list and issues['message'] == 'Not Found'):
                        return {
                            "status": 404,
                            "return": None,
                            "return_string": "ERROR: User not found."
                        }

                    issues = [{"title": issue["title"], "state": issue["state"], "number": issue["number"]} for issue in issues]
                    return_string = "Retrieved repository issues:\n" + "\n".join([f"- Issue # {issue['number']} ({issue['state']}): {issue['title']}" for issue in issues])

                    return {
                        "status": response.status,
                        "return": issues,
                        "return_string": return_string
                    }

        except aiohttp.ClientError as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: AIOHTTP ClientError: {str(e)}"
            }
        except Exception as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: {str(e)}"
            }