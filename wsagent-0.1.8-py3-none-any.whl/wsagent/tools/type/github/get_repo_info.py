import os
import aiohttp
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from dotenv import load_dotenv
load_dotenv()

class GetRepoInfo(Tool):
    def __init__(self):
        super().__init__(
            name="get_repo_info",
            func=self.get_repo_info,
            description="Get information about a specific repository",
            arguments=[
                Parameter("owner", "The name of the owner of the repository.", str, required=True),
                Parameter("repo_name", "The name of the repository.", str, required=True)
            ]
        )

    async def get_repo_info(self, owner, repo_name):
        try:
            github_token = os.getenv('GITHUB_TOKEN')

            # Check if the GitHub token is available
            if github_token is None:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": "ERROR: GitHub Personal Access Token (GITHUB_TOKEN) not found in environment variables."
                }

            headers = {'Authorization': f'token {github_token}'}

            async with aiohttp.ClientSession() as session:
                async with session.get(f'https://api.github.com/repos/{owner}/{repo_name}', headers=headers) as response:
                    repo_info = await response.json()
                    if not repo_info:
                        return {
                            "status": 404,
                            "return": None,
                            "return_string": "ERROR: Repository information not found."
                        }
                    if ("message" in repo_info and repo_info['message'] == 'Not Found'):
                        return {
                            "status": 404,
                            "return": None,
                            "return_string": "ERROR: Repository not found."
                        }
                    important_info = await extract_important_info(repo_info)  # Await the function call
                    return_string = f"Retrieved repository information:\n" + "\n".join([f"- {key}: {value}" for key, value in important_info.items()])
                    return {
                        "status": response.status,
                        "return": important_info,
                        "return_string": return_string
                    }
        except aiohttp.ClientError as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: AIOHTTP ClientError: {str(e)}"
            }
        except Exception as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: {str(e)}"
            }

async def extract_important_info(repo_info):
    important_info = {
        'id': repo_info.get('id', None),
        'full_name': repo_info.get('full_name', None),
        'private': repo_info.get('private', None),
        'url': repo_info.get('url', None),
        'created_at': repo_info.get('created_at', None),
        'pushed_at': repo_info.get('pushed_at', None),
        'size': repo_info.get('size', None),
        'language': repo_info.get('language', None),
        'open_issues_count': repo_info.get('open_issues_count', None),
        'default_branch': repo_info.get('default_branch', None),
    }
    return important_info