import os
import aiohttp
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from dotenv import load_dotenv
load_dotenv()

class GetRepositories(Tool):
    def __init__(self):
        super().__init__(
            name="get_repositories",
            func=self.get_user_repos,
            description="Get user's Github repositories",
            arguments=[
                Parameter("username", "The username of the user.", str, required=False)
            ]
        )

    async def get_user_repos(self, username=None):
        try:
            github_token = os.getenv('GITHUB_TOKEN')

            # Check if the GitHub token is available
            if github_token is None:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": "ERROR: GitHub Personal Access Token (GITHUB_TOKEN) not found in environment variables."
                }

            headers = {'Authorization': f'token {github_token}'}

            async with aiohttp.ClientSession() as session:
                user_url = f'https://api.github.com/users/{username}' if username else 'https://api.github.com/user'
                async with session.get(f'{user_url}/repos', headers=headers) as response:
                    repos = await response.json()
                    if not repos:
                        return {
                            "status": 404,
                            "return": None,
                            "return_string": "ERROR: No repositories found for the user."
                        }
                    if (type(repos) != list and repos['message'] == 'Not Found'):
                        return {
                            "status": 404,
                            "return": None,
                            "return_string": "ERROR: User not found."
                        }

                    return_string = "User's repositories:"
                    return_string += "\n" + "\n".join([f"- ID: {repo['id']}, Name: {repo['name']}, URL: {repo['html_url']}, Description: {repo['description']}, Private: {repo['private']}, Language: {repo['language']}, Created At: {repo['created_at']}, Updated At: {repo['updated_at']}, Pushed At: {repo['pushed_at']}" for repo in repos])

                    return {
                        "status": response.status,
                        "return": repos,
                        "return_string": return_string
                    }

        except aiohttp.ClientError as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: AIOHTTP ClientError: {str(e)}"
            }
        except Exception as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: {str(e)}"
            }