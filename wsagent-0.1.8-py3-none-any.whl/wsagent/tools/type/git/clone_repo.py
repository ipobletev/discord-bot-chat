import os
import asyncio
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from dotenv import load_dotenv

load_dotenv()

class CloneRepo(Tool):
    def __init__(self):
        super().__init__(
            name="clone_repo",
            func=self.clone_repo,
            description="Clone a repository",
            arguments=[
                Parameter("repo_url", "The URL of the repository to clone.", str, required=True)
            ]
        )

    async def clone_repo(self, repo_url):
        try:
            # Get the PAT from environment variables
            github_token = os.getenv('PAT_GITHUB')

            # Check if the token is available
            if github_token is None:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": "ERROR: GitHub Personal Access Token (GITHUB_PAT) not found in environment variables."
                }

            # Modify the repo_url to include the PAT
            repo_url_parts = repo_url.split('://')  # separate the protocol from the rest of the URL
            repo_url = f'{repo_url_parts[0]}://{github_token}@{repo_url_parts[1]}'

            # Get the repo name from the URL
            repo_name = repo_url.split('/')[-1]
            if '.git' in repo_name:
                repo_name = repo_name[:-4]  # Remove the .git extension if present

            # Create destination directory with the repo name
            destination = f'./data/git/{repo_name}'
            if os.path.exists(destination):
                return {
                    "status": 400,
                    "return": None,
                    "return_string": f"ERROR: Destination directory already exists. {destination}"
                }
            os.makedirs(destination, exist_ok=True)

            # Clone the repository asynchronously
            process = await asyncio.create_subprocess_shell(
                f'git clone {repo_url} {destination}',
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            # Wait for the subprocess to complete
            _, stderr = await process.communicate()

            # Check if the subprocess exited successfully
            if process.returncode != 0:
                # Handle the error case
                raise Exception(f"Unable to clone repository. Exit code: {process.returncode}. Error: {stderr.decode().strip()}")
        except Exception as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: {str(e)}"
            }

        return {
            "status": 200,
            "return": destination,
            "return_string": f"Repository cloned successfully to {destination}",
        }