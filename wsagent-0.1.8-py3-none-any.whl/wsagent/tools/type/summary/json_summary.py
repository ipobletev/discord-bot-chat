import os
import json
import aiohttp
import pandas as pd
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from wsagent.ai_services.openai.enums import OpenAIEnums

class JSONSummary(Tool):
    def __init__(self):
        super().__init__(
            name="json_summary",
            func=self.json_summary,
            description="A tool that provides a summary of the structure of a JSON file.",
            arguments=[
                Parameter("json_file_path", "The path to the JSON file.", str, required=True),
            ]
        )

    async def json_summary(self, json_file_path):
        try:
            # Load the JSON file
            with open(json_file_path, 'r', encoding='utf-8-sig') as f:
                data = json.load(f)

            # Convert the JSON data to a pandas DataFrame
            df = pd.DataFrame(data)
            
            info = []
            info.append(df.describe(include='all').to_dict())
            info.append(df.head(2).to_dict())       
            
            info_str = f"The following is the result of df.describe(include='all'):\n{info[0]}\n\nThe following is the result of df.head(2):\n{info[1]}"     
            
            prompt = f"Based on the following [INFORMATION] about a json file. Provide a summary of the structure of the json file. Its important that you mention all the keys and their hierarchy. \n\n {info_str} \n\n [SUMMARY]:"
            # Headers
            headers = {
                'Authorization': f'Bearer {os.environ.get("OPENAI_API_KEY")}',
                'Content-Type': 'application/json'
                }
        
            # Data
            data={}
            data["model"]=OpenAIEnums.Models.LLM.GPT_4_1106_PREVIEW.name
            data["messages"]=[{"role": "system", "content": prompt}]

            # URL
            url=OpenAIEnums.Endpoints.CHATCOMPLETION.url
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=data) as response:
                    json_response = await response.json()
                    return_chatbot = json_response["choices"][0]["message"]["content"]

            # Return the summary
            return {
                "status": 200,
                "return": return_chatbot,
                "return_string": f"Here is the summary of the JSON file at {json_file_path}:\n{return_chatbot}"
            }

        except FileNotFoundError:
            return {
                "status": 404,
                "return": None,
                "return_string": "ERROR: File not found"
            }
        except json.JSONDecodeError:
            return {
                "status": 400,
                "return": None,
                "return_string": "ERROR: Invalid JSON file"
            }
        except Exception as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: {str(e)}"
            }