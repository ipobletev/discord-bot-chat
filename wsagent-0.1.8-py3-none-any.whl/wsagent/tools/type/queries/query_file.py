import os
import aiohttp
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from wsagent.ai_services.openai.enums import OpenAIEnums
from wsagent.ai_services.openai.count import count_tokens

MAX_TOKENS = 8000

class QueryFile(Tool):
    def __init__(self):
        super().__init__(
            name="query_file",
            func=self.query_file,
            description="Useful for when you need to ask questions about a file in the ./data directory and extract information from it using an LLM.",
            arguments=[
                Parameter("filepath", "The path to the text based file you want to query. Must start with './data'", str, required=True),
                Parameter("questions", "An array of fully formed queries that you want to execute on the file.", list, item_type=str, required=True)
            ]
        )

    async def query_file(self, filepath, questions):
        try:
            if filepath is None or questions is None:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": "ERROR: Missing arguments. Both filepath and questions are required."
                }

            allowed_extensions = ['.txt', '.md', '.yaml', '.yml', '.conf', '.ini', '.html', '.css', '.js', '.py', '.java', '.c', '.cpp', '.js', '.ts', '.php', '.rb', '.go', '.rs', '.h', '.hpp', '.cs', '.swift', '.kt', '.scala', '.m', '.pl', '.bash', '.sh', '.r', '.groovy', '.clj', '.sql', '.properties', '.bat', '.ps1', '.vbs', '.lua', '.rst', '.markdown', '.tex', '.asm', '.mat', '.f', '.pas', '.vb', '.dart', '.sass', '.less', '.scss', '.erl', '.hs', '.aspx', '.jsp', '.phtml', '.twig', '.mustache', '.haml', '.jl', '.cshtml', '.vbhtml', '.fs', '.fsx', '.ml', '.tcl', '.zsh', '.csh', '.jsx', '.tsx']

            # Check if file extension is allowed
            if not any(filepath.endswith(extension) for extension in allowed_extensions):
                return {
                    "status": 400,
                    "return": None,
                    "return_string": f"ERROR: Invalid file extension. Allowed extensions are {allowed_extensions}"
                }

            query = "\n".join(questions)

            try:
                with open(filepath, 'r', encoding="utf-8") as infile:
                    file_content = infile.read()
            except FileNotFoundError:
                return {
                    "status": 404,
                    "return": None,
                    "return_string": "ERROR: File not found"
                }
            except IOError as e:
                return {
                    "status": 500,
                    "return": None,
                    "return_string": f"ERROR: I/O error({e.errno}): {e.strerror}"
                }
            except Exception as e:
                return {
                    "status": 500,
                    "return": None,
                    "return_string": f"ERROR: {e}"
                }
            
            # Count tokens in file_content
            tokens_count = count_tokens(input_txt=file_content, model=OpenAIEnums.Models.LLM.GPT_3_5_TURBO_1106)
            
            if tokens_count > MAX_TOKENS:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": "ERROR: The string containing the file content is too large, try a different file or a different tool."
                }

            prompt = f"Review the [FILE_CONTENT] and answer the [QUERY]. Include as much details as possible in your answer.\n\n[QUERY]\n{query}\n[FILE_CONTENT]\n\'\'\'\n{file_content}\n'\'\'\n[ANSWER]\n"
            
            # Headers
            headers = {
                'Authorization': f'Bearer {os.environ.get("OPENAI_API_KEY")}',
                'Content-Type': 'application/json'
                }
        
            # Data
            data={}
            data["model"]=OpenAIEnums.Models.LLM.GPT_4_1106_PREVIEW.name
            data["messages"]=[{"role": "system", "content": prompt}]

            # URL
            url=OpenAIEnums.Endpoints.CHATCOMPLETION.url
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=data) as response:
                    json_response = await response.json()
                    return_chatbot = json_response["choices"][0]["message"]["content"]

            # Return the query result
            return {
                "status": 200,
                "return": return_chatbot,
                "return_string": return_chatbot
            }

        except Exception as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: {str(e)}"
            }