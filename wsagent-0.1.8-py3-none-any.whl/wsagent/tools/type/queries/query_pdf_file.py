import os
import aiohttp
import PyPDF2
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from wsagent.ai_services.openai.enums import OpenAIEnums
from wsagent.ai_services.openai.count import count_tokens

MAX_TOKENS = 8000

class QueryPdfFile(Tool):
    def __init__(self):
        super().__init__(
            name="query_pdf_file",
            func=self.query_pdf_file,
            description="Useful for when you need to ask questions about specific pages of a PDF file in the ./data directory and extract information from it using an LLM.",
            arguments=[
                Parameter("filepath", "The path to the PDF file you want to query. Must start with './data'", str, required=True),
                Parameter("page_numbers", "The list of page numbers you want to query.", list, item_type=int, required=True),
                Parameter("questions", "An array of fully formed queries that you want to execute on the pages.", list, item_type=str, required=True)
            ]
        )

    async def query_pdf_file(self, filepath, page_numbers, questions):
        try:
            if filepath is None or page_numbers is None or questions is None:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": "ERROR: Missing arguments. Filepath, page_numbers, and questions are required."
                }

            if not filepath.endswith('.pdf'):
                return {
                    "status": 400,
                    "return": None,
                    "return_string": "ERROR: Invalid file extension. Only .pdf files are allowed."
                }

            query = "\n".join(questions)

            # Extract pages from PDF
            with open(filepath, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(filepath)
                pages_content = ""
                for i, page in enumerate(pdf_reader.pages):
                    # Check if the current page number is in the provided page numbers
                    if i+1 in page_numbers:  # page numbers are 1-indexed
                        pages_content += page.extract_text()

            # Count tokens in pages_content
            tokens_count = count_tokens(input_txt=pages_content, model=OpenAIEnums.Models.LLM.GPT_3_5_TURBO_1106)

            if tokens_count > MAX_TOKENS:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": "ERROR: The string containing the pages content is too large, try fewer pages or a different tool."
                }

            prompt = f"Review the [FILE_CONTENT] and answer the [QUERY]. Include as much details as possible in your answer.\n\n [QUERY]\n{query}\n[FILE_CONTENT]\n\'\'\'\n{pages_content}\n'\'\'\n[ANSWER]"

            # Headers
            headers = {
                'Authorization': f'Bearer {os.environ.get("OPENAI_API_KEY")}',
                'Content-Type': 'application/json'
                }
        
            # Data
            data={}
            data["model"]=OpenAIEnums.Models.LLM.GPT_4_1106_PREVIEW.name
            data["messages"]=[{"role": "system", "content": prompt}]

            # URL
            url=OpenAIEnums.Endpoints.CHATCOMPLETION.url
            async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers, json=data) as response:
                    json_response = await response.json()
                    return_chatbot = json_response["choices"][0]["message"]["content"]

            # Return the query result
            return {
                "status": 200,
                "return": return_chatbot,
                "return_string": return_chatbot
            }
        
        except FileNotFoundError:
            return {
                "status": 404,
                "return": None,
                "return_string": "ERROR: File not found"
            }
        
        except IOError as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: I/O error({e.errno}): {e.strerror}"
            }
        
        except Exception as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: {str(e)}"
            }