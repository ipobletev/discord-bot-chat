import os
import re
import json
import PyPDF2
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from wsagent.ai_services.ai_services import AIModelType
from wsagent.ai_services.openai.enums import OpenAIEnums
from wsagent.ai_services.openai.count import count_tokens
from wsagent.ai_services.ai_services_interface import AIModelInterface

MAX_TOKENS = 500

class CreatePDFEmbedding(Tool):
    def __init__(self):
        super().__init__(
            name="pdf_embedding",
            func=self.create_pdf_embedding,
            description="Generates embeddings for a PDF file's content per page and saves the embeddings in a JSON file located in the './data/embeddings' directory. Works only on '.pdf' files.",
            arguments=[
                Parameter("file_path", "Path to the '.pdf' file in the './data' directory. Must start with './data'", str, required=True),
            ]
        )
        
        # Create an instance of AIModelInterface
        self.ai_model_interface = AIModelInterface()

    async def create_pdf_embedding(self, file_path='./data'):
        try:
            # Check if file_path starts with ./data
            if not file_path.startswith("./data"):
                return {
                    "status": 400,
                    "return": "",
                    "return_string": "ERROR: Invalid file path. File path must start with './data'"
                }
            # Check if the file exists
            if not os.path.exists(file_path):
                return {
                    "status": 404,
                    "return": "",
                    "return_string": f"ERROR: File not found at {file_path}"
                }
                
            # Check if file_path ends with .pdf
            if not file_path.endswith(".pdf"):
                return {
                    "status": 400,
                    "return": "",
                    "return_string": "ERROR: Invalid file type. File must be a .pdf file"
                }

            try:
                # Open the PDF file
                with open(file_path, 'rb') as pdf_file:
                    pdf_reader = PyPDF2.PdfReader(pdf_file)
                    num_pages = len(pdf_reader.pages)
                    
                    # Get embeddings for each page
                    embeddings = []
                    for page_num in range(num_pages):
                        page = pdf_reader.pages[page_num]
                        content = page.extract_text()
                        content = "".join([char for char in content if char.isascii()])

                        num_tokens = count_tokens(input_txt=content, model=OpenAIEnums.Models.LLM.GPT_3_5_TURBO_1106)
                        if num_tokens > MAX_TOKENS:
                            # Split the content into chunks of MAX_TOKENS
                            chunks = self.split_into_chunks(content, MAX_TOKENS)
                            
                            # Get embeddings for each chunk
                            for i, chunk in enumerate(chunks):
                                # Use the get_embedding method from AIModelInterface
                                embedding = await self.ai_model_interface.functionality(aimodel_type=AIModelType.OPENAI,
                                    feature_type=OpenAIEnums.Feature.Embeddings.CREATE,
                                    model=OpenAIEnums.Models.Embeddings.ADA_V2,
                                    input=chunk,
                                )
                                embeddings.append({
                                    'page_number': page_num + 1,
                                    'content': chunk,
                                    'embedding': embedding
                                })
                            
                        else:
                            # Use the get_embedding method from AIModelInterface
                            embedding = await self.ai_model_interface.functionality(aimodel_type=AIModelType.OPENAI,
                                feature_type=OpenAIEnums.Feature.Embeddings.CREATE,
                                model=OpenAIEnums.Models.Embeddings.ADA_V2,
                                input=content,
                            )
                            embeddings.append({
                                'page_number': page_num + 1, 
                                'content': content,
                                'embedding': embedding
                            })
            except (PyPDF2.utils.PdfReadError, IOError) as e:
                return {
                    "status": 500,
                    "return": "",
                    "return_string": f"ERROR: Unable to read the PDF file. {str(e)}"
                }

            # Create the mirror directory inside '/data/embeddings' if it doesn't exist
            mirror_dir = f'./data/embeddings/{os.path.basename(file_path)}'  # exclude './data' part from original directory

            try:
                os.makedirs(mirror_dir, exist_ok=True)
            except OSError as e:
                return {
                    "status": 500,
                    "return": "",
                    "return_string": f"ERROR: Unable to create directory. {str(e)}"
                }

            try:
                # Write all embeddings to a single JSON file
                with open(f'{mirror_dir}/{os.path.basename(file_path)}.json', 'w') as json_file:
                    json.dump(embeddings, json_file, indent=4)
            except IOError as e:
                return {
                    "status": 500,
                    "return": "",
                    "return_string": f"ERROR: Unable to write embeddings to JSON file. {str(e)}"
                }

            return {
                "status": 200,
                "return": f"{os.path.join(mirror_dir, os.path.basename(file_path))}.json",
                "return_string": f"Embedding for {file_path} created and saved in {os.path.join(mirror_dir, os.path.basename(file_path))}.json"
            }
        except Exception as e:
            return {
                "status": 500,
                "return": "",
                "return_string": f"ERROR: {str(e)}"
            }
    
    def split_into_chunks(self, text, chunk_size=MAX_TOKENS):
        # Divide text into sentences
        sentences = re.split(r'(?<=[.!?])\s+', text)

        chunks = []
        chunk = ""
        for sentence in sentences:
            # If adding sentence would exceed chunk size, finalize the chunk and start a new one
            if count_tokens(input_txt=chunk + sentence, model=OpenAIEnums.Models.LLM.GPT_3_5_TURBO_1106) > chunk_size: 
                chunks.append(chunk)
                chunk = sentence
            else:
                chunk += sentence

        return chunks