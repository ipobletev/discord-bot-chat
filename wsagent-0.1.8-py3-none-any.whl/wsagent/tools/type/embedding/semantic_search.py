import json
import numpy as np
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from wsagent.ai_services.ai_services import AIModelType
from wsagent.ai_services.openai.enums import OpenAIEnums
from wsagent.ai_services.ai_services_interface import AIModelInterface

def vector_similarity(v1, v2):
    return np.dot(v1, v2)

class SemanticSearch(Tool):
    def __init__(self):
        super().__init__(
            name="semantic_search",
            func=self.semantic_search,
            description="Performs a semantic search on a list of JSON files that contain embeddings.",
            arguments=[
                Parameter("json_paths", "List of paths to JSON files that contain embeddings. Default='./data/embeddings'", list, item_type=str, required=True),
                Parameter("query", "The query for the semantic search", str, required=True),
                Parameter("top_chunks", "The number of top chunks to return. Default=2", int, required=False),
                Parameter("threshold", "The threshold for the semantic search. Default=0.75", float, required=False)
            ]
        )

        # Create an instance of AIModelInterface
        self.ai_model_interface = AIModelInterface()

    async def semantic_search(self, json_paths=['./data/embeddings'], query=None, top_chunks=2, threshold=0.75):
        try:
            # Input validation
            for path in json_paths:
                if not path.startswith("./data/embeddings"):
                    return {
                        "status": 400,
                        "return": None,
                        "return_string": "ERROR: Invalid path. Path must start with './data/embeddings'"
                    }
                
            if not json_paths or not query:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": f"ERROR: json_paths and query must be provided"
                }

            if top_chunks <= 0:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": f"ERROR: top_chunks must be greater than 0"
                }

            if threshold < 0 or threshold > 1:
                return {
                    "status": 400,
                    "return": None,
                    "return_string": f"ERROR: threshold must be between 0 and 1"
                }

            embeddings = []
            for json_path in json_paths:
                try:
                    with open(json_path, 'r', encoding='utf-8') as file:
                        data = json.load(file)
                        embeddings.extend(data)

                except FileNotFoundError:
                    return {
                        "status": 404,
                        "return": None,
                        "return_string": f"ERROR: File not found: {json_path}"
                    }

                except json.JSONDecodeError:
                    return {
                        "status": 500,
                        "return": None,
                        "return_string": f"ERROR: Invalid JSON in file: {json_path}"
                    }

            query_embedding = await self.ai_model_interface.functionality(input=query, 
                aimodel_type=AIModelType.OPENAI,
                feature_type=OpenAIEnums.Feature.Embeddings.CREATE,
                model=OpenAIEnums.Models.Embeddings.ADA_V2
            )
            results = []

            for chunk in embeddings:
                chunk_embedding = chunk['embedding']

                # Extract the 'embedding' field from chunk_embedding
                chunk_embedding_array = np.array(chunk_embedding['embedding'])

                # Ensure both vectors are numpy arrays
                query_embedding_array = np.array(query_embedding['embedding'])

                # Calculate the similarity between the vectors
                similarity = vector_similarity(query_embedding_array, chunk_embedding_array)

                if similarity >= threshold:
                    result = {
                        'page_number': chunk.get('page_number', 0) if 'page_number' in chunk else 1,
                        'content': chunk.get('content', ''),
                        'model': chunk.get('model', ''),
                        'input_tokens': chunk.get('input_tokens', 0),
                        'embedding': chunk_embedding_array,  # Update to the actual embedding
                        'similarity': similarity,
                    }
                    results.append(result)

            results.sort(key=lambda x: x['similarity'], reverse=True)  # Sort by similarity in descending order
            top_results = results[:top_chunks]

            if len(top_results) == 0:
                return {
                    "status": 204,
                    "return": None,
                    "return_string": f"ERROR: No results found that meet the threshold."
                }
            else:
                # Construct the return string
                return_string = f"Top {len(top_results)} results that meet the threshold.\n"
                for res in top_results:
                    return_string += f"- Page number: {res['page_number']} - Content:\n{res['content']}\n\n"
                return {
                    "status": 200,
                    "return": top_results,
                    "return_string": return_string
                }
        except Exception as e:
            return {
                    "status": 500,
                    "return": None,
                    "return_string": f"ERROR: {e}"
                }