import os
import re
import json
from wsagent.tools.base import Tool
from wsagent.tools.parameter import Parameter
from wsagent.ai_services.ai_services import AIModelType
from wsagent.ai_services.openai.enums import OpenAIEnums
from wsagent.ai_services.openai.count import count_tokens
from wsagent.ai_services.ai_services_interface import AIModelInterface

class CreateFileEmbedding(Tool):
    def __init__(self):
        super().__init__(
            name="file_embedding",
            func=self.create_file_embedding,
            description="Generates embeddings for a text file's content and saves the embeddings in a JSON file located in the './data/embeddings' directory. Works only on '.txt' or '.md' files in the './data' directory.",
            arguments=[
                Parameter("file_path", "Path to the file in the './data' directory. Must start with './data'", str, required=True),
            ]
        )

        # Create an instance of AIModelInterface
        self.ai_model_interface = AIModelInterface()

    async def create_file_embedding(self, file_path='./data'):
        try:
            # Check if file_path starts with ./data
            if not file_path.startswith("./data"):
                return {
                    "status": 400,
                    "return": "",
                    "return_string": "ERROR: Invalid file path. File path must start with './data'"
                }
            # Check if the file exists
            if not os.path.exists(file_path):
                return {
                    "status": 404,
                    "return": "",
                    "return_string": f"ERROR: File not found at {file_path}"
                }

            # Check if file_path ends with .txt or .md
            if not (file_path.endswith(".txt") or file_path.endswith(".md")):
                return {
                    "status": 400,
                    "return": "",
                    "return_string": "ERROR: Invalid file type. File must be a .txt or .md file"
                }

            try:
                with open(file_path, 'r') as file:
                    content = file.read()
            except (FileNotFoundError, PermissionError) as e:
                return {
                    "status": 500,
                    "return": "",
                    "return_string": f"ERROR: Unable to read the file. {str(e)}"
                }

            num_tokens = count_tokens(input_txt=content, model=OpenAIEnums.Models.LLM.GPT_3_5_TURBO_1106)
            embeddings = []

            if num_tokens > 2000:
                chunks = self.chunk_and_overlap(content, num_tokens)
                for i, chunk in enumerate(chunks):
                    # Use the get_embedding method from OpenAI
                    embedding = await self.ai_model_interface.functionality(
                        aimodel_type=AIModelType.OPENAI,
                        feature_type=OpenAIEnums.Feature.Embeddings.CREATE,
                        model=OpenAIEnums.Models.Embeddings.ADA_V2,
                        input=chunk,
                    )
                    # Append embedding and chunk number to the list
                    embeddings.append({
                        'chunk_number': i,
                        'content': chunk,
                        'embedding': embedding
                    })
            else:
                # Use the get_embedding method from OpenAI
                embedding = await self.ai_model_interface.functionality(
                    aimodel_type=AIModelType.OPENAI,
                    feature_type=OpenAIEnums.Feature.Embeddings.CREATE,
                    model=OpenAIEnums.Models.Embeddings.ADA_V2,
                    input=content,
                )
                embeddings.append({
                    'chunk_number': 0,
                    'content': content,
                    'embedding': embedding
                })

            # Create the mirror directory inside '/data/embeddings' if it doesn't exist
            mirror_dir = f'./data/embeddings/{os.path.basename(file_path)}'  # dir name is the same as the file name

            try:
                os.makedirs(mirror_dir, exist_ok=True)
            except OSError as e:
                return {
                    "status": 500,
                    "return": "",
                    "return_string": f"ERROR: Unable to create directory. {str(e)}"
                }

            try:
                # Write all embeddings to a single JSON file
                with open(f'{mirror_dir}/{os.path.basename(file_path)}.json', 'w') as json_file:
                    json.dump(embeddings, json_file)
            except IOError as e:
                return {
                    "status": 500,
                    "return": "",
                    "return_string": f"ERROR: Unable to write embeddings to JSON file. {str(e)}"
                }

            return {
                "status": 200,
                "return": f"{os.path.join(mirror_dir, os.path.basename(file_path))}.json",
                "return_string": f"Embedding for {file_path} created and saved in {os.path.join(mirror_dir, os.path.basename(file_path))}.json"
            }
    
        except Exception as e:
            return {
                "status": 500,
                "return": None,
                "return_string": f"ERROR: {e}"
            }

    def chunk_and_overlap(self, text, chunk_size=2000, overlap_amount=0.1):
        # Divide text into sentences
        sentences = re.split(r'(?<=[.!?])\s+', text)

        chunks = []
        chunk = ""
        for sentence in sentences:
            # If adding sentence would exceed chunk size, finalize the chunk and start a new one
            if count_tokens(input_txt=chunk + sentence, model=OpenAIEnums.Models.LLM.GPT_3_5_TURBO_1106) > chunk_size:
                chunks.append(chunk)
                chunk = sentence
            else:
                chunk += sentence

            # If chunk size is exceeded, remove sentences from the beginning until size is acceptable
            while count_tokens(input_txt=chunk, model=OpenAIEnums.Models.LLM.GPT_3_5_TURBO_1106) > chunk_size:
                first_sentence = re.match(r'.*?[.!?]', chunk)[0]
                chunk = chunk[len(first_sentence):]

            # Add overlap (if chunk is not empty)
            if chunks and chunk:
                overlap = chunks[-1][-int(overlap_amount * chunk_size):]
                chunk = overlap + chunk

        # Append last chunk if not empty
        if chunk:
            chunks.append(chunk)

        return chunks