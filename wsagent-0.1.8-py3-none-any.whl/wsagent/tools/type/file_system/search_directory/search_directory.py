from datetime import datetime
import os
import fnmatch
import traceback
from typing import Optional
from wsagent.tools.base import Tool, Parameter
from wsagent import AIServices
from wsagent.ai_services.services.openai.utils.count import count_tokens_from_text
from wsagent.tools.schemas.tool_response import ToolResponse
from wsagent.tools.type.file_system.search_directory.squema import ContentComponent, CostComponent, ParameterComponent, UsageComponent, InputComponent

class SearchDirectory(Tool):
    def __init__(self,
            max_tokens: Optional[int] = None,
            log_name: Optional[str] = None,
            log_path: Optional[str] = None,
            enable_log_file: Optional[bool]=False,
            enable_log_stream: Optional[bool]=False
        ):
        
        if max_tokens == None: max_tokens=1000
        
        self.max_tokens = max_tokens
        
        super().__init__(
            name="search_directory",
            description="Search for files and folders in the specified directory and its subdirectories using keywords. Default path = './data'.",
            arguments=[
                Parameter("keywords", "The list of keywords to search for.", list, item_type=str, required=True),
                Parameter("path", "The path of the directory to search in. Must start with './data'", str, required=False),
            ],
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )

    async def execute(self, 
        keywords: Optional[list] = None, 
        path: Optional[str] = None
    ):
        
        init_timestamp = datetime.now().timestamp()
        
        if path is None: path = "./data"
        if not path.startswith("./data"): raise ValueError("ERROR: Invalid path. Path must start with './data'")
        if not os.path.exists(path): raise FileNotFoundError("ERROR: Path does not exist")
        if not os.path.isdir(path): raise NotADirectoryError("ERROR: Path is not a directory")

        error_msg = ''
        status = False
        raw_response = {}
        content=[]
        string_llm_rep=''
        
        try:
            matches = []
            for root, dirnames, filenames in os.walk(path):
                for keyword in keywords:
                    for filename in fnmatch.filter(filenames, '*' + keyword + '*'):
                        matches.append(os.path.join(root, filename))
                    for dirname in fnmatch.filter(dirnames, '*' + keyword + '*'):
                        matches.append(os.path.join(root, dirname))

            if len(matches) == 0:
                raise ValueError("ERROR: No matches found for the specified keywords in the specified path.")

            # Remove duplicates
            matches = list(dict.fromkeys(matches))
            content = matches

            # Count tokens in matches
            matches_str = '\n'.join(matches)
            string_llm_rep = matches_str
            tokens_count = count_tokens_from_text(input_txt=matches_str, model=AIServices.OpenAI.Feature.LLM.Model.Text.GPT_3_5_TURBO_1106)
            # Check if tokens count exceeds limit
            if tokens_count > self.max_tokens:
                raise ValueError(f"ERROR: The total number of tokens in the search results exceeds the limit of {self.max_tokens}. Please refine your search.")

            status = True
            raw_response = {
                "content": content,
                "string_llm_rep": string_llm_rep
            }
        
        except Exception as e:
            string_llm_rep = f"{e}"
            self.log.error(f'{traceback.format_exc()}')
            error_msg= f"{e}"
    
        return ToolResponse(
            input=InputComponent(
                keywords=keywords,
                path=path,
            ),
            parameters=ParameterComponent(),
            content=ContentComponent(
                content=content,
                string_llm_rep=string_llm_rep
            ),
            usage=UsageComponent(),
            cost=CostComponent(),
            init_timestamp=init_timestamp,
            error_msg=error_msg,
            status=status,
            raw_response=raw_response
        )