from typing import List, Optional, Union
from wsagent.tools.schemas.base import ContentResponse, InputResponse, ParameterResponse, UsageResponse, CostResponse
from wsagent.utils.validate_args import validate_required_args

# Components
######################################

class InputComponent(InputResponse):
    @validate_required_args
    def __init__(self, 
        keywords: Optional[List[str]] = None,
        path: Optional[str] = None
    ):
        self.keywords=keywords
        self.path=path
    
class ContentComponent(ContentResponse):
    @validate_required_args
    def __init__(self, 
        content: Optional[list] = None,
        string_llm_rep: Optional[str] = None
    ):
        self.content=content
        self.string_llm_rep=string_llm_rep
        
    def to_dict(self):
        return {
            "content": self.content,
            "string_llm_rep": self.string_llm_rep
        }

    def result(self):
        return {
            "content": self.content,
            "string_llm_rep": self.string_llm_rep
        }
    
class ParameterComponent(ParameterResponse):
    @validate_required_args
    def __init__(self, 
    ):
        pass

class UsageComponent(UsageResponse):
    @validate_required_args
    def __init__(self, 
    ):
        pass

class CostComponent(CostResponse):
    @validate_required_args
    def __init__(self, 
    ):
        pass