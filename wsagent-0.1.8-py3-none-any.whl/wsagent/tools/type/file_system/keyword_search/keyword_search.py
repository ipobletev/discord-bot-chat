from datetime import datetime
import os
import re
import traceback
from typing import Optional
from wsagent.tools.base import Tool, Parameter
from wsagent import AIServices
from wsagent.ai_services.services.openai.utils.count import count_tokens_from_text
from wsagent.tools.schemas.tool_response import ToolResponse
from wsagent.tools.type.file_system.keyword_search.squema import InputComponent, ParameterComponent, ContentComponent, UsageComponent, CostComponent

class KeywordSearch(Tool):
    def __init__(self,
        max_tokens: Optional[int] = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ):
        
        self.max_tokens=max_tokens
        
        if self.max_tokens == None: self.max_tokens=2000
        
        super().__init__(
            name="keyword_search",
            description="Search for keywords in a file and return a specified number of words before and after the matched keyword.",
            arguments=[
                Parameter("filepath", "The path to the text-based file you want to search. Must start with './data'", str, required=True),
                Parameter("keywords", "An array of keywords that you want to search in the file.", list, item_type=str, required=True),
                Parameter("window", "The number of words before and after the keyword to return. Default=10", int, required=False)
            ],
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )

    async def execute(self,            
        filepath: Optional[str]=None,
        keywords: Optional[list[str]]=None, 
        window: Optional[int]=None,
    ):
        
        init_timestamp= datetime.now().timestamp()
        
        if filepath is None: raise Exception("Missing required argument: filepath")
        if keywords is None: raise Exception("Missing required argument: keywords")
        if window is None: window = 10
        
        if not filepath.startswith("./data"): raise Exception("Invalid path. Path must start with './data'")
        if not isinstance(filepath, str) or not isinstance(keywords, list) or not isinstance(window, int): raise Exception("Invalid argument types.")
        if not all(isinstance(keyword, str) for keyword in keywords): raise Exception("Invalid keywords types.") 

        results = []
        error_msg = ''
        status = False
        raw_response = {}
        content=''
        string_llm_rep=''
        
        try:
            with open(filepath, 'r') as infile:
                file_content = infile.read()

            words = file_content.split()

            for keyword in keywords:
                for i in range(len(words)):
                    if re.search(keyword.lower(), words[i].lower()):
                        start = max(0, i - window)
                        end = min(i + window + 1, len(words))
                        results.append(' '.join(words[start:end]))

            if len(results) == 0:
                raise Exception("No matches found for the specified keywords in the specified file.")

            # Count tokens in results
            content = '\n'.join(results)
            tokens_count = count_tokens_from_text(input_txt=content, model=AIServices.OpenAI.Feature.LLM.Model.Text.GPT_3_5_TURBO_1106)

            string_llm_rep = f"Found {len(results)} results in {filepath}:\n"
            for i in range(len(results)):
                string_llm_rep += f"({i + 1}) ... {results[i]} ...\n"

            # Check if tokens count exceeds limit
            if tokens_count > self.max_tokens:
                raise Exception("ERROR: The string containing the search results is too large, try different keywords or another file.")        

            status = True
            raw_response = {
                "content": content,
                "string_llm_rep": string_llm_rep
            }
            
        except Exception as e:
            string_llm_rep = f"{e}"
            self.log.error(f'{traceback.format_exc()}')
            error_msg= f"{e}"
    
        return ToolResponse(
            input=InputComponent(
                filepath=filepath,
                keywords=keywords,
                window=window
            ),
            parameters=ParameterComponent(
                max_tokens=self.max_tokens
            ),
            content=ContentComponent(
                content=content,
                string_llm_rep=string_llm_rep
            ),
            usage=UsageComponent(),
            cost=CostComponent(),
            init_timestamp=init_timestamp,
            error_msg=error_msg,
            status=status,
            raw_response=raw_response
        )
