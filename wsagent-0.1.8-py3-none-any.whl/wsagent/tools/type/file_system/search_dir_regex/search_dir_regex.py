from datetime import datetime
import logging
import os
import re
import traceback
from typing import Optional
from wsagent.ai_services.ai_services import AIServices
from wsagent.tools.base import Tool, Parameter
from wsagent.ai_services.services.openai.utils.count import count_tokens_from_text
import asyncio

from wsagent.tools.schemas.tool_response import ToolResponse
from wsagent.tools.type.file_system.search_dir_regex.squema import ContentComponent, CostComponent, ParameterComponent, UsageComponent, InputComponent

class SearchDirRegex(Tool):
    def __init__(self,
        max_tokens: int = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ):

        if max_tokens == None: max_tokens=1500
        
        self.max_tokens = max_tokens
        
        super().__init__(
            name="search_dir_regex",
            description="Search for files and folders in the specified directory and its subdirectories using a regular expression.",
            arguments=[
                Parameter("regex", "Regular expression to filter the blobs. Default=None.", str, required=True),
                Parameter("start_dir", "The directory to start the search from. Default='./data'.", str, required=False),
                Parameter("page_size", "The size of each page. Default=25.", int, required=False),
                Parameter("page_number", "The page number to return. Default=1.", int, required=False)
            ],
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )

    async def _async_append_file_path(self, 
        matches: Optional[list] = None,
        root: Optional[str] = None, 
        filename: Optional[str] = None,
    ):
        
        if matches is None: raise ValueError("ERROR: matches is not provided.")
        if root is None: raise ValueError("ERROR: Root directory is not provided.")
        if filename is None: raise ValueError("ERROR: Filename is not provided.")
        
        matches.append(os.path.join(root, filename).replace("\\", "/"))
        
    async def _async_get_file_paths(self, 
        start_dir: Optional[list] = None,
    ):
        
        if start_dir is None: start_dir="./data"
        matches = []
        
        try:
            
            for root, dirnames, filenames in os.walk(start_dir):
                tasks = [self._async_append_file_path(matches, root, filename) for filename in filenames]
                await asyncio.gather(*tasks)
        
        except Exception as e:
            self.log.error(f"An error occurred while retrieving file paths: {str(e)}")
            raise ValueError(f"{str(e)}")
        
        return matches

    async def execute(self, 
        regex=None, 
        start_dir="./data", 
        page_size=25, 
        page_number=1
    ):

        init_timestamp= datetime.now().timestamp()
        
        if page_size <= 0 or page_number <= 0 or type(page_size) != int or type(page_number) != int: raise ValueError("ERROR: Invalid page size or page number.")
        if not start_dir.startswith("./data"): raise ValueError("ERROR: Invalid start directory. Start directory must start with './data'.")
        if not os.path.exists(start_dir): raise ValueError("ERROR: The specified directory does not exist.")
        if not os.path.isdir(start_dir): raise ValueError("ERROR: Start directory is not a directory.")
        
        page_matches=[]
        error_msg = ''
        status = False
        raw_response = {}
        content=[]
        string_llm_rep=''
        
        try:

            # If regex is provided, check if it is valid
            if regex:
                re.compile(regex)
            
            # Create a list of all the filepaths inside the data/azure directory
            matches = await self._async_get_file_paths(start_dir)
            
            # If regex is provided, filter the matches
            if regex:
                pattern = re.compile(regex)
                matches = [match for match in matches if pattern.search(match)]
            
            # Use pagination
            start = (page_number - 1) * page_size
            end = start + page_size

            # Pagination validation
            if start >= len(matches):
                raise ValueError(f"ERROR: Invalid page number or no matches for the given page.")

            # Return the matches in the requested page
            page_matches = matches[start:end]
            content = page_matches
            
            # Error handling for no matches
            if len(page_matches) == 0: raise ValueError(f"No matches found for the given regex {regex}.")
                
            string_llm_rep = f"Search results (page {page_number} of {len(matches) // page_size + 1}):\n"
            for file in page_matches:
                string_llm_rep += f"- {file}\n"

            # Check for token count limit
            token_count = count_tokens_from_text(input_txt=string_llm_rep, model=AIServices.OpenAI.Feature.LLM.Model.Text.GPT_3_5_TURBO_1106)
            
            if token_count > self.max_tokens:
                raise ValueError(f"ERROR: The total number of tokens in the search results exceeds the limit of {self.max_tokens}. Please refine your search.")

            status = True
            raw_response = {
                "content": content,
                "string_llm_rep": string_llm_rep
            }
        
        except Exception as e:
            string_llm_rep = f"{e}"
            self.log.error(f'{traceback.format_exc()}')
            error_msg= f"{e}"
    
        return ToolResponse(
            input=InputComponent(
                regex=regex,
                start_dir=start_dir,
                page_size=page_size,
                page_number=page_number
            ),
            parameters=ParameterComponent(),
            content=ContentComponent(
                content=content,
                string_llm_rep=string_llm_rep
            ),
            usage=UsageComponent(),
            cost=CostComponent(),
            init_timestamp=init_timestamp,
            error_msg=error_msg,
            status=status,
            raw_response=raw_response
        )

