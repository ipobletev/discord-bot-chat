from datetime import datetime
import re
import traceback
import PyPDF2
from typing import Optional
from wsagent.ai_services.ai_services import AIServices
from wsagent.ai_services.services.openai.utils.count import count_tokens_from_text
from wsagent.tools.base import Tool, Parameter
from wsagent.tools.type.file_system.pdf_keyword_search.squema import ContentComponent, CostComponent, InputComponent, ParameterComponent, UsageComponent
from wsagent.tools.schemas.tool_response import ToolResponse

class PDFKeywordSearch(Tool):
    def __init__(self,
        max_tokens: Optional[int] = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ):
        
        if max_tokens == None: max_tokens=2000
        self.max_tokens = max_tokens
        
        super().__init__(
            name="pdf_keyword_search",
            description="Search for keywords in a PDF file and return a specified number of words before and after the matched keyword. Use this tool first to get a sense of what the PDF file contains.",
            arguments=[
                Parameter("filepath", "The path to the PDF file you want to search. Must start with './data'", str, required=True),
                Parameter("keywords", "An array of keywords that you want to search in the file.", list, item_type=str, required=True),
                Parameter("window", "The number of words before and after the keyword to return. Default=10", int, required=False)
            ],
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream,
        )

    async def execute(self, 
        filepath : Optional[str] = None,
        keywords: Optional[list] = None,
        window: Optional[int] = 10
    ):

        init_timestamp= datetime.now().timestamp()
        
        if filepath is None or keywords is None or window is None: raise ValueError("ERROR: Missing arguments. Filepath, keywords, and window are required.")
        if filepath is None or keywords is None or window is None: raise ValueError("ERROR: Missing arguments. Filepath, keywords, and window are required.")
        if not isinstance(filepath, str) or not isinstance(keywords, list) or not isinstance(window, int): raise ValueError("ERROR: Invalid argument types.")
        if not all(isinstance(keyword, str) for keyword in keywords): raise ValueError("ERROR: Invalid keywords types.")
        if window == None: window=10

        error_msg = ''
        status = False
        raw_response = {}
        content=[]
        string_llm_rep=''
        results = []
        
        try:
            
            with open(filepath, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(filepath)
                file_content = ""
                page_number = 1
                for page in pdf_reader.pages:
                    file_content += page.extract_text()
                    words = file_content.split()

                    for keyword in keywords:
                        for i in range(len(words)):
                            if re.search(keyword.lower(), words[i].lower()):
                                start = max(0, i - window)
                                end = min(i + window + 1, len(words))
                                results.append({'keyword': keyword, 'filename': filepath, 'page': page_number,
                                                'text': ' '.join(words[start:end])})
                    file_content = ""
                    page_number += 1

            if len(results) == 0:
                raise ValueError(f"ERROR: No results found in {filepath} for the given keywords.")
            
            content=results
            
            string_llm_rep = f"Found {len(results)} results in {filepath}:\n"
            for i, result in enumerate(results):
                string_llm_rep += f"\nResult {i+1}:\n"
                string_llm_rep += f"Keyword: {result['keyword']}\n"
                string_llm_rep += f"Source: Page {result['page']}\n"
                string_llm_rep += f"Text: {result['text']}\n"
                string_llm_rep += "----------"

            # Check if tokens count exceeds limit
            tokens_count = count_tokens_from_text(input_txt=string_llm_rep, model=AIServices.OpenAI.Feature.LLM.Model.Text.GPT_3_5_TURBO_1106)

            if (tokens_count) > self.max_tokens:
                raise ValueError(f"ERROR: The results are too long to return. Please try again with fewer keywords or a smaller window.")

            status = True
            raw_response = {
                "content": content,
                "string_llm_rep": string_llm_rep
            }
                    
        except Exception as e:
            string_llm_rep = f"{e}"
            self.log.error(f'{traceback.format_exc()}')
            error_msg= f"{e}"
    
        return ToolResponse(
            input=InputComponent(
                filepath=filepath,
                keywords=keywords,
                window=window
            ),
            parameters=ParameterComponent(),
            content=ContentComponent(
                content=content,
                string_llm_rep=string_llm_rep
            ),
            usage=UsageComponent(),
            cost=CostComponent(),
            init_timestamp=init_timestamp,
            error_msg=error_msg,
            status=status,
            raw_response=raw_response
        )
