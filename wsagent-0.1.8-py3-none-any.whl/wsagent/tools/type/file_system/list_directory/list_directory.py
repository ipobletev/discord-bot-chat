from datetime import datetime
import os
import traceback
from typing import Optional
from wsagent.tools.base import Tool, Parameter
from wsagent import AIServices
from wsagent.ai_services.services.openai.utils.count import count_tokens_from_text
from wsagent.tools.type.file_system.list_directory.squema import ContentComponent, CostComponent, InputComponent, ParameterComponent, UsageComponent
from wsagent.tools.schemas.tool_response import ToolResponse

class ListDirectory(Tool):
    def __init__(self,
        max_tokens: Optional[int] = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ):
        
        if max_tokens == None: max_tokens=2000
        self.max_tokens = max_tokens
        
        super().__init__(
            name="list_directory",
            description="List the contents of the specified directory and its subdirectories. Default = './data'",
            arguments=[
                Parameter("path", "The path of the directory to list. Must start with './data'", str, required=False),
                Parameter("depth", "The depth of subdirectories to list.", int, required=False)        
            ],
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )
    
    def _print_tree(self, tree, indent='', is_last=False):
        tree_string = ''
        keys = list(tree.keys())
        for i, key in enumerate(keys):
            value = tree[key]
            if is_last:
                prefix = '    ' # four spaces
            else:
                prefix = '│   ' # vertical line followed by three spaces
            if i == len(keys) - 1: # if it's the last item
                tree_string += f'{indent}└── {key}\n'
                next_indent = indent + prefix
                tree_string += self._print_tree(value, next_indent, is_last=True) if isinstance(value, dict) else ''
            else:
                tree_string += f'{indent}├── {key}\n'
                next_indent = indent + prefix
                tree_string += self._print_tree(value, next_indent, is_last=False) if isinstance(value, dict) else ''
        return tree_string
    
    async def execute(self, 
        path: Optional[str] = None, 
        depth: Optional[int] = None
    ):
        
        init_timestamp= datetime.now().timestamp()
        
        if path is None: path = "./data"
        if depth is None: depth = 1
        if not path.startswith("./data"): raise ValueError("ERROR: Invalid path. Path must start with './data'")
        
        error_msg = ''
        status = False
        raw_response = {}
        content={}
        string_llm_rep=''
        
        try:

            async def _get_tree(path, depth):
                tree = {}
                if depth < 0: return tree
                for name in os.listdir(path):
                    sub_path = os.path.join(path, name)
                    if os.path.isdir(sub_path):
                        tree[name + "/"] = await _get_tree(sub_path, depth - 1)
                    else:
                        tree[name] = None
                return tree

            content = await _get_tree(path, depth)
            if content:
                string_llm_rep = f"Here is the directory:\n{self._print_tree(content)}"
            else:
                string_llm_rep = f"The directory is empty."

            tokens_count = count_tokens_from_text(input_txt=string_llm_rep, model=AIServices.OpenAI.Feature.LLM.Model.Text.GPT_3_5_TURBO_1106)
            if tokens_count > self.max_tokens:
                raise ValueError(f"ERROR: The tokens count exceeds the limit of {self.max_tokens} tokens. Please reduce the depth of the subdirectories.")

            status = True
            raw_response = {
                "content": content,
                "string_llm_rep": string_llm_rep
            }
        
        except Exception as e:
            string_llm_rep = f"{e}"
            self.log.error(f'{traceback.format_exc()}')
            error_msg= f"{e}"
    
        return ToolResponse(
            input=InputComponent(
                path=path,
                depth=depth
            ),
            parameters=ParameterComponent(),
            content=ContentComponent(
                content=content,
                string_llm_rep=string_llm_rep
            ),
            usage=UsageComponent(),
            cost=CostComponent(),
            init_timestamp=init_timestamp,
            error_msg=error_msg,
            status=status,
            raw_response=raw_response
        )
