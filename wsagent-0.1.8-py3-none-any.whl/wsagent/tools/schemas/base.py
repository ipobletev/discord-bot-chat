from abc import ABC, abstractmethod
from typing import Any, Generic, List, Optional, TypeVar, Union
from wsagent.utils.validate_args import validate_required_args

TInput = TypeVar('TInput')
TParameters = TypeVar('TParameters')
TContent = TypeVar('TContent')
TUsage = TypeVar('TUsage')
TCost = TypeVar('TCost')

class InputResponse(ABC):
    @abstractmethod
    def __init__(self) -> None:
        pass
    
    def to_dict(self):
        return self.__dict__

class ContentResponse(ABC):
    @abstractmethod
    def __init__(self) -> None:
        pass
    
    def to_dict(self):
        return self.__dict__
    
class ParameterResponse(ABC):
    @abstractmethod
    def __init__(self) -> None:
        pass
    
    def to_dict(self):
        return self.__dict__

class UsageResponse(ABC):
    @abstractmethod
    def __init__(self) -> None:
        pass
    
    def to_dict(self):
        return self.__dict__

class CostResponse(ABC):
    @abstractmethod
    def __init__(self) -> None:
        pass
    
    def to_dict(self):
        return self.__dict__
    
class SchemaToolResponse(ABC, Generic[TInput, TParameters, TContent, TUsage, TCost]):
    """
    Base class for all response schema in the application.
    Provides common attributes and methods that are inherited by derived classes.
    """
    @validate_required_args
    def __init__(self,
        init_timestamp: Optional[Union[float,int]] = None,
        input: TInput = None,
        parameters: TParameters  = None,
        content: TContent  = None,
        usage: TUsage  = None,
        cost:  TCost  = None,
        error_msg: Optional[str] = None,
        status: Optional[bool] = None,
        raw_response: Optional[dict] = None,
    ):
        self.init_timestamp=init_timestamp
        self.input=input
        self.parameters=parameters
        self.content=content
        self.usage=usage
        self.cost=cost
        self.error_msg=error_msg
        self.status=status
        self.raw_response=raw_response

        if not issubclass(input.__class__, InputResponse):
            raise ValueError("input must be a class InputComponent with a subclass of InputResponse. InputComponent(InputResponse)")
        if not issubclass(parameters.__class__, ParameterResponse):
            raise ValueError("parameters must be a class ParameterComponent with a subclass of ParameterResponse. ParameterComponent(ParameterResponse)")
        if not issubclass(usage.__class__, UsageResponse) and usage != []:
            raise ValueError("usage must be a class UsageComponent with a subclass of UsageResponse. UsageComponent(UsageResponse)")
        if not issubclass(cost.__class__, CostResponse) and cost != []:
            raise ValueError("usage must be a class CostComponent with a subclass of CostResponse. CostComponent(CostResponse)")
        if not issubclass(content.__class__, ContentResponse) and content != []:
            raise ValueError("usage must be a class ContentComponent with a subclass of ContentResponse. ContentComponent(ContentResponse)")
        
        if init_timestamp is None: raise ValueError("init_timestamp is required")
        if input is None: raise ValueError("input is required")
        if parameters is None: raise ValueError("parameters is required")
        if content is None: content=[]
        if usage is None: raise ValueError("usage is required")
        if cost is None: raise ValueError("cost is required")
        if error_msg is None: raise ValueError("error_msg is required")
        if status is None: raise ValueError("status is required")
        if raw_response is None: raise ValueError("raw_response is required")
        
    @abstractmethod
    def to_json(self):
        """
        Convert properties of the class instance into a dictionary.
        This method should be overridden by subclasses if they have properties.
        """
        pass

