import time
from typing import Any, List, Optional, Union
import uuid
from wsagent.tools.schemas.base import SchemaToolResponse
from wsagent.utils.validate_args import validate_required_args
from typing import Any, Generic, TypeVar, Optional, Dict, Union

TInput = TypeVar('TInput')
TParameters = TypeVar('TParameters')
TContent = TypeVar('TContent')
TUsage = TypeVar('TUsage')
TCost = TypeVar('TCost')

class ToolResponse(SchemaToolResponse[TInput, TParameters, TContent, TUsage, TCost]):
    @validate_required_args
    def __init__(self,
        input: TInput,
        parameters: TParameters,
        content: TContent,
        usage: TUsage,
        cost: TCost,
        init_timestamp: Optional[Union[float,int]] = None,
        error_msg: Optional[str] = None,
        status: Optional[bool] = None,
        raw_response: Optional[dict] = None,
    ):
        
        super().__init__(
            input=input,
            parameters=parameters,
            content=content,
            usage=usage,
            cost=cost,
            init_timestamp=init_timestamp,
            error_msg=error_msg,
            status=status,
            raw_response=raw_response
        )
        
        if init_timestamp is None: raise ValueError("init_timestamp is required")
        if input is None: raise ValueError("input is required")
        if content is None: content=[]
        if usage is None: usage=[] 
        if cost is None: cost=[]
        if error_msg is None: raise ValueError("error_msg is required")
        if status is None: raise ValueError("status is required")
        if raw_response is None: raise ValueError("raw_response is required")
        
        self.id=str(uuid.uuid4())
        self.init_timestamp=init_timestamp
        self.time_exec=time.time() - init_timestamp
        self.error_msg=error_msg
        self.status=status
        self.raw_response=raw_response
    
    def to_json(self):
        def serialize(obj):
            if hasattr(obj, "to_dict"):
                return obj.to_dict()
            elif isinstance(obj, list):
                return [serialize(item) for item in obj]
            elif isinstance(obj, dict):
                return {key: serialize(value) for key, value in obj.items()}
            elif isinstance(obj, (int, float, str, bool, type(None))):  # check for basic types
                return obj
            else:
                return str(obj)  # default to string for any other types that are not recognized

        return {key: serialize(value) for key, value in self.__dict__.items()}

    @property
    def result(self):
        return self.content.result()