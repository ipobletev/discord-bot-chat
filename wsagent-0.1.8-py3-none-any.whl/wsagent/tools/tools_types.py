from enum import Enum
import inspect
from wsagent.tools.type.file_system.list_directory.list_directory import ListDirectory
from wsagent.tools.type.file_system.keyword_search.keyword_search import KeywordSearch
from wsagent.tools.type.file_system.pdf_keyword_search.pdf_keyword_search import PDFKeywordSearch
from wsagent.tools.type.file_system.search_dir_regex.search_dir_regex import SearchDirRegex
from wsagent.tools.type.file_system.search_directory.search_directory import SearchDirectory

class ToolsTypes:

    @classmethod
    def get_all_tools(cls):
        tool_classes = []
        # Loop through all attributes in class
        for name, attribute in cls.__dict__.items():
            # Check if attribute is a subclass of Enum
            if inspect.isclass(attribute) and issubclass(attribute, Enum):
                # Add all enum members to the list
                tool_classes.extend([member.value for member in attribute])
        return tool_classes
    
    class FileSystem(Enum):
        KEYWORD_SEARCH = KeywordSearch
        LIST_DIRECTORY = ListDirectory
        SEARCH_DIRECTORY = SearchDirectory
        PDF_KEYWORD_SEARCH = PDFKeywordSearch
        SEARCH_DIR_REGEX = SearchDirRegex
    
