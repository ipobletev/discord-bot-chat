from abc import ABC, abstractmethod
import logging
from typing import Any, Callable, List, Optional
from wsagent.tools.parameter import Parameter, TYPE_MAP, ToolExecutionError
from wsagent.utils.logs import PrintAndLog

class Tool(ABC):
    """Represents a tool that can be configured and executed.
    
    Attributes:
        _name (str): The name of the tool.
        name (callable): The function that the tool executes.
        _description (str): A description of what the tool does.
        _arguments (list of Parameter): The expected arguments for the function.
        log (Logger): A logging instance for the tool.
    """
    
    def __init__(
        self,
        name: Optional[str] = None,
        description: Optional[str] = None,
        arguments: Optional[List[Parameter]] = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ) -> None:
        """Initialize a new Tool instance.
        
        Args:
            name (Optional[str]): The name of the tool.
            func (Callable): The function that the tool executes.
            description (Optional[str]): A description of the tool.
            arguments (Optional[List[Parameter]]): Parameters that define expected arguments.
        """
        self._name = name
        self._description = description
        
        self.arguments = arguments or []
        self.log_name=f'{log_name}.tools.{self._name}'
        self.log_path=f'{log_path}/tools'
        self.enable_log_file=enable_log_file
        self.enable_log_stream=enable_log_stream
        
        self.log = PrintAndLog(
            log_name=self.log_name,
            log_path=self.log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        ).logger
           
    @property
    def name(self) -> str:
        """Gets the name of the tool."""
        return self._name

    @property
    def description(self) -> str:
        """Gets the description of the tool."""
        return self._description

    def _validate_arguments(self, *args, **kwargs):
        """Validates the arguments passed to the tool against the expected parameters.
        
        Args:
            *args: Positional arguments to validate.
            **kwargs: Keyword arguments to validate.
        
        Raises:
            ToolExecutionError: If any argument is not of the expected type.
        """
        for i, arg in enumerate(args):
            if not isinstance(arg, self.arguments[i].type):
                self.log.info(
                    f"Argument {self.arguments[i]._name} ({i}): "
                    f"Expected {self.arguments[i].type}, got {type(arg)}"
                )
                raise ToolExecutionError(
                    f"Argument {self.arguments[i]._name} ({i}): "
                    f"Expected {self.arguments[i].type}, got {type(arg)}"
                )

        for key, value in kwargs.items():
            matching_args = [arg for arg in self.arguments if arg._name == key]
            if not matching_args:
                self.log.info(f"Unexpected argument: {key}")
                raise ToolExecutionError(f"Unexpected argument: {key}")
            arg = matching_args[0]
            if not isinstance(value, arg.type):
                self.log.info(
                    f"Argument {arg._name}: Expected {arg.type}, got {type(value)}"
                )
                raise ToolExecutionError(
                    f"Argument {arg._name}: Expected {arg.type}, got {type(value)}"
                )

    def run(self, *args, **kwargs):
        """Executes the tool's function with the given arguments.
        
        Args:
            *args: Positional arguments for the function.
            **kwargs: Named arguments for the function.
            
        Returns:
            The result of the function execution.
            
        Raises:
            ToolExecutionError: If execution of the function fails.
        """
        self.log.info(f"Executing {self._name} with args: {args} and kwargs: {kwargs}")
        self._validate_arguments(*args, **kwargs)
        try:
            result = self.execute(*args, **kwargs)
            self.log.info(f"Result: {result}")
        except Exception as e:
            self.log.info(f"Error executing {self._name}: {e}")
            raise ToolExecutionError(f"Error executing {self._name}: {e}")
        return result
    
    def get_schema(self) -> dict:
        """Returns a schema dictionary reflecting the tool's configuration.
        
        Returns:
            dict: A JSON schema representation of the tool and its parameters.
        """
        schema = {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {},
                    "required": [arg.name for arg in self.arguments if arg.required]
                }
            }
        }
        # Property schema for each argument
        for arg in self.arguments:
            arg_schema = {
                "type": TYPE_MAP.get(arg.type, "string"),
                "description": arg.description
            }
            if arg.type == list and arg.item_type:
                arg_schema["items"] = {"type": TYPE_MAP.get(arg.item_type, "string")}
            schema["function"]["parameters"]["properties"][arg._name] = arg_schema
        return schema
    
    @abstractmethod
    async def execute(self,
        *args, **kwargs
    ):
        pass
        