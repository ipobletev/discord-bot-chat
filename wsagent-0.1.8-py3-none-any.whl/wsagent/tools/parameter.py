from typing import Optional, Type, Any

TYPE_MAP = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
    type(None): "null",
}

class ToolExecutionError(Exception):
    """Base exception class for errors during tool execution."""
    pass

class Parameter:
    """Represents a parameter with a type, description, and other metadata."""

    def __init__(self, 
        name: Optional[str] = None, 
        description: Optional[str] = None, 
        type: Optional[Type[Any]] = None, 
        item_type: Optional[Type[Any]] = None,
        required: bool = False
    ) -> None:
        self._name = name
        self._description = description
        self._type = type
        self._item_type = item_type
        self._required = required

    # Using @property makes attribute access for the user much more intuitive
    @property
    def item_type(self) -> Optional[Type[Any]]:
        return self._item_type

    @property
    def name(self) -> Optional[str]:
        """Return the parameter's name."""
        return self._name

    @property
    def type(self) -> Optional[Type[Any]]:
        """Return the parameter's type."""
        return self._type

    @property
    def required(self) -> bool:
        """Return whether the parameter is required."""
        return self._required
    
    @property
    def description(self) -> Optional[str]:
        """Return the parameter's description."""
        return self._description