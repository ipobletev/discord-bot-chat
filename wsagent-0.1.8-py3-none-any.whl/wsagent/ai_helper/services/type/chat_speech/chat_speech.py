import subprocess
from datetime import datetime
from enum import Enum
from typing import Optional, Union
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_helper.schemas.ai_helper_response import AIHelperResponse
from wsagent.ai_services.ai_services_interface import AIServicesInterface
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.validate_args import validate_required_args
import asyncio

@validate_required_args
async def aihelper_chat_speech(
    ai_service_interface: Optional[AIServicesInterface] = None, 
    action: Optional[Union[Enum,str]] = None, 
    action_params: Optional[dict] = None
) -> AIHelperResponse:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if action_params is None: action_params={}
    
    messages: list = action_params.get('messages', None)
    llm_model = action_params.get('llm_model', None)
    audio_model = action_params.get('audio_model', None)
    voice = action_params.get('voice', None)
    stream = action_params.get('stream', False)
    stop_event: asyncio.Event = action_params.get('stop_event', False)
    
    # Required parameters
    if messages is None: raise ValueError("messages must be provided")
    
    # Optional parameters
    if llm_model is None: llm_model = AIHelper.OpenAI.Chat.Models.GPT_4_O
    if audio_model is None: audio_model = AIHelper.OpenAI.Audio.Models.WHISPER_1
    if voice is None: voice = AIHelper.OpenAI.Audio.Voices.ALLOY
    
    # Add the video content to the messages
    action_params['model'] = llm_model
    
    text_responses: AIServiceResponse = ai_service_interface.execute(
        action=AIHelper.Action.CHAT, 
        action_params = action_params
    )

    # Initialize a buffer to store the concatenated text
    concatenated_text = ''
    final_text_response=None
    final_audio_responses=None

    # Initialize the ffplay process once
    ffplay_cmd = ['ffplay', '-autoexit', '-', '-nodisp', '-loglevel', 'quiet']
    ffplay_proc = subprocess.Popen(ffplay_cmd, stdin=subprocess.PIPE)
    
    text_chunk = ''
    audio_queue = asyncio.Queue()

    async def process_audio_queue():
        while True:
            if stop_event.is_set():
                if ffplay_proc.stdin:
                    ffplay_proc.stdin.close()
                ffplay_proc.terminate()  # Ensure the process is terminated
                await asyncio.sleep(0.1)  # Optional: Give it some time to clean up
                break
            concatenated_text = await audio_queue.get()
            if concatenated_text is None:
                break
            action_params['model'] = audio_model
            action_params['text'] = concatenated_text
            audio_responses = ai_service_interface.execute(
                action=AIHelper.Action.AUDIO_TEXT_TO_SPEECH,
                action_params=action_params
            )
            nonlocal final_audio_responses
            async for audio_chunk in audio_responses:
                if stop_event.is_set():
                    if ffplay_proc.stdin:
                        ffplay_proc.stdin.close()
                    ffplay_proc.terminate()  # Ensure the process is terminated
                    await asyncio.sleep(0.1)  # Optional: Give it some time to clean up
                    break
                if isinstance(audio_chunk, AIServiceResponse):
                    final_audio_responses = audio_chunk
                    continue
                try:
                    ffplay_proc.stdin.write(audio_chunk)
                except Exception as e:
                    raise e

    audio_task = asyncio.create_task(process_audio_queue())

    # Iterate over the response chunks
    async for chunk in text_responses:
        if isinstance(chunk, AIServiceResponse):
            final_text_response = chunk
            text_chunk = final_text_response.result[0]
            if stream:
                text_chunk = "."
        else:
            text_chunk = chunk
            yield text_chunk
        
        concatenated_text += text_chunk

        # Check if concatenated_text forms a phrase
        if concatenated_text.strip().endswith('.') or not stream:
            await audio_queue.put(concatenated_text)
            concatenated_text = ''

    # Signal the audio processing to complete
    await audio_queue.put(None)
    await audio_task

    # Wait for the audio processing to complete
    if not stop_event.is_set():
        ffplay_proc.stdin.close()
        ffplay_proc.wait()
    
    cost = final_text_response.cost['total_cost'] + final_audio_responses.cost['total_cost']
    
    additional_data = {
        "text_service": final_text_response,
        "audio_service": final_audio_responses
    }
    
    raw_response = {
        "text_raw_responses": final_text_response.raw_response,
        "audio_raw_responses": final_audio_responses.raw_response
    }
    
    yield AIHelperResponse(
        result=final_text_response.result,
        action=action,
        action_params=action_params,
        additional_data=additional_data,
        cost={
            "total_cost": cost
        },
        usage=final_text_response.usage,
        init_timestamp=init_timestamp,
        raw_response=raw_response
    )