from datetime import datetime
from typing import Optional, Union, cast
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_helper.schemas.ai_helper_response import AIHelperResponse
from wsagent.ai_services.ai_services_interface import AIServicesInterface
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def aihelper_edit_image(
    ai_service_interface: Optional[AIServicesInterface] = None, 
    action: Optional[Union[AIHelper.Action,str]] = None,
    action_params: Optional[dict] = None
) -> AIHelperResponse:
    
    init_timestamp=datetime.now().timestamp()
    response=None
    
    if action is None: raise ValueError("action must be provided")
    if action_params is None: action_params={}
    
    # All parameters for this method
    ## action_params
    image_path = action_params.get('image_path', None)
    prompt = action_params.get('prompt', None)
    mask_path = action_params.get('mask_path', None)
    model = action_params.get('model', None)
    n = action_params.get('n', None)
    size = action_params.get('size', None)
    response_format = action_params.get('response_format', None)
    user = action_params.get('user', None)
    retries = action_params.get('retries', None)
    backoff_base = action_params.get('backoff_base', None)
        
    responses = ai_service_interface.execute(
        action=action, 
        action_params = {
            "model": model,
            "image_path": image_path,
            "mask_path": mask_path,
            "prompt": prompt,
            "n": n,
            "response_format": response_format,
            "size": size,
            "user": user,
            "retries": retries,
            "backoff_base": backoff_base
        }
    )
    async for response in responses:
        response: AIServiceResponse = response
    
    yield AIHelperResponse(
        result=response.result,
        action=response.action,
        action_params=response.action_params,
        additional_data=response.additional_data,
        cost=response.cost,
        usage=response.usage,
        init_timestamp=init_timestamp,
        raw_response=response.raw_response
    )