from datetime import datetime
from typing import Optional, Union, cast
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_helper.schemas.ai_helper_response import AIHelperResponse
from wsagent.ai_services.ai_services_interface import AIServicesInterface
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def aihelper_embedding(
    ai_service_interface: Optional[AIServicesInterface] = None, 
    action: Optional[Union[AIHelper.Action,str]] = None,
    action_params: Optional[dict] = None,
) -> AIHelperResponse:
    
    init_timestamp=datetime.now().timestamp()
    response=None
    
    if action is None: raise ValueError("action must be provided")
    if action_params is None: action_params={}
        
    responses = ai_service_interface.execute(
        action=action, 
        action_params=action_params
    )
    async for response in responses:
        response: AIServiceResponse = response
    
    yield AIHelperResponse(
        result=response.result,
        action=response.action,
        action_params=response.action_params,
        additional_data=response.additional_data,
        cost=response.cost,
        usage=response.usage,
        init_timestamp=init_timestamp,
        raw_response=response.raw_response
    )