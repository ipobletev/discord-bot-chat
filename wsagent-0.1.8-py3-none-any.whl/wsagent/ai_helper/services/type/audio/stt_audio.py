from datetime import datetime
from typing import Optional, Union
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_helper.schemas.ai_helper_response import AIHelperResponse
from wsagent.ai_services.ai_services_interface import AIServicesInterface
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def aihelper_stt_audio(
    ai_service_interface: Optional[AIServicesInterface] = None, 
    action: Optional[Union[AIHelper.Action,str]] = None,
    action_params: Optional[dict] = None
) -> AIHelperResponse:

    init_timestamp=datetime.now().timestamp()
    response=None
    
    responses = ai_service_interface.execute(
        action=action, 
        action_params=action_params
    )
    async for response in responses:
        # If the response is not an AIServiceResponse, yield it
        if not isinstance(response, AIServiceResponse):
            yield response
    
    final_response: AIServiceResponse = response
    
    yield AIHelperResponse(
        result=final_response.result,
        action=final_response.action,
        action_params=final_response.action_params,
        additional_data=final_response.additional_data,
        cost=final_response.cost,
        usage=final_response.usage,
        init_timestamp=init_timestamp,
        raw_response=final_response.raw_response
    )