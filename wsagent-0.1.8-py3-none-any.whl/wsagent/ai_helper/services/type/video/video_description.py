import os
import cv2
from moviepy.editor import VideoFileClip
import base64
from datetime import datetime
from enum import Enum
from typing import Optional, Union
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_helper.schemas.ai_helper_response import AIHelperResponse
from wsagent.ai_services.ai_services_interface import AIServicesInterface
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def aihelper_video_description(
    ai_service_interface: Optional[AIServicesInterface] = None, 
    action: Optional[Union[Enum,str]] = None, 
    action_params: Optional[dict] = None
) -> AIHelperResponse:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if action_params is None: action_params={}
    
    video_path: str = action_params.get('video_path', None)
    out_audio_path: str = action_params.get('out_audio_path', None)
    seconds_per_frame: int = action_params.get('seconds_per_frame', None)
    messages: list = action_params.get('messages', None)
    llm_model = action_params.get('llm_model', None)
    audio_model = action_params.get('audio_model', None)
    
    # Required parameters
    if video_path is None: raise ValueError("video_path must be provided")
    
    # Optional parameters
    if seconds_per_frame is None: seconds_per_frame = 1
    if llm_model is None: llm_model = AIHelper.Models.OpenAI.Chat.GPT_4_O
    if audio_model is None: audio_model = AIHelper.Models.OpenAI.Audio.WHISPER_1

    # Extract frames from video
    base64Frames, audio_path = process_video(
        video_path=video_path, 
        out_audio_path=out_audio_path, 
        seconds_per_frame=seconds_per_frame
    )
    # Create transcription of the audio
    action_params["model"] = audio_model
    action_params["path_file"] = audio_path
    transcription=''
    async for response in ai_service_interface.execute(
        action=AIHelper.Action.AUDIO_SPEECH_TO_TEXT, 
        action_params = action_params
    ):
        if isinstance(response, AIServiceResponse):
            transcription = response.result
    
    # Add the video content to the messages
    messages_video_content = [
        {"role": "user", "content": [ 
            {"type": "text", "text": "You are generating a video summary. Create a summary of the provided video and its transcript."},
            *map(lambda x: {"type": "image_url","image_url": {"url": f'data:image/jpg;base64,{x}', "detail": "low"}}, base64Frames),
            {"type": "text", "text": f"The audio transcription is: {transcription}"}]
        }
    ]
    action_params['messages'] = messages_video_content + messages
    action_params['model'] = llm_model
    
    responses = ai_service_interface.execute(
        action=AIHelper.Action.CHAT, 
        action_params = action_params
    )
    async for response in responses:
        # If the response is not an AIServiceResponse, yield it
        if not isinstance(response, AIServiceResponse):
            yield response
    
    final_response: AIServiceResponse = response
    
    yield AIHelperResponse(
        result=final_response.result,
        action=final_response.action,
        action_params=final_response.action_params,
        additional_data=final_response.additional_data,
        cost=final_response.cost,
        usage=final_response.usage,
        init_timestamp=init_timestamp,
        raw_response=final_response.raw_response
    )
    
def process_video(
    video_path: str, 
    out_audio_path: str, 
    seconds_per_frame: int
):
    
    base64Frames = []
    base_video_path = os.path.dirname(video_path)
    file_name = os.path.splitext(os.path.basename(video_path))[0]
    if out_audio_path is None: out_audio_path = f"{base_video_path}/temp_{file_name}.mp3"

    video = cv2.VideoCapture(video_path)
    total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = video.get(cv2.CAP_PROP_FPS)
    frames_to_skip = int(fps * seconds_per_frame)
    curr_frame=0

    # Loop through the video and extract frames at specified sampling rate
    while curr_frame < total_frames - 1:
        video.set(cv2.CAP_PROP_POS_FRAMES, curr_frame)
        success, frame = video.read()
        if not success:
            break
        _, buffer = cv2.imencode(".jpg", frame)
        base64Frames.append(base64.b64encode(buffer).decode("utf-8"))
        curr_frame += frames_to_skip
    video.release()

    # Extract audio from video
    clip = VideoFileClip(video_path)
    clip.audio.write_audiofile(out_audio_path, verbose=False, bitrate="32k")
    clip.audio.close()
    clip.close()

    return base64Frames, out_audio_path