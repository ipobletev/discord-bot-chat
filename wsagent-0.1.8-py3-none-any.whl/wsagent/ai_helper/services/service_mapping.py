
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_helper.services.type.chat.chat import aihelper_chat
from wsagent.ai_helper.services.type.embedding.embedding import aihelper_embedding
from wsagent.ai_helper.services.type.audio.tts_audio import aihelper_tts_audio
from wsagent.ai_helper.services.type.audio.stt_audio import aihelper_stt_audio
from wsagent.ai_helper.services.type.image.create_image import aihelper_create_image
from wsagent.ai_helper.services.type.image.variation_image import aihelper_variation_image
from wsagent.ai_helper.services.type.image.edit_image import aihelper_edit_image
from wsagent.ai_helper.services.type.video.video_description import aihelper_video_description
from wsagent.ai_helper.services.type.chat_speech.chat_speech import aihelper_chat_speech

aihelper_service_mapping = {
    AIHelper.Action.CHAT.value: aihelper_chat,
    AIHelper.Action.CHAT_SPEECH.value: aihelper_chat_speech,
    AIHelper.Action.EMBEDDING.value: aihelper_embedding,
    AIHelper.Action.AUDIO_TEXT_TO_SPEECH.value: aihelper_tts_audio,
    AIHelper.Action.AUDIO_SPEECH_TO_TEXT.value: aihelper_stt_audio,
    AIHelper.Action.IMAGE_CREATE.value: aihelper_create_image,
    AIHelper.Action.IMAGE_VARIATION.value: aihelper_variation_image,
    AIHelper.Action.IMAGE_EDIT.value: aihelper_edit_image,
    AIHelper.Action.VIDEO_DESCRIPTION.value: aihelper_video_description,
}