import asyncio
from typing import Optional, Union
import uuid
from wsagent.ai_helper.schemas.ai_helper_response import AIHelperResponse
from wsagent.ai_helper.ai_helper_enum import AIHelper
from wsagent.ai_services.ai_services_interface import AIServicesInterface
from wsagent.ai_helper.services.service_mapping import aihelper_service_mapping

class AIHelperInterface:
    """   
    ### Brief


    
    ### Parameters of ai_service_params
    
    

    ### Init example to use:
    ```

    ```
    """

    def __init__(self, 
        ai_service_params: Optional[dict]=None,
        session_id: Optional[str]=None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ):

        # Set default values
        if ai_service_params is None: ai_service_params={}
        
        self.ai_service_params=ai_service_params
        
        if session_id:
            self.log_name = f'{log_name}.{session_id}.ah'
            self.log_path = f'{log_path}/{session_id}/ah'
        else:
            self.log_name=f'{log_name}.ah'
            self.log_path=f'{log_path}/ah'

        self.ai_service_interface = AIServicesInterface(
            ai_service_params=ai_service_params,
            session_id=None,
            log_name=self.log_name,
            log_path=self.log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )

    async def execute(self,
        action: Optional[Union[AIHelper.Action,str]] = None,
        action_params: Optional[dict] = None,
    ) -> AIHelperResponse:
        
        if action is None: raise ValueError("action must be provided.")
        if action_params is None: ValueError("action_params must be provided.")
        # if action_params["model"] is None: raise ValueError("model is required")
        
        function_to_call = aihelper_service_mapping.get(action.value)
        if function_to_call == None:
            raise ValueError(f"Function to call not found: {action.value}")
            
        # Check if function_to_call is a coroutine function
        if function_to_call:
            async for result in function_to_call( 
                ai_service_interface=self.ai_service_interface,
                action=action,
                action_params=action_params,
            ):
                yield result
        else:
            raise ValueError(f"Function to call is not a coroutine function: {action}")