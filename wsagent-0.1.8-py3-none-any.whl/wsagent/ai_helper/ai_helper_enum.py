from enum import Enum, auto

from wsagent.ai_services.ai_services_enum import AIServices

# Master Storage definitions
class AIHelper:

    class Action(Enum):
        CHAT                    = "CHAT_CREATE"
        CHAT_SPEECH             = "CHAT_SPEECH"
        EMBEDDING               = "EMBEDDING_CREATE"
        AUDIO_TEXT_TO_SPEECH    = "TEXT_TO_SPEECH"
        AUDIO_SPEECH_TO_TEXT    = "SPEECH_TO_TEXT"
        AUDIO_SPEECH_TO_SPEECH  = "SPEECH_TO_SPEECH"
        AUDIO_SOUND_EFFECTS     = "SOUND_EFFECTS"
        IMAGE_CREATE            = "IMAGE_CREATE"
        IMAGE_VARIATION         = "IMAGE_VARIATION"
        IMAGE_EDIT              = "IMAGE_EDIT"
        VIDEO_DESCRIPTION       = "VIDEO_DESCRIPTION"

        @property
        def name(self):
            return self.value
         
    # AI Services Definitions
    
    class OpenAI:
        
        class Chat:
            
            class Models(Enum):
                # Text
                GPT_3_5_TURBO               = AIServices.OpenAI.Feature.LLM.Model.GPT_3_5_TURBO.name
                GPT_3_5_TURBO_0125          = AIServices.OpenAI.Feature.LLM.Model.GPT_3_5_TURBO_0125.name
                GPT_3_5_TURBO_1106          = AIServices.OpenAI.Feature.LLM.Model.GPT_3_5_TURBO_1106.name
                GPT_4                       = AIServices.OpenAI.Feature.LLM.Model.GPT_4.name
                GPT_4_0613                  = AIServices.OpenAI.Feature.LLM.Model.GPT_4_0613.name
                GPT_4_1106_PREVIEW          = AIServices.OpenAI.Feature.LLM.Model.GPT_4_1106_PREVIEW.name
                GPT_4_0125_PREVIEW          = AIServices.OpenAI.Feature.LLM.Model.GPT_4_0125_PREVIEW.name
                GPT_4_TURBO_PREVIEW         = AIServices.OpenAI.Feature.LLM.Model.GPT_4_TURBO_PREVIEW.name
                GPT_4_TURBO_2024_04_09      = AIServices.OpenAI.Feature.LLM.Model.GPT_4_TURBO_2024_04_09.name
                
                #Vision
                GPT_4_TURBO                 = AIServices.OpenAI.Feature.LLM.Model.GPT_4_TURBO.name          
                GPT_4_VISION_PREVIEW        = AIServices.OpenAI.Feature.LLM.Model.GPT_4_VISION_PREVIEW.name    
                GPT_4_1106_VISION_PREVIEW   = AIServices.OpenAI.Feature.LLM.Model.GPT_4_1106_VISION_PREVIEW.name

                # Omni
                GPT_4_O_MINI                = AIServices.OpenAI.Feature.LLM.Model.GPT_4_O_MINI.name
                GPT_4_O_MINI_2024_07_18     = AIServices.OpenAI.Feature.LLM.Model.GPT_4_O_MINI_2024_07_18.name
                GPT_4_O                     = AIServices.OpenAI.Feature.LLM.Model.GPT_4_O.name   
                GPT_4_O_2024_05_13          = AIServices.OpenAI.Feature.LLM.Model.GPT_4_O_2024_05_13.name

                @property
                def name(self):
                    return self.value 
                
        class Embedding:
            
            class Models(Enum):

                ADA_V2                      = AIServices.OpenAI.Feature.Embeddings.Model.ADA_V2.name
                SMALL_V3                    = AIServices.OpenAI.Feature.Embeddings.Model.SMALL_V3.name
                LARGE_V3                    = AIServices.OpenAI.Feature.Embeddings.Model.LARGE_V3.name

                @property
                def name(self):
                    return self.value 

        class Audio:
            
            class Models(Enum):

                # TTS
                TTS_1                       = AIServices.OpenAI.Feature.Audio.Model.TTS_1.name
                TTS_1_HD                    = AIServices.OpenAI.Feature.Audio.Model.TTS_1_HD.name
                # STT
                WHISPER_1                   = AIServices.OpenAI.Feature.Audio.Model.WHISPER_1.name
                
                @property
                def name(self):
                    return self.value 
            
            class Voices(Enum):
                
                ALLOY           = AIServices.OpenAI.Feature.Audio.Voices.ALLOY.value
                ECHO            = AIServices.OpenAI.Feature.Audio.Voices.ECHO.value
                FABLE           = AIServices.OpenAI.Feature.Audio.Voices.FABLE.value
                ONYX            = AIServices.OpenAI.Feature.Audio.Voices.ONYX.value
                NOVA            = AIServices.OpenAI.Feature.Audio.Voices.NOVA.value
                SHIMMER         = AIServices.OpenAI.Feature.Audio.Voices.SHIMMER.value
            
        class Image:
            
            class Models(Enum):

                # Image
                DALL_E_3                    = AIServices.OpenAI.Feature.Image.Model.DALL_E_3.name
                DALL_E_2                    = AIServices.OpenAI.Feature.Image.Model.DALL_E_2.name
                
                @property
                def name(self):
                    return self.value
            
    class Anthropic:
        
        class Chat:
            
            class Models(Enum):

                # Text Model
                CLAUDE_2_1                  = AIServices.AnthropicAI.Feature.LLM.Model.CLAUDE_2_1.name
                CLAUDE_2_0                  = AIServices.AnthropicAI.Feature.LLM.Model.CLAUDE_2_0.name
                CLAUDE_INSTANT_1_2          = AIServices.AnthropicAI.Feature.LLM.Model.CLAUDE_INSTANT_1_2.name
                # Vision Model
                CLAUDE_3_OPUS               = AIServices.AnthropicAI.Feature.LLM.Model.CLAUDE_3_OPUS.name
                CLAUDE_3_SONNET             = AIServices.AnthropicAI.Feature.LLM.Model.CLAUDE_3_SONNET.name
                CLAUDE_3_HAIKU              = AIServices.AnthropicAI.Feature.LLM.Model.CLAUDE_3_HAIKU.name
                CLAUDE_3_5_SONNET           = AIServices.AnthropicAI.Feature.LLM.Model.CLAUDE_3_5_SONNET.name

                @property
                def name(self):
                    return self.value 
            
    class Groq:
        
        class Chat:
            
            class Models(Enum):

                # Text Model
                LLAMA3_8B_8192_TOOL_PREVIEW = AIServices.GroqAI.Feature.LLM.Model.LLAMA3_8B_8192_TOOL_PREVIEW.name
                LLAMA3_70B_8192_TOOL_PREVIEW= AIServices.GroqAI.Feature.LLM.Model.LLAMA3_70B_8192_TOOL_PREVIEW.name
                LLAMA3_8B_8192              = AIServices.GroqAI.Feature.LLM.Model.LLAMA3_8B_8192.name
                LLAMA3_70B_8192             = AIServices.GroqAI.Feature.LLM.Model.LLAMA3_70B_8192.name
                LLAMA3_1_8B_INSTANT         = AIServices.GroqAI.Feature.LLM.Model.LLAMA3_1_8B_INSTANT.name
                LLAMA3_1_70B_VERSATILE      = AIServices.GroqAI.Feature.LLM.Model.LLAMA3_1_70B_VERSATILE.name
                MIXTRAL_8X7_32768           = AIServices.GroqAI.Feature.LLM.Model.MIXTRAL_8X7_32768.name
                GEMMA2_9B_IT                = AIServices.GroqAI.Feature.LLM.Model.GEMMA2_9B_IT.name
                GEMMA_7B_IT                 = AIServices.GroqAI.Feature.LLM.Model.GEMMA_7B_IT.name
                
                @property
                def name(self):
                    return self.value    

    class ElevenLabs:

        class Audio:
            
            class Models(Enum):
                # TTS
                MULTILOINGUAL_V2        = AIServices.ElevenLabs.Feature.Audio.Model.MULTILINGUAL_V2.name
                MULTILOINGUAL_V1        = AIServices.ElevenLabs.Feature.Audio.Model.MULTILINGUAL_V1.name
                MONOLINGUAL_V1          = AIServices.ElevenLabs.Feature.Audio.Model.MONOLINGUAL_V1.name
                TURBO_V2                = AIServices.ElevenLabs.Feature.Audio.Model.TURBO_V2.name
                # STS
                MULTILINGUAL_STS_V2     = AIServices.ElevenLabs.Feature.Audio.Model.MULTILINGUAL_STS_V2.name
                
                @property
                def name(self):
                    return self.value 
        
            class Voices(Enum):
                RACHEL = AIServices.ElevenLabs.Feature.Audio.Voices.RACHEL.value
                DREW = AIServices.ElevenLabs.Feature.Audio.Voices.DREW.value
                CLYDE = AIServices.ElevenLabs.Feature.Audio.Voices.CLYDE.value
                PAUL = AIServices.ElevenLabs.Feature.Audio.Voices.PAUL.value
                DOMI = AIServices.ElevenLabs.Feature.Audio.Voices.DOMI.value
                DAVE = AIServices.ElevenLabs.Feature.Audio.Voices.DAVE.value
                FIN = AIServices.ElevenLabs.Feature.Audio.Voices.FIN.value
                SARAH = AIServices.ElevenLabs.Feature.Audio.Voices.SARAH.value
                ANTONI = AIServices.ElevenLabs.Feature.Audio.Voices.ANTONI.value
                THOMAS = AIServices.ElevenLabs.Feature.Audio.Voices.THOMAS.value
                CHARLIE = AIServices.ElevenLabs.Feature.Audio.Voices.CHARLIE.value
                GEORGE = AIServices.ElevenLabs.Feature.Audio.Voices.GEORGE.value
                EMILY = AIServices.ElevenLabs.Feature.Audio.Voices.EMILY.value
                ELLI = AIServices.ElevenLabs.Feature.Audio.Voices.ELLI.value
                CALLUM = AIServices.ElevenLabs.Feature.Audio.Voices.CALLUM.value
                PATRICK = AIServices.ElevenLabs.Feature.Audio.Voices.PATRICK.value
                HARRY = AIServices.ElevenLabs.Feature.Audio.Voices.HARRY.value
                LIAM = AIServices.ElevenLabs.Feature.Audio.Voices.LIAM.value
                DOROTHY = AIServices.ElevenLabs.Feature.Audio.Voices.DOROTHY.value
                JOSH = AIServices.ElevenLabs.Feature.Audio.Voices.JOSH.value
                ARNOLD = AIServices.ElevenLabs.Feature.Audio.Voices.ARNOLD.value
                CHARLOTTE = AIServices.ElevenLabs.Feature.Audio.Voices.CHARLOTTE.value
                ALICE = AIServices.ElevenLabs.Feature.Audio.Voices.ALICE.value
                MATILDA = AIServices.ElevenLabs.Feature.Audio.Voices.MATILDA.value
                JAMES = AIServices.ElevenLabs.Feature.Audio.Voices.JAMES.value
                JOSEPH = AIServices.ElevenLabs.Feature.Audio.Voices.JOSEPH.value
                JEREMY = AIServices.ElevenLabs.Feature.Audio.Voices.JEREMY.value
                MICHAEL = AIServices.ElevenLabs.Feature.Audio.Voices.MICHAEL.value
                ETHAN = AIServices.ElevenLabs.Feature.Audio.Voices.ETHAN.value
                CHRIS = AIServices.ElevenLabs.Feature.Audio.Voices.CHRIS.value
                GIGI = AIServices.ElevenLabs.Feature.Audio.Voices.GIGI.value
                FREYA = AIServices.ElevenLabs.Feature.Audio.Voices.FREYA.value
                BRIAN = AIServices.ElevenLabs.Feature.Audio.Voices.BRIAN.value
                GRACE = AIServices.ElevenLabs.Feature.Audio.Voices.GRACE.value
                DANIEL = AIServices.ElevenLabs.Feature.Audio.Voices.DANIEL.value
                LILY = AIServices.ElevenLabs.Feature.Audio.Voices.LILY.value
                SERENA = AIServices.ElevenLabs.Feature.Audio.Voices.SERENA.value
                ADAM = AIServices.ElevenLabs.Feature.Audio.Voices.ADAM.value
                NICOLE = AIServices.ElevenLabs.Feature.Audio.Voices.NICOLE.value
                BILL = AIServices.ElevenLabs.Feature.Audio.Voices.BILL.value
                JESSIE = AIServices.ElevenLabs.Feature.Audio.Voices.JESSIE.value
                SAM = AIServices.ElevenLabs.Feature.Audio.Voices.SAM.value
                GLINDA = AIServices.ElevenLabs.Feature.Audio.Voices.GLINDA.value
                GIOVANNI = AIServices.ElevenLabs.Feature.Audio.Voices.GIOVANNI.value
                MIMI = AIServices.ElevenLabs.Feature.Audio.Voices.MIMI.value

    class AzureAI:
        
        class Chat:
            
            class Models(Enum):
                # Text
                GPT_3_5_TURBO_16K           = AIServices.AzureAI.Feature.LLM.Model.GPT_3_5_TURBO_16K.name
                GPT_3_5_TURBO_INSTRUCT      = AIServices.AzureAI.Feature.LLM.Model.GPT_3_5_TURBO_INSTRUCT.name
                GPT_4                       = AIServices.AzureAI.Feature.LLM.Model.GPT_4.name
                GPT_4_32K                   = AIServices.AzureAI.Feature.LLM.Model.GPT_4_32K.name
                
                # Omni
                GPT_4_O                     = AIServices.AzureAI.Feature.LLM.Model.GPT_4_O.name   

                @property
                def name(self):
                    return self.value 
                
        class Embedding:
            
            class Models(Enum):

                ADA_V2                      = AIServices.AzureAI.Feature.Embeddings.Model.ADA_V2.name
                SMALL_V3                    = AIServices.AzureAI.Feature.Embeddings.Model.SMALL_V3.name
                LARGE_V3                    = AIServices.AzureAI.Feature.Embeddings.Model.LARGE_V3.name

                @property
                def name(self):
                    return self.value 

        class Image:
            
            class Models(Enum):

                # Image
                DALL_E_3                    = AIServices.AzureAI.Feature.Image.Model.DALL_E_3.name
                DALL_E_2                    = AIServices.AzureAI.Feature.Image.Model.DALL_E_2.name
                
                @property
                def name(self):
                    return self.value
   
    @classmethod
    def list_actions(cls):
        return [action.name for action in cls.Action]