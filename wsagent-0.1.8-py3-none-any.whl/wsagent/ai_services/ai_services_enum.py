from enum import Enum, auto
from wsagent.ai_services.services.elevenlabs.enums import ElevenLabsEnums
from wsagent.ai_services.services.openai.enums import OpenAIEnums
from wsagent.ai_services.services.azure_ai.enums import AzureAIEnums
from wsagent.ai_services.services.anthropic.enums import AnthropicAIEnums
from wsagent.ai_services.services.groq.enums import GroqAIEnums
# from wsagent.ai_services.services.google_ai.enums import GoogleAIEnums

# Master AI Services definitions
class AIServices:
    OpenAI = OpenAIEnums
    AzureAI = AzureAIEnums
    AnthropicAI = AnthropicAIEnums
    GroqAI = GroqAIEnums
    ElevenLabs = ElevenLabsEnums

    @classmethod
    def get_aiservices_from_action(cls, action):
        for aiservice in cls.get_all_enums_services():
            if action.__module__ == aiservice.__module__:
                return aiservice
                    
    @classmethod
    def get_enum_model_from_model_name(cls, model_name):
        for aiservice in cls.get_all_enums_services():
            feature_class = getattr(aiservice, 'Feature', None)
            if feature_class:
                for feature_name in dir(feature_class):
                    if not feature_name.startswith("__"):
                        feature = getattr(feature_class, feature_name)
                        model_enum = getattr(feature, 'Model', None)
                        if model_enum and issubclass(model_enum, Enum):
                            for model in model_enum:
                                if model.name == model_name:
                                    return model
        
    @classmethod
    def get_aiservices_from_str_model(cls,str_model: str):
        for aiservice in cls.get_all_enums_services():
            aiservice_models = cls.get_models_from_aiservice(aiservice)
            for model in aiservice_models:
                if model == str_model:
                    return aiservice
                        
    @classmethod
    def get_all_model_from_all_aiservice(cls):
        model_names = []
        for aiservice in cls.get_all_enums_services():
            feature_class = getattr(aiservice, 'Feature', None)
            if feature_class:
                for feature_name in dir(feature_class):
                    if not feature_name.startswith("__"):
                        feature = getattr(feature_class, feature_name)
                        model_enum = getattr(feature, 'Model', None)
                        if model_enum and issubclass(model_enum, Enum):
                            for model in model_enum:
                                model_names.append(model.name)
        return model_names
    
    @classmethod
    def get_models_from_aiservice(cls, aiservice):
        model_names = []
        feature_class = getattr(aiservice, 'Feature', None)
        if feature_class:
            for feature_name in dir(feature_class):
                if not feature_name.startswith("__"):
                    feature = getattr(feature_class, feature_name)
                    model_enum = getattr(feature, 'Model', None)
                    if model_enum and issubclass(model_enum, Enum):
                        for model in model_enum:
                            model_names.append(model.name)
        return model_names

    @classmethod
    def get_models_from_aiservice_feature(cls, aiservice_feature):
        model_names = []
        feature_class = getattr(aiservice_feature, 'Model', None)
        if feature_class and issubclass(feature_class, Enum):
            for model in feature_class:
                model_names.append(model.name)
        return model_names
    
    @classmethod
    def get_all_enums_services(cls):
        return [service for service in cls.__dict__.values() if isinstance(service, type)]
