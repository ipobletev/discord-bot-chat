# Exceptions
class StopException(Exception):
    pass