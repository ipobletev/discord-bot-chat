from typing import Dict, Type
from wsagent.ai_services.ai_services_enum import AIServices
from wsagent.ai_services.base import AIServiceBase
from wsagent.ai_services.services.anthropic.anthropic import AnthropicAI
from wsagent.ai_services.services.azure_ai.azure_ai import AzureAI
from wsagent.ai_services.services.elevenlabs.elevenlabs import ElevenLabs
from wsagent.ai_services.services.groq.groq import GroqAI
from wsagent.ai_services.services.openai.openai import OpenAI

class AIServicesRegistry:
    _registry: Dict[AIServices, Type[AIServiceBase]] = {}
    
    @classmethod
    def register_ai_services(cls, ai_services_type: AIServices, ai_service_class: Type[AIServiceBase]) -> None:
        if ai_services_type in cls._registry:
            raise ValueError(f"AIServices type '{ai_services_type}' is already registered.")
        cls._registry[ai_services_type] = ai_service_class

    @classmethod
    def get_ai_services(cls, ai_services_type: AIServices) -> Type[AIServiceBase]:
        if ai_services_type not in cls._registry:
            raise ValueError(f"AIServices type '{ai_services_type}' is not registered.")
        return cls._registry[ai_services_type]
    
AIServicesRegistry.register_ai_services(AIServices.OpenAI, OpenAI)
AIServicesRegistry.register_ai_services(AIServices.GroqAI, GroqAI)
AIServicesRegistry.register_ai_services(AIServices.AzureAI, AzureAI)
AIServicesRegistry.register_ai_services(AIServices.AnthropicAI, AnthropicAI)
AIServicesRegistry.register_ai_services(AIServices.ElevenLabs, ElevenLabs)