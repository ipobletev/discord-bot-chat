from datetime import datetime
from enum import Enum
import logging
from typing import Any, AsyncGenerator, Optional, Union
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.ai_services.services.elevenlabs.utils.cost import calculate_tts_cost
from wsagent.ai_services.services.elevenlabs.headers import elevenlabs_header
from wsagent.ai_services.services.elevenlabs.enums import ElevenLabsEnums
from wsagent.utils.validate_args import validate_required_args
from wsagent.utils.request import request_with_exponential_backoff

@validate_required_args
async def text_to_speech(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AsyncGenerator[Union[str, AIServiceResponse], None]:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    ### Custom
    retries = action_params.get("retries", None)
    backoff_base = action_params.get("backoff_base", None)
    stop_event = action_params.get("stop_event", None)
    ### Header
    api_key = ai_service_params.get("elevenlabs_api_key", None)
    ### path parameters
    voice_id = action_params.get("voice", None)
    ### query parameters
    enable_logging = action_params.get("enable_logging", None)
    optimize_streaming_latency = action_params.get("optimize_streaming_latency", None)
    output_format = action_params.get("output_format", None)
    ### body parameters
    text = action_params.get("text", None)
    model_id = action_params.get("model", None)
    voice_settings = action_params.get("voice_settings", None)
    pronunciation_dictionary_locators = action_params.get("pronunciation_dictionary_locators", None)
    seed = action_params.get("seed", None)
    previous_text = action_params.get("previous_text", None)
    next_text = action_params.get("next_text", None)
    previous_request_ids = action_params.get("previous_request_ids", None)
    next_request_ids = action_params.get("next_request_ids", None)
    
    # Required parameters
    if api_key is None: raise ValueError("elevenlabs_api_key cannot be None")
    if text is None: raise ValueError("text cannot be None")
    if voice_id is None: raise ValueError("voice_id cannot be None")
    
    # Optional parameters with default values
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2

    str_model_id=None
    if isinstance(model_id, str):
        str_model_id = model_id
    elif isinstance(model_id, Enum):
        str_model_id = model_id.name
    else:
        raise ValueError("action must be a string or Enum.")
    str_voice_id=None
    if isinstance(voice_id, Enum):
        str_voice_id = voice_id.value
    elif isinstance(voice_id, str):
        str_voice_id = voice_id
    else:
        raise ValueError("voice must be a string or Enum.")
    
    # Header
    headers=elevenlabs_header.copy()
    headers['Content-Type']= 'application/json'
    
    # Set body data
    data={}
    if text is not None: data['text']=text
    if model_id is not None: data['model_id']=str_model_id
    if voice_settings is not None: data['voice_settings']=voice_settings
    if pronunciation_dictionary_locators is not None: data['pronunciation_dictionary_locators']=pronunciation_dictionary_locators
    if seed is not None: data['seed']=seed
    if previous_text is not None: data['previous_text']=previous_text
    if next_text is not None: data['next_text']=next_text
    if previous_request_ids is not None: data['previous_request_ids']=previous_request_ids
    if next_request_ids is not None: data['next_request_ids']=next_request_ids

    # Set url
    url=f"{ElevenLabsEnums.Endpoints.BASE.url}/{ElevenLabsEnums.Endpoints.TEXT_TO_SPEECH.url}/{str_voice_id}/stream"
    
    # Set params
    params={}
    if enable_logging is not None: params['enable_logging']=enable_logging
    if optimize_streaming_latency is not None: params['optimize_streaming_latency']=optimize_streaming_latency
    if output_format is not None: params['output_format']=output_format
    
    audio_data = bytearray()
    
    async for response in request_with_exponential_backoff(
        stream=True,
        retries=retries,
        stop_event=stop_event,
        backoff_base=backoff_base,
        url=url, 
        headers=headers, 
        json=data, 
        params=params,
        log=log
    ):
        audio_data.extend(response)
        yield response
    
    cost=0
    cost = calculate_tts_cost(
        num_characters=len(text),
        model=str_model_id
    )

    # Generate a output
    yield AIServiceResponse(
        result=audio_data,
        action=action,
        action_params=action_params,
        additional_data=None,
        cost={
            "total_cost": cost
        },
        usage=None,
        init_timestamp=init_timestamp,
        raw_response=None
    )