from datetime import datetime
from enum import Enum
import logging
from typing import Any, AsyncGenerator, Optional, Union
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.ai_services.services.elevenlabs.utils.cost import calculate_tts_cost
from wsagent.ai_services.services.elevenlabs.headers import elevenlabs_header
from wsagent.ai_services.services.elevenlabs.enums import ElevenLabsEnums
from wsagent.utils.validate_args import validate_required_args
from wsagent.utils.request import request_with_exponential_backoff

@validate_required_args
async def sound_effects(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AsyncGenerator[Union[str, AIServiceResponse], None]:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    ### Custom
    retries = action_params.get("retries", None)
    backoff_base = action_params.get("backoff_base", None)
    ### Header
    api_key = ai_service_params.get("elevenlabs_api_key", None)
    ### body parameters
    text = action_params.get("text", None)
    duration_seconds = action_params.get("duration_seconds", None)
    prompt_influence = action_params.get("prompt_influence", None)
    
    # Required parameters
    if api_key is None: raise ValueError("elevenlabs_api_key cannot be None")
    if text is None: raise ValueError("text cannot be None")
    
    # Optional parameters with default values
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2
    
    # Header
    headers=elevenlabs_header.copy()
    headers['Content-Type']= 'application/json'
    
    # Set body data
    data={}
    if text is not None: data['text']=text
    if duration_seconds is not None: data['duration_seconds']=duration_seconds
    if prompt_influence is not None: data['prompt_influence']=prompt_influence

    # Set url
    url=f"{ElevenLabsEnums.Endpoints.BASE.url}/{ElevenLabsEnums.Endpoints.SOUND_EFFECTS.url}"
    
    audio_data = bytearray()
    
    async for response in request_with_exponential_backoff(
        stream=True,
        retries=retries,
        backoff_base=backoff_base,
        url=url, 
        headers=headers, 
        json=data, 
        log=log
    ):
        audio_data.extend(response)
        yield response
    
    cost=0
    # cost = calculate_tts_cost(
    #     num_characters=len(text),
    #     model=str_model_id
    # )

    # Generate a output
    yield AIServiceResponse(
        result=audio_data,
        action=action,
        action_params=action_params,
        additional_data=None,
        cost={
            "total_cost": cost
        },
        usage=None,
        init_timestamp=init_timestamp,
        raw_response=None
    )