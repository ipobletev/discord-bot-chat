from datetime import datetime
from enum import Enum
import logging
from typing import Any, AsyncGenerator, Optional, Union
import audioread
import aiohttp
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.ai_services.services.elevenlabs.utils.cost import calculate_tts_cost
from wsagent.ai_services.services.elevenlabs.headers import elevenlabs_header
from wsagent.ai_services.services.elevenlabs.enums import ElevenLabsEnums
from wsagent.utils.validate_args import validate_required_args
from wsagent.utils.request import request_with_exponential_backoff

@validate_required_args
async def speech_to_speech(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AsyncGenerator[Union[str, AIServiceResponse], None]:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    ### Custom
    retries = action_params.get("retries", None)
    backoff_base = action_params.get("backoff_base", None)
    ### Header
    api_key = ai_service_params.get("elevenlabs_api_key", None)
    ### path parameters
    voice_id = action_params.get("voice", None)
    ### query parameters
    enable_logging=action_params.get("enable_logging", None)
    optimize_streaming_latency=action_params.get("optimize_streaming_latency", None)
    output_format=action_params.get("output_format", None)
    ### body parameters
    audio=action_params.get("audio", None)
    model_id=action_params.get("model", None)
    voice_settings=action_params.get("voice_settings", None)
    seed=action_params.get("seed", None)
    
    # Required parameters
    if api_key is None: raise ValueError("elevenlabs_api_key cannot be None")
    if audio is None: raise ValueError("audio cannot be None")
    
    # Optional parameters with default values
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2

    str_model_id=None
    if isinstance(model_id, str):
        str_model_id = model_id
    elif isinstance(model_id, Enum):
        str_model_id = model_id.name
    else:
        raise ValueError("action must be a string or Enum.")
    str_voice_id=None
    if isinstance(voice_id, Enum):
        str_voice_id = voice_id.value
    elif isinstance(voice_id, str):
        str_voice_id = voice_id
    else:
        raise ValueError("voice must be a string or Enum.")
    
    # Header
    headers=elevenlabs_header.copy()
    
    # Set body form data
    data = aiohttp.FormData()
    data.add_field('audio', open(audio, 'rb'), filename='audio.mp3', content_type='audio/mpeg')
    if str_model_id is not None: data.add_field('model_id', str_model_id)
    if voice_settings is not None: data.add_field('voice_settings', voice_settings)
    if seed is not None: data.add_field('seed', seed)

    # Set url
    url=f"{ElevenLabsEnums.Endpoints.BASE.url}/{ElevenLabsEnums.Endpoints.SPEECH_TO_SPEECH.url}/{str_voice_id}/stream"
    
    # Set params
    params={}
    if enable_logging is not None: params['enable_logging']=enable_logging
    if optimize_streaming_latency is not None: params['optimize_streaming_latency']=optimize_streaming_latency
    if output_format is not None: params['output_format']=output_format
    
    audio_data = bytearray()
    
    async for response in request_with_exponential_backoff(
        stream=True,
        retries=retries,
        backoff_base=backoff_base,
        url=url, 
        headers=headers,
        data=data, 
        params=params,
        log=log
    ):
        audio_data.extend(response)
        yield response
    
    cost=0
    # cost = calculate_tts_cost(
    #     num_characters=len(text),
    #     model=str_model_id
    # )

    # Generate a output
    yield AIServiceResponse(
        result=audio_data,
        action=action,
        action_params=action_params,
        additional_data=None,
        cost={
            "total_cost": cost
        },
        usage=None,
        init_timestamp=init_timestamp,
        raw_response=None
    )