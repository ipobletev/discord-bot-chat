import os
from dotenv import load_dotenv
load_dotenv()

# OpenAI Keys
ELEVENLABS_DEFAULT_MODEL=os.getenv("ELEVENLABS_DEFAULT_MODEL",'')
ELEVENLABS_API_KEY=os.getenv("ELEVENLABS_API_KEY",'')