
from enum import Enum
from typing import Optional, Union
from wsagent.ai_services.ai_services_enum import AIServices

def calculate_tts_cost(
    num_characters: Optional[int]= None,
    model: Optional[Union[Enum,str]]= None,
) -> float:
    
    if num_characters is None: raise Exception("Model is required")
    if model is None: model = AIServices.ElevenLabs.Feature.Audio.Model.MULTILOINGUAL_V2
    
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    enum_model = AIServices.get_enum_model_from_model_name(str_model)
    
    audio_cost = enum_model.cost_usage * num_characters

    return audio_cost