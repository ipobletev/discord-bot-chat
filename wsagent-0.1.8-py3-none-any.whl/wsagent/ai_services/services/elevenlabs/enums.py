from enum import Enum

class ElevenLabsEnums:

    @property
    def name(self):
        return "ElevenLabsEnums"

    class Feature:

        class Audio:
            
            class Model(Enum):
                # TTS                   # model name                        #cost per character (when exceeding free character limit)
                MULTILINGUAL_V2        = ("eleven_multilingual_v2",        0.30/1000)
                MULTILINGUAL_V1        = ("eleven_multilingual_v1",        0.30/1000)
                MONOLINGUAL_V1          = ("eleven_monolingual_v1",         0.30/1000)
                TURBO_V2                = ("eleven_turbo_v2",               0.30/1000)
                # STS
                MULTILINGUAL_STS_V2   = ("eleven_multilingual_sts_v2",    0.30/1000)
                ENGLISH_STS_V21         = ("eleven_english_sts_v2",         0.30/1000)

                @property
                def name(self):
                    return self.value[0]
                
                @property
                def cost_usage(self):
                    return self.value[1]
                
            class Voices(Enum):
                RACHEL = "21m00Tcm4TlvDq8ikWAM"
                DREW = "29vD33N1CtxCmqQRPOHJ"
                CLYDE = "2EiwWnXFnvU5JabPnv8n"
                PAUL = "5Q0t7uMcjvnagumLfvZi"
                DOMI = "AZnzlk1XvdvUeBnXmlld"
                DAVE = "CYw3kZ02Hs0563khs1Fj"
                FIN = "D38z5RcWu1voky8WS1ja"
                SARAH = "EXAVITQu4vr4xnSDxMaL"
                ANTONI = "ErXwobaYiN019PkySvjV"
                THOMAS = "GBv7mTt0atIp3Br8iCZE"
                CHARLIE = "IKne3meq5aSn9XLyUdCD"
                GEORGE = "JBFqnCBsd6RMkjVDRZzb"
                EMILY = "LcfcDJNUP1GQjkzn1xUU"
                ELLI = "MF3mGyEYCl7XYWbV9V6O"
                CALLUM = "N2lVS1w4EtoT3dr4eOWO"
                PATRICK = "ODq5zmih8GrVes37Dizd"
                HARRY = "SOYHLrjzK2X1ezoPC6cr"
                LIAM = "TX3LPaxmHKxFdv7VOQHJ"
                DOROTHY = "ThT5KcBeYPX3keUQqHPh"
                JOSH = "TxGEqnHWrfWFTfGW9XjX"
                ARNOLD = "VR6AewLTigWG4xSOukaG"
                CHARLOTTE = "XB0fDUnXU5powFXDhCwa"
                ALICE = "Xb7hH8MSUJpSbSDYk0k2"
                MATILDA = "XrExE9yKIg1WjnnlVkGX"
                JAMES = "ZQe5CZNOzWyzPSCn5a3c"
                JOSEPH = "Zlb1dXrM653N07WRdFW3"
                JEREMY = "bVMeCyTHy58xNoL34h3p"
                MICHAEL = "flq6f7yk4E4fJM5XTYuZ"
                ETHAN = "g5CIjZEefAph4nQFvHAz"
                CHRIS = "iP95p4xoKVk53GoZ742B"
                GIGI = "jBpfuIE2acCO8z3wKNLl"
                FREYA = "jsCqWAovK2LkecY7zXl4"
                BRIAN = "nPczCjzI2devNBz1zQrb"
                GRACE = "oWAxZDx7w5VEj9dCyTzz"
                DANIEL = "onwK4e9ZLuTAKqWW03F9"
                LILY = "pFZP5JQG7iQjIQuC4Bku"
                SERENA = "pMsXgVXv3BLzUgSXRplE"
                ADAM = "pNInz6obpgDQGcFmaJgB"
                NICOLE = "piTKgcLEGmPE4e6mEKli"
                BILL = "pqHfZKP75CvOlQylNhV4"
                JESSIE = "t0jbNlBVZ17f02VDIeMI"
                SAM = "yoZ06aMxZJJ28mfd3POQ"
                GLINDA = "z9fAnlkpzviPz146aGWa"
                GIOVANNI = "zcAOhNBS3c14rBihAFp1"
                MIMI = "zrHiDhphv9ZnVXBqCLjz"
                
                # shared voices (dont work)
                # KHUSHI = "t0WUmKMVeMLJiTULHrF7"
                # CLAIRE = "6vTyAgAT8PncODBcLjRf"
                # EDNA_E = "FrCDCQwye0euHmliGxP9"
                # KIWI = "VEWZvLXUrFL3O7dUnBSW"
                # RAED = "IK7YYZcSpmlkjKrQxbSn"
                # AMBER = "2BP0mL5uSfNKL5oaqVC0"
                # EDUARDO_ROMAN = "Im4Y9oToz1nxbbKPCFUr"
                # HYZNBERG = "DzcRs71mIqvZ5truEdVC"
                # LARRY_JOHANSEN = "YCKqwWPo1hlDwHMgnGL2"
                # TEST_AARON_2 = "NjR4DuBPZTGgUwPKHA8o"
                # REGINALD = "HYydtQTaNqtXRE78SGv5"
                # JACKSON = "CjiOLGAKfR1l160DOkC4"
                # WINSTON = "85jDBmwOZmkxyLRy3I1Q"
                # MAXI_ARGAMES = "D7fO4LMKxU3UYXGDpTnA"
                # SOFIA_THE_SOFA = "I4UbemA0OeSjFk5m2pln"
                # TARUN_C_DHANRAJ = "NdG3kHGRy8j5sr85kT1g"
                # MR_CLEM = "dDOtpn9FZ9FIj62H5Adj"
                # MAD_SCIENTIST = "DUnzBkwtjRWXPr6wRbmL"
                # BLAIRE_FROST = "RPdRfxxQOaNxn1LtRQqm"
                # LISA = "3Wkq9joP6N76sbFEoUeu"
                # NIA = "6apLrnYQQqBtgzD4BwTE"
                # AMANDA_STARTS = "IM3Iu58MPEcTXngIfwee"
                # ALICIA = "NBcGlQxeT5lFe7hgzwTR"
                # STEPHEN_I = "J9ppVV9auGmTQtfYI50c"
                # AMELIA = "ZF6FPAbjXT4488VcRRnw"
                # DEE = "rr0A91JHKDIrts589ikk"
                # AVANI = "BWjhPmVMf5YVMx6dmM49"
                # CHRIS = "0sKw1e0bDwnqFHZXD2km"
                # ROBERT = "BtWabtumIemAotTjP5sk"
                # BEN = "aTTiK3YzK3dXETpuDE2h"

    class Action:

        class Audio(Enum):
            
            TEXT_TO_SPEECH   = "TEXT_TO_SPEECH"
            SPEECH_TO_TEXT   = "SPEECH_TO_TEXT"
            TRANSLATION      = "TRANSLATION"
            SOUND_EFFECTS    = "SOUND_EFFECTS"
            SPEECH_TO_SPEECH = "SPEECH_TO_SPEECH"

            @property
            def name(self):
                return self.value

    class Endpoints(Enum):
        BASE                = "https://api.elevenlabs.io/v1"
        TEXT_TO_SPEECH      = "text-to-speech"
        DUBBING             = "dubbing"
        SOUND_EFFECTS       = "sound-generation"
        SPEECH_TO_SPEECH    = "speech-to-speech"
        
        @property
        def url(self):
            return self.value