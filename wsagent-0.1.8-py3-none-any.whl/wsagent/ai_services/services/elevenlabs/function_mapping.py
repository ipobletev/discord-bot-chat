# Dispatch dictionary
from wsagent.ai_services.services.elevenlabs.endpoints.audio.sound_effects import sound_effects
from wsagent.ai_services.services.elevenlabs.endpoints.audio.sts import speech_to_speech
from wsagent.ai_services.services.elevenlabs.enums import ElevenLabsEnums
from wsagent.ai_services.services.elevenlabs.endpoints.audio.tts import text_to_speech

elevenlabs_function_map = {
    ### AUDIO ###
    ElevenLabsEnums.Action.Audio.TEXT_TO_SPEECH.value: text_to_speech,
    ElevenLabsEnums.Action.Audio.SOUND_EFFECTS.value: sound_effects,
    ElevenLabsEnums.Action.Audio.SPEECH_TO_SPEECH.value: speech_to_speech,
}