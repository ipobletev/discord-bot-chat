
from wsagent.ai_services.services.elevenlabs.config import ELEVENLABS_API_KEY

elevenlabs_header = {
    'accept': '*/*',
    'xi-api-key': ELEVENLABS_API_KEY,
}