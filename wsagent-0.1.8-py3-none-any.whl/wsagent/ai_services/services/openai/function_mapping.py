

# Dispatch dictionary
from wsagent.ai_services.services.openai.enums import OpenAIEnums
from wsagent.ai_services.services.openai.endpoints.audio.audio import audio_create_speech, audio_create_transcription, audio_create_translation
from wsagent.ai_services.services.openai.endpoints.chat.chat import create_chat_completion
from wsagent.ai_services.services.openai.endpoints.embedding.embedding import create_embedding
from wsagent.ai_services.services.openai.endpoints.assistant.assistant import assistants_create, assistants_delete, assistants_list, assistants_modify, assistants_retrieve
from wsagent.ai_services.services.openai.endpoints.assistant.assistant_file import assistants_file_create, assistants_file_delete, assistants_file_list, assistants_file_retrieve
from wsagent.ai_services.services.openai.endpoints.assistant.messages import thread_messages_create, thread_messages_file_list, thread_messages_file_retrieve, thread_messages_list, thread_messages_modify, thread_messages_retrieve
from wsagent.ai_services.services.openai.endpoints.assistant.thread import thread_create, thread_delete, thread_modify, thread_retrieve
from wsagent.ai_services.services.openai.endpoints.file.file import file_delete, file_list, file_retrieve, file_retrieve_content, file_upload
from wsagent.ai_services.services.openai.endpoints.images.images import image_create, image_edit, image_variation
from wsagent.ai_services.services.openai.endpoints.models.models import models_delete_finetunning_model, models_list, models_retrieve
from wsagent.ai_services.services.openai.endpoints.moderation.moderation import moderation_create
from wsagent.ai_services.services.openai.endpoints.assistant.runs import thread_create_and_run, thread_run_cancel, thread_run_create, thread_run_list, thread_run_modify, thread_run_retrieve, thread_run_step_list, thread_run_step_retrieve

openai_function_map = {
    ### CHAT ###
    OpenAIEnums.Action.Chat.CREATE.value: create_chat_completion,
    ### EMBEDDINGS ###
    OpenAIEnums.Action.Embeddings.CREATE.value: create_embedding,
    ### AUDIO ###
    OpenAIEnums.Action.Audio.TEXT_TO_SPEECH.value: audio_create_speech,
    OpenAIEnums.Action.Audio.SPEECH_TO_TEXT.value: audio_create_transcription,
    OpenAIEnums.Action.Audio.TRANSLATION.value: audio_create_translation,
    ### IMAGES ###
    OpenAIEnums.Action.Images.CREATE.value: image_create,
    OpenAIEnums.Action.Images.EDIT.value: image_edit,
    OpenAIEnums.Action.Images.VARIATION.value: image_variation,
    ### MODELS ###
    OpenAIEnums.Action.Models.LIST.value: models_list,
    OpenAIEnums.Action.Models.RETRIEVE.value: models_retrieve,
    OpenAIEnums.Action.Models.DELETE_FINETUNNING_MODEL.value: models_delete_finetunning_model,
    ### MODERATION ###
    OpenAIEnums.Action.Moderation.CREATE.value: moderation_create,
    ### FILES ###
    OpenAIEnums.Action.File.LIST.value: file_list,
    OpenAIEnums.Action.File.UPLOAD.value: file_upload,
    OpenAIEnums.Action.File.DELETE.value: file_delete,
    OpenAIEnums.Action.File.RETRIEVE.value: file_retrieve,
    OpenAIEnums.Action.File.RETRIEVE_CONTENT.value: file_retrieve_content,
    ### ASSISTANTS ###
    OpenAIEnums.Action.Assistants.CREATE.value: assistants_create,
    OpenAIEnums.Action.Assistants.RETRIEVE.value: assistants_retrieve,
    OpenAIEnums.Action.Assistants.DELETE.value: assistants_delete,
    OpenAIEnums.Action.Assistants.MODIFY.value: assistants_modify,
    OpenAIEnums.Action.Assistants.LIST.value: assistants_list,
    ### ASSISTANTS FILES ###
    OpenAIEnums.Action.Assistants.FILE_CREATE.value: assistants_file_create,
    OpenAIEnums.Action.Assistants.FILE_RETRIEVE.value: assistants_file_retrieve,
    OpenAIEnums.Action.Assistants.FILE_DELETE.value: assistants_file_delete,
    OpenAIEnums.Action.Assistants.FILE_LIST.value: assistants_file_list,
    ### ASSISTANTS THREADS ###
    OpenAIEnums.Action.Assistants.THREAD_RETRIEVE.value: thread_retrieve,
    OpenAIEnums.Action.Assistants.THREAD_CREATE.value: thread_create,
    OpenAIEnums.Action.Assistants.THREAD_MODIFY.value: thread_modify,
    OpenAIEnums.Action.Assistants.THREAD_DELETE.value: thread_delete,
    ### ASSISTANTS MESSAGES ###
    OpenAIEnums.Action.Assistants.THREAD_MESSAGES_CREATE.value: thread_messages_create,
    OpenAIEnums.Action.Assistants.THREAD_MESSAGES_RETRIEVE.value: thread_messages_retrieve,
    OpenAIEnums.Action.Assistants.THREAD_MESSAGES_MODIFY.value: thread_messages_modify,
    OpenAIEnums.Action.Assistants.THREAD_MESSAGES_LIST.value: thread_messages_list,
    OpenAIEnums.Action.Assistants.THREAD_MESSAGES_FILE_RETRIEVE.value: thread_messages_file_retrieve,
    OpenAIEnums.Action.Assistants.THREAD_MESSAGES_FILE_LIST.value: thread_messages_file_list,
    ### ASSISTANTS RUNS ###
    OpenAIEnums.Action.Assistants.THREAD_RUN_CREATE.value: thread_run_create,
    OpenAIEnums.Action.Assistants.THREAD_RUN_RETRIEVE.value: thread_run_retrieve,
    OpenAIEnums.Action.Assistants.THREAD_RUN_MODIFY.value: thread_run_modify,
    OpenAIEnums.Action.Assistants.THREAD_RUN_LIST.value: thread_run_list,
    OpenAIEnums.Action.Assistants.THREAD_RUN_CANCEL.value: thread_run_cancel,
    OpenAIEnums.Action.Assistants.THREAD_CREATE_AND_RUN.value: thread_create_and_run,
    OpenAIEnums.Action.Assistants.THREAD_RUN_STEP_RETRIEVE.value: thread_run_step_retrieve,
    OpenAIEnums.Action.Assistants.THREAD_RUN_STEP_LIST.value: thread_run_step_list
}