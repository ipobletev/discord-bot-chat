
from wsagent.ai_services.services.openai.config import OPENAI_API_KEY

beta_openai_headers = {
    'Authorization': f'Bearer {OPENAI_API_KEY}',
    'OpenAI-Beta': 'assistants=v1'
}

classic_openai_headers = {
    'Authorization': f'Bearer {OPENAI_API_KEY}'
}
