import asyncio
from datetime import datetime
from enum import Enum
import json
import logging
import traceback
from typing import Any, Callable, List, Optional, Union, AsyncGenerator

import aiohttp
from wsagent.ai_services.exceptions import StopException
from wsagent.ai_services.services.openai.utils.content_item import content_item_image, content_item_text
from wsagent.ai_services.services.openai.utils.cost import calculate_token_cost, calculate_vision_image_cost
from wsagent.ai_services.services.openai.utils.count import count_image_tiles, count_tokens_from_image, count_tokens_from_messages, count_tokens_from_text
from wsagent.ai_services.services.openai.headers import classic_openai_headers
from wsagent.ai_services.services.openai.enums import OpenAIEnums
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.request import request_with_exponential_backoff
from wsagent.utils.validate_args import validate_required_args
import copy

@validate_required_args
async def create_chat_completion(
    action: Optional[Union[Enum, str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict] = None,
    log: Optional[logging.Logger] = None
) -> AsyncGenerator[Union[str, AIServiceResponse], None]:

    init_timestamp = datetime.now().timestamp()

    if action is None: raise ValueError("action must be provided")
    if log is None: log = logging.getLogger(__name__)
    if action_params is None: action_params = {}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")

    # All parameters for this method
    ## action_params
    messages = action_params.get('messages', None)
    model = action_params.get('model', None)
    frequency_penalty = action_params.get('frequency_penalty', None)
    logit_bias = action_params.get('logit_bias', None)
    logprobs = action_params.get('logprobs', None)
    top_logprobs = action_params.get('top_logprobs', None)
    max_tokens = action_params.get('max_tokens', None)
    n = action_params.get('n', None)
    presence_penalty = action_params.get('presence_penalty', None)
    response_format = action_params.get('response_format', None)
    seed = action_params.get('seed', None)
    stop = action_params.get('stop', None)
    stream = action_params.get('stream', None)
    temperature = action_params.get('temperature', None)
    top_p = action_params.get('top_p', None)
    tools = action_params.get('tools', None)
    tool_choice = action_params.get('tool_choice', None)
    user = action_params.get('user', None)
    functions = action_params.get('functions', None)
    retries = action_params.get('retries', None)
    backoff_base = action_params.get('backoff_base', None)
    ## Custom
    generator_response = action_params.get('generator_response', None)
    user_message = action_params.get('user_message', None)
    prefix_messages = action_params.get('prefix_messages', None)
    suffix_messages = action_params.get('suffix_messages', None)
    images = action_params.get('images', None)
    image_detail = action_params.get('image_detail', None)
    stop_event = action_params.get('stop_event', None)
    # ai_service_params
    api_key = ai_service_params.get('openai_api_key', None)

    # Check if all required parameters are provided
    if api_key is None: raise ValueError("openai_api_key is required")

    # Optional parameters with default values
    if model is None: model = OpenAIEnums.Feature.LLM.Model.GPT_4_O
    if n is None: n = 1
    if retries is None: retries = 5
    if backoff_base is None: backoff_base = 2
    if generator_response is None: generator_response = False

    str_model = None
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")

    # Header
    headers = classic_openai_headers.copy()
    headers['Authorization'] = f'Bearer {api_key}'
    headers['Content-Type'] = 'application/json'

    # Set data
    data = {}
    data["model"] = str_model
    if max_tokens: data["max_tokens"] = max_tokens
    if frequency_penalty: data["frequency_penalty"] = frequency_penalty
    if logit_bias: data["logit_bias"] = logit_bias
    if logprobs: data["logprobs"] = logprobs
    if top_logprobs: data["top_logprobs"] = top_logprobs
    if n: data["n"] = n
    if presence_penalty: data["presence_penalty"] = presence_penalty
    if response_format: data["response_format"] = response_format
    if seed: data["seed"] = seed
    if stop: data["stop"] = stop
    if stream: data["stream"] = stream
    if temperature: data["temperature"] = temperature
    if top_p: data["top_p"] = top_p
    if tools: data["tools"] = tools
    if tool_choice: data["tool_choice"] = tool_choice
    if user: data["user"] = user
    if functions: data["functions"] = functions

    # Prepare messages with easy way
    if messages is None:
        # Prepare image data for the payload
        if images:
            content = []
            for image in images:
                content.append(content_item_image(image, image_detail))
            content.append(content_item_text(user_message))
            chat_user_message = [{"role": "user", "content": content}]
        # Prepare the payload without the image request
        else:
            chat_user_message = [{"role": "user", "content": user_message}]
        # Make the payload
        messages = prefix_messages + chat_user_message + suffix_messages

    copy_messages = copy.deepcopy(messages)

    # Data
    data["messages"] = copy.deepcopy(messages)

    # Set url
    url = OpenAIEnums.Endpoints.CHATCOMPLETION.url

    # Clear
    tool_calls_raw = [{} for _ in range(n)]
    logprobs_call = []
    text_chunk = []
    tools_calls = []
    raw_response = {}
    content = []
    if stream: raw_response['byte_line'] = []
    completion_text_chunk = ''
    output_tokens = 0
    input_tokens = 0

    # Log messages
    log.info(f'Data parameters to llm server: {data}')

    try:
        async for request_response in request_with_exponential_backoff(
            stream=stream,
            generator_response=generator_response,
            stop_event=stop_event,
            retries=retries,
            backoff_base=backoff_base,
            url=url,
            headers=headers,
            json=copy.deepcopy(data),
            log=log,
            stream_handler=stream_response_handler,
            # Extra arg for stream_handler
            text_chunk=text_chunk,
            tool_calls_raw=tool_calls_raw,
            logprobs_call=logprobs_call,
            raw_response=raw_response
        ):
            if stream: yield request_response
    except StopException:
        pass

    if stream:
        input_tokens = count_tokens_from_messages(messages=copy_messages, model=model)
        if tools:
            for tool in tool_calls_raw:
                output_tokens += count_tokens_from_text(input_txt=json.dumps(tool), model=model)
                tools_calls.append({
                    "tool_name": tool['function'],
                    "tool_input": json.loads(tool['arguments'])
                })
            content = tools_calls
        else:
            output_tokens = count_tokens_from_text(input_txt=completion_text_chunk, model=model)
            completion_text_chunk = "".join(text_chunk)
            content.append(completion_text_chunk)
    else:
        raw_response = json.loads(request_response)
        input_tokens = raw_response['usage']['prompt_tokens']
        output_tokens = raw_response['usage']['completion_tokens']
        choices = raw_response.get('choices', '')
        for choice in choices:
            message = choice.get('message', '')
            completion_text_chunk = message.get('content', '')
            tool_calls_raw = message.get('tool_calls', [])
            if tools:
                for tool in tool_calls_raw:
                    tools_calls.append({
                        "tool_name": tool['function']['name'],
                        "tool_input": json.loads(tool['function']['arguments'])
                    })
                content = tools_calls
            else:
                content.append(completion_text_chunk)
            if logprobs: logprobs_call = choice.get('logprobs', []).get('content', [])

    # Calculate Cost
    text_token_cost = calculate_token_cost(model, input_tokens, output_tokens)

    image_cost_items = []
    image_token_cost = 0
    image_source = ''

    if images:
        # Get all images from messages
        for message in messages:
            for content_item in message['content']:
                if type(content_item) is dict:
                    if content_item.get('type') == 'image_url':
                        images.append(content_item['image_url']['url'].replace("data:image/jpeg;base64,", ""))
        for image in images:
            if image.startswith(('http')):
                source_type = 'url'
                image_source = image
            elif any(image.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.webp']):
                source_type = 'local_path'
                image_source = image
            else:
                source_type = 'local_base64'
                image_source = ''
            tiles = count_image_tiles(image)
            cost = calculate_vision_image_cost(vision_model=model, image_detail=image_detail, input_tiles=tiles)
            image_cost_items.append({
                "source_type": source_type,
                "image_source": image_source,
                "image_detail": image_detail,
                "cost": cost
            })
            image_token_cost += cost

    # Generate a output
    yield AIServiceResponse(
        result=content,
        action=action,
        action_params=action_params,
        additional_data={
            "stop_event": False if stop_event is None else stop_event.is_set()
        },
        cost={
            "total_cost": text_token_cost + image_token_cost,
            "text_token_cost": text_token_cost,
            "image_token_cost": image_token_cost,
            "image_details": image_cost_items
        },
        usage={
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens
        },
        init_timestamp=init_timestamp,
        raw_response=raw_response
    )

async def stream_response_handler(
    response: Optional[aiohttp.ClientResponse] = None,
    stop_event: Optional[asyncio.Event] = None,
    *args, **kwargs
) -> AsyncGenerator[str, None]:
    
    text_chunk: list = kwargs.get('text_chunk')
    tool_calls_raw: dict = kwargs.get('tool_calls_raw')
    logprobs_call: list = kwargs.get('logprobs_call')
    raw_response = kwargs.get('raw_response')

    async for line in response.content:
        decoded_line = line.decode().strip()

        raw_response['byte_line'].append(decoded_line)
        
        if decoded_line.endswith('[DONE]'):
            return

        elif decoded_line.startswith("data: "):
            try:
                json_data = json.loads(decoded_line[len("data: "):])
                choices = json_data.get("choices", None)

                if choices is None or not choices:
                    continue

                for choice in choices:
                    index = int(choice.get('index', 0))
                    delta = choice.get("delta", {})
                    logprobs = choice.get("logprobs", [])
                    chunk = delta.get("content", "")
                    if "tool_calls" in delta:
                        tool_call_data = delta['tool_calls'][0]
                        function_info = tool_call_data.get("function", {})
                        function_name = function_info.get("name", "")
                        function_arguments_fragment = function_info.get("arguments", "")
                        if function_name and "function" not in tool_calls_raw:
                            tool_calls_raw[index]["function"] = function_name
                            tool_calls_raw[index]["arguments"] = ""
                        tool_calls_raw[index]["arguments"] += function_arguments_fragment
                    if logprobs:
                        if "content" in logprobs:
                            logprobs_call.append(logprobs['content'][0])
                    
                    if chunk is not None:
                        text_chunk.append(chunk)
                        yield chunk

            except Exception as e:
                print(f'Error parsing JSON: {e}')
                print(traceback.format_exc())
                
        if stop_event and stop_event.is_set():  # Check if the stop event 
            raise StopException("Stop event set.")
        
    return