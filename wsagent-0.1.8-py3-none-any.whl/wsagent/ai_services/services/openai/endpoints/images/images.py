from datetime import datetime
from enum import Enum
import json
import logging
import os
import time
import traceback
from typing import Optional, Union, cast
import aiofiles
import aiohttp
from wsagent.ai_helper.schemas.ai_helper_response import AIHelperResponse
from wsagent.ai_services.services.openai.utils.cost import calculate_image_generator_cost
from wsagent.ai_services.services.openai.headers import classic_openai_headers
from wsagent.ai_services.services.openai.enums import OpenAIEnums
from wsagent.ai_services.services.openai.utils.count import count_tokens_from_image
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.request import request_with_exponential_backoff
from wsagent.utils.validate_args import validate_required_args

@validate_required_args
async def image_create(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AIServiceResponse:

    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    prompt = action_params.get('prompt', None)
    model = action_params.get('model', None)
    n = action_params.get('n', None)
    quality = action_params.get('quality', None)
    response_format = action_params.get('response_format', None)
    size = action_params.get('size', None)
    style = action_params.get('style', None)
    user = action_params.get('user', None)
    retries = action_params.get('retries', None)
    backoff_base = action_params.get('backoff_base', None)
    ## ai_service_params
    api_key = ai_service_params.get('openai_api_key', None)
    
    # Check if all required parameters are provided
    if api_key is None: raise ValueError("api_key cannot be None")
    if prompt is None or prompt == '': raise ValueError("prompt is required")
    
    # Optional parameters with default values
    if model is None: model = OpenAIEnums.Feature.Image.Model.DALL_E_3
    if n is None: n = 1
    if quality is None: quality = "hd"
    if response_format is None: response_format = "url"
    if size is None: size = OpenAIEnums.Feature.Image.Resolution._1024x1024
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2

    str_model=None
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    # Header
    headers=classic_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    headers['Authorization'] = f'Bearer {api_key}'
        
    data={}
    data["prompt"]=prompt
    data["model"]=str_model
    data["n"]=n
    data["quality"]=quality
    data["response_format"]=response_format
    data["size"]=size.name
    if style is not None: data["style"]=style
    if user is not None: data["user"] = user
    
    # Set url
    url=OpenAIEnums.Endpoints.IMAGES_CREATE.url
    
    # Send request
    total_cost=0
    content=[]
    raw_response={}

    async for response in request_with_exponential_backoff(
        stream=False,
        retries=retries,
        backoff_base=backoff_base,
        url=url, 
        headers=headers, 
        json=data, 
        log=log
    ):
        if isinstance(response, AIHelperResponse):
            raw_response = response

    for image_data in raw_response.get('data',[]):
        revised_prompt_raw = image_data.get('revised_prompt','')
        url_raw = image_data.get('url','')
        b64_json_raw = image_data.get('b64_json','')
        if url_raw:
            image=url_raw
        if b64_json_raw:
            image=b64_json_raw
        cost_item = calculate_image_generator_cost( 
            image_model=model,
            quality=quality, 
            size=size.name
        )
        content.append(image)
        total_cost+=cost_item
    
    yield AIServiceResponse(
        result=content,
        additional_data=None,
        action=action,
        action_params=action_params,
        usage=None,
        cost={
            "total_cost": total_cost
        },
        init_timestamp=init_timestamp,
        raw_response=raw_response,
    )

@validate_required_args
async def image_edit(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AIServiceResponse:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    image_path = action_params.get('image_path', None)
    prompt = action_params.get('prompt', None)
    mask_path = action_params.get('mask_path', None)
    model = action_params.get('model', None)
    n = action_params.get('n', None)
    size = action_params.get('size', None)
    response_format = action_params.get('response_format', None)
    user = action_params.get('user', None)
    retries = action_params.get('retries', None)
    backoff_base = action_params.get('backoff_base', None)
    ## ai_service_params
    api_key = ai_service_params.get('openai_api_key', None)
    
    # Check if all required parameters are provided
    if api_key is None: raise ValueError("api_key cannot be None")
    if prompt is None or prompt == '': raise ValueError("prompt is required")
    
    # Optional parameters with default values
    if model is None: model = OpenAIEnums.Feature.Image.Model.DALL_E_3
    if n is None: n = 1
    if size is None: size = OpenAIEnums.Feature.Image.Resolution._1024x1024
    if response_format is None: response_format = "url"
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2

    str_model=None
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    # Set url
    url=OpenAIEnums.Endpoints.IMAGES_EDIT.url

    # Header
    headers=classic_openai_headers.copy()
    headers['Authorization'] = f'Bearer {api_key}'
    
    # Send request
    total_cost=0
    content=[]
    image=''
    raw_response={}

    async with aiohttp.ClientSession() as session:
        # Open the image and mask files within the async context manager

        data = aiohttp.FormData()
        data.add_field('prompt', prompt)
        data.add_field('n', str(n))
        data.add_field('size', size.name)
        data.add_field('response_format', response_format)
        if model is not None:
            data.add_field('model', str_model)
        if user is not None:
            data.add_field('user', user)
            
        async with aiofiles.open(image_path, 'rb') as f:
            data_image = await f.read()
            data.add_field('image', data_image, filename=os.path.basename(image_path), content_type='image/png')

        if mask_path is not None:
            async with aiofiles.open(mask_path, 'rb') as f:
                data_image = await f.read()
                data.add_field('mask', data_image, filename=os.path.basename(mask_path), content_type='image/png')

        async for response in request_with_exponential_backoff(
            stream=False,
            retries=retries,
            backoff_base=backoff_base,
            url=url, 
            headers=headers, 
            data=data, 
            log=log
        ):
            if isinstance(response, AIHelperResponse):
                raw_response = response

        for image_data in raw_response.get('data',[]):
            url_raw = image_data.get('url','')
            b64_json_raw = image_data.get('b64_json','')
            if url_raw:
                image=url_raw
            if b64_json_raw:
                image=b64_json_raw
            cost_item = calculate_image_generator_cost( 
                image_model=model,
                size=size.name
            )
            content.append(image)
            total_cost+=cost_item
    
    yield AIServiceResponse(
        result=content,
        additional_data=None,
        action=action,
        action_params=action_params,
        usage=None,
        cost={
            "total_cost": total_cost
        },
        init_timestamp=init_timestamp,
        raw_response=raw_response,
    )

@validate_required_args
async def image_variation(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AIServiceResponse:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    image_path = action_params.get('image_path', None)
    model = action_params.get('model', None)
    n = action_params.get('n', None)
    response_format = action_params.get('response_format', None)
    size = action_params.get('size', None)
    user = action_params.get('user', None)
    retries = action_params.get('retries', None)
    backoff_base = action_params.get('backoff_base', None)
    ## ai_service_params
    api_key = ai_service_params.get('openai_api_key', None)
    
    # Check if all required parameters are provided
    if api_key is None: raise ValueError("api_key cannot be None")
    if image_path is None: raise ValueError("image_path cannot be None")
    
    # Optional parameters with default values
    if model is None: model = OpenAIEnums.Feature.Image.Model.DALL_E_3.name
    if n is None: n = 1
    if response_format is None: response_format = "url"
    if size is None: size = OpenAIEnums.Feature.Image.Resolution._1024x1024.name
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2

    str_model=None
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    # Header
    headers=classic_openai_headers.copy()
    headers['Authorization'] = f'Bearer {api_key}'
    
    # Set url
    url=OpenAIEnums.Endpoints.IMAGES_VARIATION.url
    
    # Send request
    content = []
    total_cost=0
    image=''
    raw_response=None

    async with aiohttp.ClientSession() as session:
        # Open the image and mask files within the async context manager

        data = aiohttp.FormData()
        data.add_field('n', str(n))
        data.add_field('size', size.name)
        data.add_field('response_format', response_format)
        if model is not None:
            data.add_field('model', str_model)
        if user is not None:
            data.add_field('user', user)
            
        async with aiofiles.open(image_path, 'rb') as f:
            data_image = await f.read()
            data.add_field('image', data_image, filename=os.path.basename(image_path), content_type='image/png')

        async for response in request_with_exponential_backoff(
            stream=False,
            retries=retries,
            backoff_base=backoff_base,
            url=url, 
            headers=headers, 
            data=data, 
            log=log
        ):
            raw_response = json.loads(response)
    
        for image_data in raw_response.get('data',[]):
            url_raw = image_data.get('url','')
            b64_json_raw = image_data.get('b64_json','')
            if url_raw:
                image=url_raw
            if b64_json_raw:
                image=b64_json_raw
            cost_item = calculate_image_generator_cost( 
                image_model=model,
                size=size.name
            )
            content.append(image)
            total_cost+=cost_item

    yield AIServiceResponse(
        result=content,
        additional_data=None,
        action=action,
        action_params=action_params,
        usage=None,
        cost={
            "total_cost": total_cost
        },
        init_timestamp=init_timestamp,
        raw_response=raw_response,
    )