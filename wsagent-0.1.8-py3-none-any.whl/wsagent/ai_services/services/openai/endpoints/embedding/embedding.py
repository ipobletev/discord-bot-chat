from datetime import datetime
from enum import Enum
import json
import logging
from typing import Optional, Union
from wsagent.ai_services.services.openai.utils.cost import calculate_embedding_cost
from wsagent.ai_services.services.openai.headers import classic_openai_headers
from wsagent.ai_services.services.openai.enums import OpenAIEnums
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.request import request_with_exponential_backoff
from wsagent.utils.validate_args import validate_required_args
    
@validate_required_args
async def create_embedding(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AIServiceResponse:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    input = action_params.get('input', None)
    model = action_params.get('model', None)
    encoding_format = action_params.get('encoding_format', None)
    dimensions = action_params.get('dimensions', None)
    user = action_params.get('user', None)
    retries = action_params.get('retries', None)
    backoff_base = action_params.get('backoff_base', None)
    
    ## ai_service_params
    api_key = ai_service_params.get('openai_api_key', None)
    
    # Check if all required parameters are provided
    if api_key is None: raise ValueError("openai_api_key cannot be None")
    if input is None or input == '': raise ValueError("input is required")
    
    # Optional parameters with default values
    if model is None: model = OpenAIEnums.Feature.Embeddings.Model.LARGE_V3.name
    if encoding_format is None: encoding_format='float'
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2
    if dimensions is None: dimensions=OpenAIEnums.Feature.Embeddings.Model.LARGE_V3.dimensions

     # Header
    headers=classic_openai_headers.copy()
    headers['Authorization'] = f'Bearer {api_key}'
    headers['Content-Type']= 'application/json'

    str_model=None
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    # Set data
    data={}
    data["input"]=input
    data["model"]=str_model
    if model != OpenAIEnums.Feature.Embeddings.Model.ADA_V2:
        data["dimensions"]=dimensions
    
    if encoding_format is not None: data["encoding_format"]=encoding_format
    if user is not None: data["user"]=user

    # Set url
    url=OpenAIEnums.Endpoints.EMBEDDINGS.url

    log.info(f"Getting embedding for text: {input}")
    log.info(f"data: {data}")
    
    embedding=None
    cost=0
    input_tokens=0    
    total_tokens=0
    raw_response={}
    
    async for response in request_with_exponential_backoff(
        stream=False,
        retries=retries,
        backoff_base=backoff_base,
        url=url, 
        headers=headers, 
        json=data, 
        log=log
    ):
        raw_response = json.loads(response)
        
    embedding = raw_response["data"][0]["embedding"]
    input_tokens = raw_response["usage"]["prompt_tokens"]
    total_tokens = raw_response["usage"]["total_tokens"]
    cost = calculate_embedding_cost(model,input_tokens)
    log.info(f"Embedding received. Cost: ${cost:.10f}")

    yield AIServiceResponse(
        result=embedding,
        action=action,
        action_params=action_params,
        additional_data=None,
        usage= {
            "input_tokens": input_tokens,
            "total_tokens": total_tokens
        },
        cost =  {
            "total_cost": cost
        },
        init_timestamp=init_timestamp,
        raw_response=raw_response
    )