import asyncio
from datetime import datetime
from enum import Enum
import io
import logging
import os
import traceback
from typing import Any, AsyncGenerator, Callable, Optional, Union
import aiofiles
import aiohttp
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.ai_services.services.openai.utils.cost import calculate_audio_stt_cost, calculate_audio_tts_cost
from wsagent.ai_services.services.openai.headers import classic_openai_headers
from wsagent.ai_services.services.openai.enums import OpenAIEnums
import audioread
from wsagent.utils.validate_args import validate_required_args
from wsagent.utils.request import request_with_exponential_backoff

@validate_required_args
async def audio_create_speech(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AsyncGenerator[Union[str, AIServiceResponse], None]:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    model = action_params.get("model", None)
    input = action_params.get("text", None)
    voice = action_params.get("voice", None)
    response_format = action_params.get("response_format", None)
    speed = action_params.get("speed", None)
    path_to_save = action_params.get("path_to_save", None)
    chunk_size = action_params.get("chunk_size", None)
    retries = action_params.get("retries", None)
    backoff_base = action_params.get("backoff_base", None)
    stop_event = action_params.get("stop_event", None)
    # ai_service_params
    api_key = ai_service_params.get("openai_api_key", None)
    
    # Required parameters
    if api_key is None: raise ValueError("openai_api_key cannot be None")
    if input is None: raise ValueError("input cannot be None")
    
    # Optional parameters with default values
    if model is None: model=OpenAIEnums.Feature.Audio.Model.TTS_1_HD
    if voice is None: voice=OpenAIEnums.Feature.Audio.Voices.ALLOY
    if speed is None: speed=1.0
    if chunk_size is None: chunk_size=4096
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2
    if path_to_save is None: path_to_save="temp_out_speech.mp3"

    str_model=None
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    # Header
    headers=classic_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    headers['Authorization'] = f'Bearer {api_key}'
    
    if isinstance(voice, Enum):
        str_voice = voice.value
    elif isinstance(voice, str):
        str_voice = voice
    else:
        raise ValueError("voice must be a string or Enum.")
    
    # Set data
    data={}
    if input is not None: data['input']=input
    if model is not None: data['model']=str_model
    if voice is not None: data['voice']=str_voice
    if response_format is not None: data['response_format']=response_format
    if speed is not None: data['speed']=speed

    # Set url
    url=OpenAIEnums.Endpoints.AUDIO_SPEECH.url

    cost=0
    
    audio_data = bytearray()
    
    async for response in request_with_exponential_backoff(
        stream=True,
        retries=retries,
        stop_event=stop_event,
        backoff_base=backoff_base,
        url=url, 
        headers=headers, 
        json=data, 
        log=log
    ):
        audio_data.extend(response)
        yield response
    
    cost = calculate_audio_tts_cost(
        audio_model=str_model,
        user_msg=input
    )

    # Generate a output
    yield AIServiceResponse(
        result=audio_data,
        action=action,
        action_params=action_params,
        additional_data=None,
        cost={
            "total_cost": cost
        },
        usage=None,
        init_timestamp=init_timestamp,
        raw_response=None
    )

@validate_required_args
async def audio_create_transcription(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AsyncGenerator[Union[str, AIServiceResponse], None]:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    path_file = action_params.get("path_file", None)
    model = action_params.get("model", None)
    language = action_params.get("language", None)
    prompt = action_params.get("prompt", None)
    response_format = action_params.get("response_format", None)
    temperature = action_params.get("temperature", None)
    retries = action_params.get("retries", None)
    backoff_base = action_params.get("backoff_base", None)
    # ai_service_params
    api_key = ai_service_params.get("openai_api_key", None)
    
    # Required parameters
    if api_key is None: raise ValueError("openai_api_key cannot be None")
    if path_file is None: raise ValueError("path_file is required")
    
    # Optional parameters with default values
    if model is None: model=OpenAIEnums.Feature.Audio.Model.WHISPER_1
    if language is None: language="en"
    if response_format is None: response_format="text"
    if temperature is None: temperature=0

    str_model=None
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    # Header
    headers=classic_openai_headers.copy()
    headers['Authorization'] = f'Bearer {api_key}'
    
    # Set url
    url=OpenAIEnums.Endpoints.AUDIO_TRANSCRIPTION.url

    with audioread.audio_open(path_file) as audio_file:
        audio_time_s_length = audio_file.duration
        
    data = aiohttp.FormData()
    data.add_field('file', open(path_file, 'rb'), content_type='audio/mpeg')
    data.add_field('model', str_model)
    if prompt: data.add_field('prompt', prompt)
    if language: data.add_field('language', language)
    if response_format: data.add_field('response_format', response_format)
    if temperature: data.add_field('temperature', str(temperature))
    
    # Send request
    cost=0
    output=''
        
    async for response in request_with_exponential_backoff(
        retries=retries,
        backoff_base=backoff_base,
        url=url, 
        headers=headers, 
        data=data, 
        log=log
    ):
        yield response

    cost = calculate_audio_stt_cost(
        audio_model=model,
        audio_time_s_length=audio_time_s_length
    )
            
    # Generate a output
    yield AIServiceResponse(
        result=output,
        action=action,
        action_params=action_params,
        additional_data = None,
        cost={
            "total_cost": cost
        },
        usage=None,
        init_timestamp=init_timestamp,
        raw_response=None
    )

@validate_required_args
async def audio_create_translation(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AIServiceResponse:

    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    path_file = action_params.get("path_file", None)
    model = action_params.get("model", None)
    prompt = action_params.get("prompt", None)
    response_format = action_params.get("response_format", None)
    temperature = action_params.get("temperature", None)
    retries = action_params.get("retries", None)
    backoff_base = action_params.get("backoff_base", None)
    # ai_service_params
    api_key = ai_service_params.get("openai_api_key", None)
    
    # Required parameters
    if api_key is None: raise ValueError("openai_api_key cannot be None")
    
    # Optional parameters with default values
    if model is None: model=OpenAIEnums.Feature.LLM.Model.GPT_4_O.name
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2
    if temperature is None: temperature=0

    str_model=None
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    # Header
    headers=classic_openai_headers.copy()
    headers['Authorization'] = f'Bearer {api_key}'
    
    # Set url
    url=OpenAIEnums.Endpoints.AUDIO_TRANSLATION.url

    data = aiohttp.FormData()
    data.add_field('file', open(path_file, 'rb'), filename=os.path.basename(path_file), content_type='audio/mpeg')
    data.add_field('model', str_model)
    if prompt: data.add_field('prompt', prompt)
    if response_format: data.add_field('response_format', response_format)
    if temperature: data.add_field('temperature', str(temperature))
    
    with audioread.audio_open(path_file) as audio_file:
        audio_time_s_length = audio_file.duration
    
    # Send request
    cost=0
        
    async for response in request_with_exponential_backoff(
        retries=retries,
        backoff_base=backoff_base,
        url=url, 
        headers=headers, 
        data=data, 
        log=log
    ):
        yield response
                
    cost = calculate_audio_stt_cost(
        audio_model=model,
        audio_time_s_length=audio_time_s_length
    )

    # Generate a output
    yield AIServiceResponse(
        result=True,
        action=action,
        action_params=action_params,
        additional_data = None,
        cost={
            "total_cost": cost
        },
        usage=None,
        init_timestamp=init_timestamp,
        raw_response=None
    )