from datetime import datetime
from enum import Enum
import logging
import traceback
from typing import Optional, Union
import aiohttp
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.ai_services.services.openai.headers import classic_openai_headers
from wsagent.ai_services.services.openai.enums import OpenAIEnums
from wsagent.utils.request import request_with_exponential_backoff
    
async def models_list(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AIServiceResponse:

    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    retries = action_params.get('retries', None)
    backoff_base = action_params.get('backoff_base', None)
    

    headers=classic_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set url
    url=OpenAIEnums.Endpoints.MODELS.url
    
    raw_response = await request_with_exponential_backoff(
        method='GET',
        retries=retries,
        backoff_base=backoff_base,
        url=url, 
        headers=headers, 
        log=log, 
    )

    # Generate a output
    return AIServiceResponse(
        result=raw_response,
        action=action,
        action_params=action_params,
        additional_data = None,
        cost=None,
        usage=None,
        init_timestamp=init_timestamp,
        raw_response=raw_response
    )


async def models_retrieve(log,
    model_id: Optional[Enum] = None
):
    
    if model_id is None:
        log.error("Error: model_id cannot be None")
        return {
            "success":False, 
            "error_message":"Error: model_id cannot be None",
            "error_code": 400
        }

    #header
    headers=classic_openai_headers.copy()
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.MODELS.url}/{model_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:
                    output = await response.json()
                    status=True
                    output["success"]=status
        
                    log.info(f"output: {output}")
           
                    return output
                
                else:
                    # Handle errors
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {
            "success":False, 
            "error_message":traceback.format_exc(),
            "error_code": 500
        }

async def models_delete_finetunning_model(log,
    model_id: Optional[str] = None
):
    
    if model_id is None: 
        log.error("Error: model_id cannot be None") 
        return {
            "success":False, 
            "error_message":"Error: model_id cannot be None",
            "error_code": 400
        }

    #header
    headers=classic_openai_headers.copy()
        
    # Set url
    url=f'{OpenAIEnums.Endpoints.MODELS.url}/{model_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.delete(url=url, headers=headers) as response:
                if response.status == 200:
                    output = await response.json()
                    status=True
                    output["success"]=status
        
                    log.info(f"output: {output}")
                                
                    return output
                
                else:
                    # Handle errors
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {
            "success":False, 
            "error_message":traceback.format_exc(),
            "error_code": 500
        }    