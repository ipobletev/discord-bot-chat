from enum import Enum
import traceback
from typing import Optional
import aiohttp
from wsagent.ai_services.services.openai.headers import beta_openai_headers
from wsagent.ai_services.services.openai.enums import OpenAIEnums

async def assistants_create(log,
    api_key: Optional[str] = None,
    model: Optional[Enum] = None,
    name: Optional[str] = None,
    description: Optional[str] = None,
    instructions: Optional[str] = None,
    tools: Optional[str] = None,
    file_ids: Optional[str] = None,
    metadata: Optional[str] = None
):
    
    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
    
    if name is None:
        log.error(f"Error: {400}")
        log.error(f"Message: Name cannot be None")
        return {
            "success": False,
            "error_message": "Error: Name cannot be None",
            "error_code": 400
        }
    if model is None:
        log.error(f"Error: {400}")
        log.error(f"Message: Model cannot be None")
        return {
            "success": False,
            "error_message": "Error: Model cannot be None",
            "error_code": 400
        }
    
    if file_ids is None: file_ids = []
    if tools is None: tools = []
    
    data = {
        'model': model.name,
        'name': name,
        'description': description,
        'instructions': instructions,
        'tools': tools,
        'file_ids': file_ids,
        'metadata': metadata
    }

    url = OpenAIEnums.Endpoints.ASSISTANT.url
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:
                    output = await response.json()
                    output["success"] = True
                    log.info(f"output: {output}")
                    return output
                else:
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {
            "success": False,
            "error_message": str(e),
            "error_code": 500
        }

async def assistants_retrieve(log, 
    api_key: Optional[str] = None,
    assistant_id: Optional[str] = None
):
    
    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
    
    if assistant_id is None:
        log.error(f"Error: {400}")
        log.error(f"Message: Assistant ID cannot be None")
        return {
            "success": False,
            "error_message": "Error: Assistant ID cannot be None",
            "error_code": 400
        }
    
    url = f'{OpenAIEnums.Endpoints.ASSISTANT.url}/{assistant_id}'

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:
                    output = await response.json()
                    output["success"] = True
                    log.info(f"output: {output}")
                    return output
                else:
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {
            "success": False,
            "error_message": str(e),
            "error_code": 500
        }

async def assistants_delete(log, assistant_id: Optional[str] = None):
    if assistant_id is None:
        log.error(f"Error: {400}")
        log.error(f"Message: Assistant ID cannot be None")
        return {
            "success": False,
            "error_message": "Error: Assistant ID cannot be None",
            "error_code": 400
        }
    
    headers = beta_openai_headers.copy()
    headers['Content-Type'] = 'application/json'
    
    url = f'{OpenAIEnums.Endpoints.ASSISTANT.url}/{assistant_id}'

    try:
        async with aiohttp.ClientSession() as session:
            async with session.delete(url=url, headers=headers) as response:
                if response.status == 200:
                    output = await response.json()
                    output["success"] = True
                    log.info(f"output: {output}")
                    return output
                else:
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {
            "success": False,
            "error_message": str(e),
            "error_code": 500
        }

async def assistants_modify(log, 
    api_key: Optional[str] = None,
    assistant_id: Optional[str] = None,
    model: Optional[Enum] = None, name: Optional[str] = None,
    description: Optional[str] = None, instructions: Optional[str] = None,
    tools: Optional[str] = None, file_ids: Optional[str] = None,
    metadata: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    if assistant_id is None:
        log.error(f"Error: {400}")
        log.error(f"Message: Assistant ID cannot be None")
        return {
            "success": False,
            "error_message": "Error: Assistant ID cannot be None",
            "error_code": 400
        }
    
    if file_ids is None: file_ids = []
    if tools is None: tools = []
    if metadata is None: metadata = {}
    
    data = {}
    if model is not None: data['model'] = model.name
    if name is not None: data['name'] = name
    if description is not None: data['description'] = description
    if instructions is not None: data['instructions'] = instructions
    data['tools'] = tools
    data['file_ids'] = file_ids
    data['metadata'] = metadata

    url = f'{OpenAIEnums.Endpoints.ASSISTANT.url}/{assistant_id}'

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:
                    output = await response.json()
                    output["success"] = True
                    log.info(f"output: {output}")
                    return output
                else:
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {
            "success": False,
            "error_message": str(e),
            "error_code": 500
        }

async def assistants_list(log, 
    api_key: Optional[str] = None,
    limit: Optional[int] = None,
    order: Optional[str] = None, after: Optional[str] = None,
    before: Optional[str] = None):
    
    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
    
    params = {k: v for k, v in {
        'limit': limit, 'order': order, 'after': after, 'before': before
    }.items() if v is not None}

    url = OpenAIEnums.Endpoints.ASSISTANT.url

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers, params=params) as response:
                if response.status == 200:
                    output = await response.json()
                    output["success"] = True
                    log.info(f"output: {output}")
                    return output
                else:
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {
            "success": False,
            "error_message": str(e),
            "error_code": 500
        }