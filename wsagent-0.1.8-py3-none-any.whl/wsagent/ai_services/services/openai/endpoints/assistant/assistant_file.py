from enum import Enum
import traceback
from typing import Optional
import aiohttp
from wsagent.ai_services.services.openai.headers import beta_openai_headers
from wsagent.ai_services.services.openai.enums import OpenAIEnums

async def assistants_file_create(log,
    api_key: Optional[str] = None,
    assistant_id: Optional[str] = None,    
    file_id: Optional[str] = None     
):
    
    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
    
    if not assistant_id: raise ValueError("assistant_id cannot be None")
    if not file_id: raise ValueError("file_id cannot be None")
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.ASSISTANT.url}/{assistant_id}/files'
    
    data={}
    data['file_id']=file_id
    
    # Send the request using an aiohttp client session
    status = False
    output = {}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:
                    output = await response.json()
                    status = True
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status = False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output
    

async def assistants_file_retrieve(log,
    api_key: Optional[str] = None,
    assistant_id: Optional[str] = None,    
    file_id: Optional[str] = None     
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
    
    if not assistant_id: raise ValueError("assistant_id cannot be None")
    if not file_id: raise ValueError("file_id cannot be None")
    
    #header
    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.ASSISTANT.url}/{assistant_id}/files/{file_id}'
    
    # Send the request using an aiohttp client session
    status = False
    output = {}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:
                    output = await response.json()
                    status = True
                else:
                    
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output

async def assistants_file_list(log,
    api_key: Optional[str] = None,
    assistant_id: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
    
    if not assistant_id: raise ValueError("assistant_id cannot be None")
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.ASSISTANT.url}/{assistant_id}/files'
    
    # Send the request using an aiohttp client session
    status = False
    output = {}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:
                    output = await response.json()
                    status = True
                else:
                    
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output

async def assistants_file_delete(log,
    api_key: Optional[str] = None,
    assistant_id: Optional[str] = None,    
    file_id: Optional[str] = None     
):
    
    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
    
    if not assistant_id: raise ValueError("assistant_id cannot be None")
    if not file_id: raise ValueError("file_id cannot be None")
    
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.ASSISTANT.url}/{assistant_id}/files/{file_id}'
    
    # Send the request using an aiohttp client session
    status = False
    output = {}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.delete(url=url, headers=headers) as response:
                if response.status == 200:
                    output = await response.json()
                    status = True
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output