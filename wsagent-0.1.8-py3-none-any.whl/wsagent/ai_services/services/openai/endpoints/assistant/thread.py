from enum import Enum
import traceback
from typing import Any, List, Optional
import aiohttp
from wsagent.ai_services.services.openai.headers import beta_openai_headers
from wsagent.ai_services.services.openai.enums import OpenAIEnums
    
async def thread_create(log,
    api_key: Optional[str] = None,
    messages: Optional[List] = None,
    metadata: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    # Set parameters
    if messages is None: messages=[]
    if metadata is None: metadata={}
    
    # Set data
    data={}
    data['messages']=messages
    data['metadata']=metadata

    # Set url
    url=OpenAIEnums.Endpoints.THREAD.url
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output


async def thread_retrieve(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    # Set parameters
    if thread_id is None: raise Exception("thread_id is required")
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output


async def thread_modify(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None,
    metadata: Optional[Any] = None # Only metadata can be modified
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    # Set parameters
    if thread_id is None: raise Exception("thread_id is required")
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}'

    # data
    data={}
    data['metadata']=metadata
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output

async def thread_delete(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    # Set parameters
    if thread_id is None: raise Exception("thread_id is required")
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.delete(url=url, headers=headers) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output