from enum import Enum
import traceback
from typing import Any, Optional
import aiohttp
from wsagent.ai_services.services.openai.headers import beta_openai_headers
from wsagent.ai_services.services.openai.enums import OpenAIEnums

async def thread_messages_create(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None,
    role: Optional[str] = None,
    content: Optional[str] = None,
    file_ids: Optional[str] = None,
    metadata: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    # Set parameters
    if thread_id is None: raise Exception("thread_id is required.")
    if role is None: raise Exception("role is required.")
    if content is None: raise Exception("content is required.")
    
    #Set init
    if file_ids is None: file_ids=[]
    if metadata is None: metadata={}
    
    # Set data
    data={}
    data['role']=role
    data['content']=content
    data['file_ids']=file_ids
    data['metadata']=metadata

    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/messages'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output
    
async def thread_messages_retrieve(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None,
    message_id: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    if thread_id is None: raise Exception("thread_id is required.")
    if message_id is None: raise Exception("message_id is required.")
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/messages/{message_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output
    

async def thread_messages_modify(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None,
    message_id: Optional[str] = None,
    metadata: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    if thread_id is None: raise Exception("thread_id is required.")
    if message_id is None: raise Exception("message_id is required.")
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/messages/{message_id}'
    
    data={}
    data['metadata']=metadata
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers,json=data) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output
    

async def thread_messages_list(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None,
    limit: Optional[int] = None,
    order: Optional[str] = None,
    after: Optional[str] = None,
    before: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    if thread_id is None: raise Exception("thread_id is required.")
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/messages'
    
    # Set params
    params = {k: v for k, v in {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before
    }.items() if v is not None}

    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers,params=params) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output
    
async def thread_messages_file_retrieve(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None,
    message_id: Optional[str] = None,
    file_id: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    # Set parameters
    if thread_id is None: raise Exception("thread_id is required.")
    if message_id is None: raise Exception("message_id is required.")
    if file_id is None: raise Exception("file_id is required.")
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/messages/{message_id}/files/{file_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output
    
    
async def thread_messages_file_list(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None,
    message_id: Optional[str] = None,
    limit: Optional[int] = None,
    order: Optional[str] = None,
    after: Optional[str] = None,
    before: Optional[str] = None
):
    
    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    # Set parameters
    if thread_id is None: raise Exception("thread_id is required.")
    if message_id is None: raise Exception("message_id is required.")
    
    # Set params
    params = {k: v for k, v in {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before
    }.items() if v is not None}
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/messages/{message_id}/files'

    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers,params=params) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output