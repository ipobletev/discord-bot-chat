from enum import Enum
import traceback
from typing import Dict, Optional

import aiohttp
from wsagent.ai_services.services.openai.enums import OpenAIEnums
from wsagent.ai_services.services.openai.headers import beta_openai_headers

async def thread_run_create(log,
    api_key: Optional[str] = None,
    assistant_id: Optional[str] = None,
    thread_id: Optional[Enum] = None,
    model: Optional[str] = None,
    instructions: Optional[str] = None,
    tools: Optional[str] = None,
    metadata: Optional[Dict] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    #Required parameters
    if thread_id is None: raise ValueError("Thread ID cannot be None")
    if assistant_id is None: raise ValueError("Assistant ID cannot be None")
    
    # Set parameters
    if tools is None: tools=[]
    
    # Set data
    data={}
    data['assistant_id']=assistant_id
    data['model']=model.name
    data['instructions']=instructions
    data['tools']=tools
    data['metadata']=metadata

    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/runs'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output

async def thread_run_retrieve(log,
    api_key: Optional[str] = None,
    thread_id: Optional[Enum] = None,
    run_id: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    #Required parameters
    if thread_id is None: raise ValueError("thread_id cannot be None")
    if run_id is None: raise ValueError("run_id cannot be None")
    
    # Set data
    data={}
    data['thread_id']=thread_id
    data['run_id']=run_id

    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/runs/{run_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:

                    output = await response.json()

                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")

                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output

async def thread_run_modify(log,
    api_key: Optional[str] = None,
    thread_id: Optional[Enum] = None,
    run_id: Optional[str] = None,
    metadata: Optional[Dict] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    #Required parameters
    if thread_id is None: raise ValueError("Thread ID cannot be None")
    if run_id is None: raise ValueError("run_id ID cannot be None")
    
    # Set parameters
    if metadata is None: metadata={}
    
    # Set data
    data={}
    data['metadata']=metadata

    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/runs/{run_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output

async def thread_run_list(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None,
    limit: Optional[int] = None,
    order: Optional[str] = None,
    after: Optional[str] = None,
    before: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    #Required parameters
    if thread_id is None: raise ValueError("thread_id cannot be None")
    
    # Set params
    params = {k: v for k, v in {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before
    }.items() if v is not None}
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/runs'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers,params=params) as response:
                if response.status == 200:

                    output = await response.json()

                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")

                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output

async def thread_run_cancel(log,
    api_key: Optional[str] = None,
    thread_id: Optional[Enum] = None,
    run_id: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    #Required parameters
    if thread_id is None: raise ValueError("Thread ID cannot be None")
    if run_id is None: raise ValueError("run_id ID cannot be None")
    
    # Set data
    data={}
    data['thread_id']=thread_id
    data['run_id']=run_id

    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/runs/{run_id}/cancel'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output


async def thread_create_and_run(log,
    api_key: Optional[str] = None,
    assistant_id: Optional[str] = None,
    thread_data: Optional[Enum] = None, # Add messages and metadata
    model: Optional[str] = None,
    instructions: Optional[str] = None,
    tools: Optional[str] = None,
    metadata: Optional[Dict] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    #Required parameters
    if assistant_id is None: raise ValueError("Assistant ID cannot be None")
    
    # Set parameters
    if tools is None: tools=[]
    
    # Set data
    data={}
    data['thread']=thread_data
    data['assistant_id']=assistant_id
    data['model']=model.name
    data['instructions']=instructions
    data['tools']=tools
    data['metadata']=metadata

    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/runs'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:

                    output = await response.json()
                    
                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")
                    print(text)
                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output

async def thread_run_step_retrieve(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None,
    run_id: Optional[str] = None,
    step_id: Optional[str] = None
):
    
    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    #Required parameters
    if thread_id is None: raise ValueError("thread_id cannot be None")
    if run_id is None: raise ValueError("run_id cannot be None")
    if step_id is None: raise ValueError("step_id cannot be None")
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/runs/{run_id}/steps/{step_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:

                    output = await response.json()

                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")

                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output

async def thread_run_step_list(log,
    api_key: Optional[str] = None,
    thread_id: Optional[str] = None,
    run_id: Optional[str] = None,
    limit: Optional[int] = None,
    order: Optional[str] = None,
    after: Optional[str] = None,
    before: Optional[str] = None
):

    headers=beta_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    #Required parameters
    if thread_id is None: raise ValueError("thread_id cannot be None")
    if run_id is None: raise ValueError("run_id cannot be None")
    
    # Set params
    params = {k: v for k, v in {
        'limit': limit,
        'order': order,
        'after': after,
        'before': before
    }.items() if v is not None}
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.THREAD.url}/{thread_id}/runs/{run_id}/steps'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers,params=params) as response:
                if response.status == 200:

                    output = await response.json()

                    status=True
                    
                else:
                    # Handle errors
                    log.error(f"Error: {response.status}")
                    text = await response.text()
                    log.error(f"Message: {text}")

                    raise Exception(f"Error: Received a {response.status} status code.")

    except Exception as e:
        log.error(traceback.format_exc())
        status=False
    finally:
        
        output["success"]=status
        
        log.info(f"output: {output}")
        
        return output