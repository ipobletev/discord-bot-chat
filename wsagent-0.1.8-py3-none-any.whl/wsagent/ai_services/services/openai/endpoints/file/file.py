from enum import Enum
import os
import traceback
from typing import Optional
import aiohttp
from wsagent.ai_services.services.openai.headers import classic_openai_headers
from wsagent.ai_services.services.openai.enums import OpenAIEnums
import aiofiles
    
async def file_list(log,
    api_key: Optional[str] = None,
    purpose: Optional[Enum] = None
):

    headers=classic_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    # Define the query parameters
    params = {}
    if purpose: params['purpose'] = purpose

    # Set url
    url=OpenAIEnums.Endpoints.FILES.url
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers, params=params) as response:
                if response.status == 200:
                    output = await response.json()
                    status=True
                    output["success"]=status
                    log.info(f"output: {output}")
                    return output
                else:
                    # Handle errors
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }
                
    except Exception as e:
        log.error(traceback.format_exc())
        return {
            "success": False,
            "error_message": e,
            "error_code": 500
        }
    
async def file_upload(log,
    file_path: Optional[str] = None,
    purpose: Optional[str] = None
):
    
    #Required parameters
    if file_path is None: 
        log.error("Error: File_path cannot be None")
        return {
            "success": False,
            "error_message": "Error: File_path cannot be None",
            "error_code": 400
        }
    if purpose is None: 
        log.error("Error: Purpose cannot be None")
        return {
            "success": False,
            "error_message": "Error: Purpose cannot be None",
            "error_code": 400
        }

    # Create a FormData object for a multipart/form-data request
    data = aiohttp.FormData()
    data.add_field('purpose', purpose)
    async with aiofiles.open(file_path, 'rb') as f:
        data.add_field('file', f, filename=os.path.basename(file_path))
    
    #header
    headers=classic_openai_headers.copy()
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.FILES.url}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            # Create FormData within the session context manager
            data = aiohttp.FormData()
            data.add_field('purpose', purpose)

            async with aiofiles.open(file_path, 'rb') as f:
                content = await f.read()  # Read file content
                data.add_field('file', content, filename=os.path.basename(file_path), content_type='application/octet-stream')
                
                async with session.post(url=url, headers=headers, data=data) as response:
                    if response.status == 200:
                        output = await response.json()
                        status=True
                        output["success"]=status
                        log.info(f"output: {output}")
                        return output
                    else:
                        # Handle errors
                        error_response = await response.json()
                        error_message = error_response.get('error', {}).get('message', 'Unknown error')
                        error_code = error_response.get('error', {}).get('code', 'Unknown code')
                        log.error(f"Error: {response.status}")
                        log.error(f"Message: {error_message}")

                        return {
                            "success": False,
                            "error_message": error_message,
                            "error_code": error_code
                        }

    except Exception as e:
        log.error(traceback.format_exc())
        return {        
            "success": False,
            "error_message": e,
            "error_code": 500
        }

async def file_delete(log,
    file_id: Optional[Enum] = None
):
    
    #Required parameters
    if file_id is None: 
        log.error("Error: File_id cannot be None")
        return {
            "success": False,
            "error_message": "Error: File_id cannot be None",
            "error_code": 400
        }

    #header
    headers=classic_openai_headers.copy()

    # Set url
    url=f'{OpenAIEnums.Endpoints.FILES.url}/{file_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.delete(url=url, headers=headers) as response:
                if response.status == 200:
                    output = await response.json()
                    status=True
                    output["success"]=status
                    log.info(f"output: {output}")
                    return output
                else:
                    # Handle errors
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {        
            "success": False,
            "error_message": e,
            "error_code": 500
        }

async def file_retrieve(log,
    file_id: Optional[str] = None
):
    
    #Required parameters
    if file_id is None: 
        log.error("Error: File_id cannot be None")
        return {
            "success": False,
            "error_message": "Error: File_id cannot be None",
            "error_code": 400
        }

    #header
    headers=classic_openai_headers.copy()
    
    # Set url
    url=f'{OpenAIEnums.Endpoints.FILES.url}/{file_id}'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:
                    output = await response.json()
                    status=True
                    output["success"]=status
                    log.info(f"output: {output}")
                    return output
                else:
                    # Handle errors
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {        
            "success": False,
            "error_message": e,
            "error_code": 500
        }

async def file_retrieve_content(log,
    file_id: Optional[str] = None
):
    
    #Required parameters
    if file_id is None:
        log.error("Error: File_id cannot be None")
        return {
            "success": False,
            "error_message": "Error: File_id cannot be None",
            "error_code": 400
        }

    #header
    headers=classic_openai_headers.copy()

    # Set url
    url=f'{OpenAIEnums.Endpoints.FILES.url}/{file_id}/content'
    
    # Send request
    status=False
    output={}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url=url, headers=headers) as response:
                if response.status == 200:
                    output["content"] = await response.read()
                    status=True
                    output["success"]=status
                    log.info(f"output: {output}")
                    return output
                else:
                    # Handle errors
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {        
            "success": False,
            "error_message": e,
            "error_code": 500
        }