from enum import Enum
import traceback
from typing import Optional
import aiohttp
# from wsagent.ai_services.ai_services import AIServices
from wsagent.ai_services.services.openai.headers import classic_openai_headers

async def moderation_create(log,
    api_key: Optional[str] = None,
    input: Optional[str] = None,    
    model: Optional[Enum] = None     
):

    headers=classic_openai_headers.copy()
    headers['Content-Type']= 'application/json'
    
    # Set parameters
    if api_key is not None: 
        headers['Authorization'] = f'Bearer {api_key}'
        
    if not input: 
        log.error("Error: input cannot be None")
        return {
            "success":False, 
            "error_message":"Error: input cannot be None",
            "error_code": 400
        }
    
    if not model: model=AIServices.OpenAI.Feature.Moderation.Model.TEXT_MODERATION_STABLE
    
    # Set url
    url=f'{AIServices.OpenAI.Endpoints.MODERATION.url}'
    
    data={}
    data['input']=input
    data['model']=model.name
    
    # Send the request using an aiohttp client session
    status = False
    output = {}
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url=url, headers=headers, json=data) as response:
                if response.status == 200:
                    output = await response.json()
                    status = True
                    output["success"] = status
                    log.info(f"output: {output}")

                    return output
                
                else:
                    # Handle errors
                    error_response = await response.json()
                    error_message = error_response.get('error', {}).get('message', 'Unknown error')
                    error_code = error_response.get('error', {}).get('code', 'Unknown code')
                    log.error(f"Error: {response.status}")
                    log.error(f"Message: {error_message}")

                    return {
                        "success": False,
                        "error_message": error_message,
                        "error_code": error_code
                    }

    except Exception as e:
        log.error(traceback.format_exc())
        return {
            "success":False, 
            "error_message":traceback.format_exc(),
            "error_code": 500
        }