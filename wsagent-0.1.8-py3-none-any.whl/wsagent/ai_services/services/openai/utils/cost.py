
from enum import Enum
from typing import Optional, Union

from wsagent.ai_services.ai_services_enum import AIServices

def calculate_token_cost(
    model: Optional[Union[Enum,str]]= None, 
    input_tokens: Optional[int] = None,
    output_tokens: Optional[int] = None,
) -> float:
    
    if model is None: raise Exception("Model is required")
    if input_tokens is None: raise Exception("Prompt tokens is required")
    if output_tokens is None: raise Exception("Completion tokens is required")
    
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    enum_model = AIServices.get_enum_model_from_model_name(str_model)
    
    cost_per_prompt_token = enum_model.cost_per_input_token
    cost_per_completion_token = enum_model.cost_per_ouput_token

    return (cost_per_prompt_token * float(input_tokens)) + (cost_per_completion_token * float(output_tokens))
           
def calculate_embedding_cost(
    model: Optional[Union[Enum,str]]= None, 
    input_tokens: Optional[int] = None,
) -> float:
    
    if model is None: raise Exception("Model is required")
    if input_tokens is None: raise Exception("Input tokens is required")
    
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    enum_model = AIServices.get_enum_model_from_model_name(str_model)
    
    cost_per_input_token = enum_model.cost_per_input_token
    return cost_per_input_token * input_tokens

def calculate_vision_image_cost(
    vision_model: Optional[Union[Enum,str]]= None, 
    image_detail : Optional[str]= None, 
    input_tiles: Optional[int]= None, 
) -> float:
    
    if input_tiles is None: raise Exception("Input tiles is required")
    if image_detail not in ["low", "high"]: raise Exception("image_detail must be low or high")
    
    if isinstance(vision_model, str):
        str_vision_model = vision_model
    elif isinstance(vision_model, Enum):
        str_vision_model = vision_model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    enum_model = AIServices.get_enum_model_from_model_name(str_vision_model)
    
    base_img_token = str_vision_model.base_img_token
    base_cost_per_token = str_vision_model.cost_per_input_token
    
    if image_detail == "low":
        tokens = base_img_token
    if image_detail == "high":
        tokens = base_img_token + (2*base_img_token * input_tiles)

    image_cost= tokens*base_cost_per_token
    
    return image_cost

def calculate_audio_tts_cost(
    audio_model: Optional[Union[Enum,str]]= None, 
    user_msg: Optional[str]= None
) -> float:
    if audio_model is None:
        raise ValueError("Audio model is required")
    if user_msg is None:
        raise ValueError("User message in characters is required")

    if isinstance(audio_model, str):
        str_model = audio_model
    elif isinstance(audio_model, Enum):
        str_model = audio_model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    enum_model = AIServices.get_enum_model_from_model_name(str_model)

    user_msg_len = len(user_msg)
    cost = user_msg_len * enum_model.cost_usage

    return cost

def calculate_audio_stt_cost(
    audio_model: Optional[Union[Enum,str]]= None, 
    audio_time_s_length: Optional[int]= None
) -> float:
    if audio_model is None:
        raise ValueError("Audio model is required")
    if audio_time_s_length is None:
        raise ValueError("audio_time_s_length is required")

    if isinstance(audio_model, str):
        str_model = audio_model
    elif isinstance(audio_model, Enum):
        str_model = audio_model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    enum_model = AIServices.get_enum_model_from_model_name(str_model)
    
    cost = audio_time_s_length * enum_model.cost_usage

    return cost

def calculate_image_generator_cost(
    image_model: Optional[Union[Enum,str]]= None, 
    quality: Optional[str] = None,
    size: Optional[str] = None
) -> float:
    
    if image_model is None:
        raise ValueError("Model is required")
    if size is None:
        raise ValueError("Size is required")

    if isinstance(image_model, str):
        str_model = image_model
    elif isinstance(image_model, Enum):
        str_model = image_model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    enum_model = AIServices.get_enum_model_from_model_name(str_model)

    cost_info = enum_model.cost_usage
    if size not in cost_info:
        raise ValueError("The specified size is not available for this model")

    if isinstance(cost_info[size], dict):
        if quality not in cost_info[size]:
            raise ValueError("The specified quality is not available for this size")
        cost = cost_info[size][quality]
    else:
        cost = cost_info[size]

    return cost