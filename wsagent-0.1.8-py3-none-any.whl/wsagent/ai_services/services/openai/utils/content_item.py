from typing import Optional
from wsagent.utils.image import b64encode_image_from_path, b64encode_image_from_url

def content_item_image(
    image: Optional[str] = None,
    image_detail: Optional[str] = None,
    media_type: Optional[str] = None
) -> dict:
    if image.startswith(('http')):
        img_b64 = b64encode_image_from_url(image)
        if media_type is None: media_type="image/jpeg"
    elif any(image.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.webp']):
        img_b64 = b64encode_image_from_path(image)
        if media_type is None: media_type = f"image/{image.split('.')[-1]}"
    else:
        img_b64=image

    image_json={
        "type": "image_url",
        "image_url": {
            "url": f"data:image/jpeg;base64,{img_b64}",
            "detail": image_detail
        }
    }
    return image_json

def content_item_text(
    text: Optional[str] = None
) -> dict:
    return {
        "type": "text", 
        "text": text
    }