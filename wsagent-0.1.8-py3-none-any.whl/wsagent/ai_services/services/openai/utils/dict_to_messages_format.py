from typing import Optional

def format_chat_messages_responses(elements: Optional[list] = None) -> list:
    
    if elements is None: raise ValueError("elements must be provided")
    
    # Initialize an empty list to hold the formatted responses
    formatted_list = []

    # Iterate through each response in the input list
    for element in elements:
        # Create a new dictionary with only the 'role' and 'content' keys
        formatted_response = {
            'role': element['role'],
            'content': element['content']
        }
        # Append the formatted dictionary to the list
        formatted_list.append(formatted_response)

    return formatted_list