import os
from dotenv import load_dotenv
load_dotenv()

# OpenAI Keys
OPENAI_DEFAULT_MODEL=os.getenv("OPENAI_DEFAULT_MODEL",'gpt-4o')
OPENAI_API_KEY=os.getenv("OPENAI_API_KEY",'')