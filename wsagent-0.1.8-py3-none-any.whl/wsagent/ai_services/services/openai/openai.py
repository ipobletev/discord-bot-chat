from enum import Enum
from typing import AsyncGenerator, Optional, Union
from wsagent.ai_services.base import AIServiceBase
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.ai_services.services.openai.function_mapping import openai_function_map
from wsagent.utils.validate_args import validate_required_args

class OpenAI(AIServiceBase):
    """OpenAI model."""
    @validate_required_args
    def __init__(self, 
        ai_service_params: Optional[dict] = None, 
        session_id: Optional[str] = None,         
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool] = None,
        enable_log_stream: Optional[bool] = None,
    ) -> None:
                
        """Initialize the OpenAI model."""
        super().__init__(
            ai_service_name='openai',
            ai_service_params=ai_service_params,
            session_id=session_id,
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )
        
    @validate_required_args
    async def internal_execute(self,
        action: Optional[Union[Enum,str]] = None,
        action_params: Optional[dict] = None,
    ) -> AsyncGenerator[Union[str, AIServiceResponse], None]:
        
        if action is None: 
            self.log.error("action cannot be None")
            raise ValueError("action cannot be None")

        if isinstance(action, str):
            str_action = action
        elif isinstance(action, Enum):
            str_action = action.name
        else:
            raise ValueError("action must be a string or Enum.")
        
        # Retrieve the appropriate function from the map
        function_to_call = openai_function_map.get(str_action)
        
        action_params["service"] = "OpenAI"

        # Check if the function exists in the map
        if function_to_call:
            # If it does, call it with the provided arguments
            self.log.info(f"Executing: {function_to_call.__name__}")
            output = function_to_call(
                action=action,
                action_params=action_params,
                ai_service_params=self.ai_service_params,
                log=self.log
            )
            # Consume the internal_async_generator and yield its results
            async for result in output:
                yield result
        else:
            # If not, self.log and raise an error
            self.log.error(f"Unknown type: {action}")
            raise ValueError(f"Unknown type: {action}")