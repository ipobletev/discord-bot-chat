from enum import Enum

class OpenAIEnums:

    @property
    def name(self):
        return "OpenAIEnums"

    class Feature:
        
        class LLM:
            
            class Model(Enum):
                """An enumeration of OpenAI models."""
                # Text
                # Enum name            Model Name                   cost_per_input_token   cost_per_ouput_token
                # LLM Model
                GPT_3_5_TURBO          = ("gpt-3.5-turbo",          0.0  / 1000         , 0.0     / 1000)
                GPT_3_5_TURBO_0125     = ("gpt-3.5-turbo-0125",     0.0  / 1000         , 0.0     / 1000)
                GPT_3_5_TURBO_1106     = ("gpt-3.5-turbo-1106",     0.0  / 1000         , 0.0     / 1000)
                GPT_4                  = ("gpt-4",                  0.03 / 1000         , 0.06    / 1000)
                GPT_4_0613             = ("gpt-4-0613",             0.01 / 1000         , 0.03    / 1000)
                GPT_4_1106_PREVIEW     = ("gpt-4-1106-preview",     0.01 / 1000         , 0.03    / 1000)
                GPT_4_0125_PREVIEW     = ("gpt-4-0125-preview",     0.01 / 1000         , 0.03    / 1000)
                GPT_4_TURBO_PREVIEW    = ("gpt-4-turbo-preview",    0.01 / 1000         , 0.03    / 1000)
                GPT_4_TURBO_2024_04_09 = ("gpt-4-turbo-2024-04-09", 0.01 / 1000         , 0.03    / 1000)
                
                #Vision
                # Enum name                 Model Name                        cost_per_input_token  cost_per_ouput_token  base_img_token
                # LLM Model
                GPT_4_TURBO                 = ("gpt-4-turbo"                  , 0.01 / 1000 , 0.03 / 1000      , 85)
                GPT_4_VISION_PREVIEW        = ("gpt-4-vision-preview"         , 0.01 / 1000 , 0.03 / 1000      , 85)
                GPT_4_1106_VISION_PREVIEW   = ("gpt-4-1106-vision-preview"    , 0.01 / 1000 , 0.03 / 1000      , 85)

                # Omni
                # Enum name             Model Name                   cost_per_input_token     cost_per_ouput_token    base_img_token
                GPT_4_O_MINI            = ("gpt-4o-mini"            , 0.150  / 1000000         , 0.600     / 1000000,     85)
                GPT_4_O_MINI_2024_07_18 = ("gpt-4o-mini-2024-07-18" , 0.150  / 1000000         , 0.600     / 1000000,     85)
                GPT_4_O                 = ("gpt-4o"                 , 5      / 1000000         , 15.0      / 1000000,     85)
                GPT_4_O_2024_05_13      = ("gpt-4o-2024-05-13"      , 5      / 1000000         , 15.0      / 1000000,     85)

                @property
                def name(self):
                    return self.value[0]

                @property
                def cost_per_input_token(self):
                    return self.value[1]

                @property
                def cost_per_ouput_token(self):
                    return self.value[2]
                
                @property
                def base_img_token(self):
                    return self.value[3]
                    
        class Image:
            
            class Model(Enum):
                DALL_E_3 = ("dall-e-3", {
                    '1024x1024': {'standard': 0.04, 'hd': 0.08},
                    '1024x1792': {'standard': 0.08, 'hd': 0.12},
                    '1792x1024': {'standard': 0.08, 'hd': 0.12},
                })

                DALL_E_2 = ("dall-e-2", {
                    '1024x1024': 0.02,
                    '512x512': 0.018,
                    '256x256': 0.016,
                })
                
                @property
                def name(self):
                    return self.value[0]
                
                @property
                def cost_usage(self):
                    return self.value[1]
            
            class Resolution(Enum):
                _1024x1024  = "1024x1024"
                _1024x1792  = '1024x1792'
                _1792x1024  = '1792x1024'
                _512x512    = '512x512'
                _256x256    = '256x256'
                
                @property
                def name(self):
                    return self.value
        
        class Audio:
            
            class Model(Enum):
                # TTS
                TTS_1                   = ("tts-1",             0.015 / 1000)
                TTS_1_HD                = ("tts-1-hd",          0.030 / 1000)
                # STT
                WHISPER_1               = ("whisper-1",         0.006 / 60)

                @property
                def name(self):
                    return self.value[0]
                
                @property
                def cost_usage(self):
                    return self.value[1]
                
            class Voices(Enum):
                
                ALLOY = "alloy"
                ECHO = "echo"
                FABLE = "fable"
                ONYX = "onyx"
                NOVA = "nova"
                SHIMMER = "shimmer"
                
        class Moderation:
            
            class Model(Enum):
                
                TEXT_MODERATION_LASTEST = ("text-moderation-latest") # free
                TEXT_MODERATION_STABLE  = ("text-moderation-stable") # free

                @property
                def name(self):
                    return self.value
            
        class Embeddings:

            class Model(Enum):
                
                # Embeddings Model
                ADA_V2              = ("text-embedding-ada-002",    0.0001   / 1000          , 0.0  , 1536)
                SMALL_V3            = ("text-embedding-3-small",    0.00002  / 1000          , 0.0  , 1536)
                LARGE_V3            = ("text-embedding-3-large",    0.00013  / 1000          , 0.0  , 3072)

                @property
                def name(self):
                    return self.value[0]

                @property
                def cost_per_input_token(self):
                    return self.value[1]

                @property
                def dimensions(self):
                    return self.value[3]
        
    class Action:
        
        class Chat(Enum):
            CREATE = "CHAT_CREATE"
            """
            ### Brief: Create a chat completion.
            
            ### Action params:
            
            - messages: list. of messages to be used as context for the completion in OpenAI format. Required.
            - model: Enum. The model to use for the completion. Optional.
            - frequency_penalty: float. The frequency penalty to apply to the completion. Optional.
            - logit_bias: The logit bias to apply to the completion. Optional.
            - logprobs: The logprobs to use for the completion. Optional.
            - max_tokens: The maximum number of tokens to generate. Optional.
            - n: The number of completions to generate. Optional.
            - presence_penalty: The presence penalty to apply to the completion. Optional.
            - response_format: The response format to use for the completion. Optional.
            - seed: The seed to use for the completion. Optional.
            - stop: The stop sequence to use for the completion. Optional.
            - stream: The stream to use for the completion. Optional.
            - temperature: The temperature to use for the completion. Optional.
            - top_p: The top_k to use for the completion. Optional.
            - tools: The tools to use for the completion. Optional.
            - tool_choise: The tool chooise to use for the completion. Optional.
            - user: The user to use for the completion. Optional.
            - function: The function to use for the completion. Optional.
            - retries: The number of retries to use for the completion. Optional.
            - backoff: The backoff to use for the completion. Optional.
            - user_message: The user message to use for the completion. Optional.
            - prefix_message: The prefix message to use for the completion. Optional.
            - suffix_message: The suffix message to use for the completion. Optional.
            - images: The images to use for the completion. Optional.
            - image_details: The image details to use for the completion. Optional.
            - callback: The callback to use for the completion. Optional.
            - stop_event: The stop event to use for the completion. Optional.
            
            ### Example
            ```
            messages = [{ "role": "user", "content": "Hello, how are you?" }]

            response = await ai_service.execute(
                action=OpenAIEnums.Action.Chat.CREATE,
                action_params={
                    "model": OpenAIEnums.Feature.LLM.Model.Omni.GPT_4_O,
                    "messages": messages,
                }
            )
            print(response.result)
            ```
            """
            
            @property
            def name(self):
                return self.value
            
        class Embeddings(Enum):
            CREATE = "EMBEDDING_CREATE"
            """
            ### Brief: Create an embedding.
            
            ### Action params:
            
            - input: str. The input text to create the embedding. Required.
            - model: Enum. The model to use for the completion. Optional.
            - encoding_format: str. The encoding format to use for the completion. Optional. Default: float.
            - dimensions: int. The dimensions to use for the completion. Optional.
            - user: str. The user to use for the completion. Optional.
            - retries: int. The number of retries to use for the completion. Optional.
            - backoff: int. The backoff to use for the completion. Optional.
            
            ### Example
            ```
            response = await ai_service.execute(
                action=OpenAIEnums.Action.Embeddings.CREATE,
                action_params={
                    "model": OpenAIEnums.Feature.Embeddings.Model.LARGE_V3,
                    "input": "hola como estas?",
                }
            )
            print(response.result)
            ```
            """
            
            @property
            def name(self):
                return self.value
            
        class FineTuning(Enum):
            CREATE = "FINE_TUNNING_CREATE"
            LIST_JOBS = "FINE_TUNNING_LIST"
            RETRIEVE = "FINE_TUNNING_RETRIEVE"
            CANCEL = "FINE_TUNNING_CANCEL"
            LIST_EVENTS = "FINE_TUNNING_LIST_EVENTS"
            
            @property
            def name(self):
                return self.value
            
        class File(Enum):
            
            LIST               = "LIST"
            UPLOAD             = "UPLOAD"
            DELETE             = "DELETE"
            RETRIEVE           = "RETRIEVE"
            RETRIEVE_CONTENT   = "RETRIEVE_CONTENT"
            
            @property
            def name(self):
                return self.value
                
        class Assistants(Enum):
            #Main
            CREATE                = "ASSISTANT_CREATE"
            RETRIEVE              = "ASSISTANT_STATUS"
            DELETE                = "ASSISTANT_DELETE"
            MODIFY                = "ASSISTANT_MODIFY"
            LIST                  = "ASSISTANT_LIST"    
            #File
            FILE_CREATE           = "ASSISTANT_FILE_CREATE"
            FILE_RETRIEVE         = "ASSISTANT_FILE_RETRIEVE"
            FILE_DELETE           = "ASSISTANT_FILE_DELETE"
            FILE_LIST             = "ASSISTANT_FILE_LIST" 
            #Threads
            THREAD_RETRIEVE                 = "ASSISTANT_THREAD_RETRIEVE"
            THREAD_CREATE                   = "ASSISTANT_THREAD_CREATE"
            THREAD_MODIFY                   = "ASSISTANT_THREAD_MODIFY"
            THREAD_DELETE                   = "ASSISTANT_THREAD_DELETE"   
            #Messages
            THREAD_MESSAGES_CREATE          = "ASSISTANT_THREAD_MESSAGES_CREATE"
            THREAD_MESSAGES_RETRIEVE        = "ASSISTANT_THREAD_MESSAGES_RETRIEVE"
            THREAD_MESSAGES_MODIFY          = "ASSISTANT_THREAD_MESSAGES_MODIFY"
            THREAD_MESSAGES_LIST            = "ASSISTANT_THREAD_MESSAGES_LIST"
            THREAD_MESSAGES_FILE_RETRIEVE   = "ASSISTANT_THREAD_MESSAGES_FILE_RETRIEVE"
            THREAD_MESSAGES_FILE_LIST       = "ASSISTANT_THREAD_MESSAGES_FILE_LIST"  
            #Runs
            THREAD_RUN_CREATE               = "ASSISTANT_THREAD_RUN_CREATE"
            THREAD_RUN_RETRIEVE             = "ASSISTANT_THREAD_RUN_RETRIEVE"
            THREAD_RUN_MODIFY               = "ASSISTANT_THREAD_RUN_MODIFY"
            THREAD_RUN_LIST                 = "ASSISTANT_THREAD_RUN_LIST"
            THREAD_RUN_CANCEL               = "ASSISTANT_THREAD_RUN_CANCEL"    
            THREAD_CREATE_AND_RUN           = "ASSISTANT_THREAD_CREATE_AND_RUN"    
            THREAD_RUN_STEP_RETRIEVE        = "ASSISTANT_THREAD_RUN_STEP_RETRIEVE"
            THREAD_RUN_STEP_LIST            = "ASSISTANT_THREAD_RUN_STEP_LIST"    
            
            @property
            def name(self):
                return self.value
        
        class Moderation(Enum):
            
            CREATE = "MODERATION_CREATE"

            @property
            def name(self):
                return self.value

        class Models(Enum):
            
            LIST                        = "MODELS_LIST"
            RETRIEVE                    = "MODELS_RETRIEVE"
            DELETE_FINETUNNING_MODEL    = "MODELS_DELETE_FINETUNNING_MODEL"

            @property
            def name(self):
                return self.value
        
        class Images(Enum):
            
            CREATE      = "IMAGE_CREATE"
            EDIT        = "IMAGE_EDIT"
            VARIATION   = "IMAGE_VARIATION"

            @property
            def name(self):
                return self.value
            
        class Audio(Enum):
            
            TEXT_TO_SPEECH   = "TEXT_TO_SPEECH"
            SPEECH_TO_TEXT   = "SPEECH_TO_TEXT"
            TRANSLATION      = "TRANSLATION"

            @property
            def name(self):
                return self.value

    class Endpoints(Enum):
        BASE                = "https://api.openai.com/v1/"
        MODERATION          = f"{BASE}/moderations"
        EMBEDDINGS          = f"{BASE}/embeddings"
        CHATCOMPLETION      = f"{BASE}/chat/completions"
        FINE_TUNNING        = f"{BASE}/fine_tuning/jobs"
        FILES               = f"{BASE}/files"
        MODELS              = f"{BASE}/models"
        AUDIO_SPEECH        = f"{BASE}/audio/speech"
        AUDIO_TRANSCRIPTION = f"{BASE}/audio/transcriptions"
        AUDIO_TRANSLATION   = f"{BASE}/audio/translations"
        IMAGES_CREATE       = f"{BASE}/images/generations"
        IMAGES_EDIT         = f"{BASE}/images/edits"
        IMAGES_VARIATION    = f"{BASE}/images/variations"
        ASSISTANT           = f"{BASE}/assistants"
        THREAD              = f"{BASE}/threads"
        
        @property
        def url(self):
            return self.value