

# Dispatch dictionary
from wsagent.ai_services.services.groq.endpoints.chat.chat import create_chat_completion
from wsagent.ai_services.services.groq.enums import GroqAIEnums

groq_function_map = {
    ### CHAT ###
    GroqAIEnums.Action.Chat.CREATE.value: create_chat_completion,
}