
from enum import Enum
from typing import Optional, Union
from wsagent.ai_services.ai_services_enum import AIServices

def calculate_token_cost(
    model: Optional[Union[Enum,str]]= None, 
    input_tokens: Optional[int] = None,
    output_tokens: Optional[int] = None,
) -> float:
    
    if model is None: raise Exception("Model is required")
    if input_tokens is None: raise Exception("Prompt tokens is required")
    if output_tokens is None: raise Exception("Completion tokens is required")

    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    enum_model = AIServices.get_enum_model_from_model_name(str_model)
    
    cost_per_prompt_token = enum_model.cost_per_input_token
    cost_per_completion_token = enum_model.cost_per_ouput_token

    return (cost_per_prompt_token * float(input_tokens)) + (cost_per_completion_token * float(output_tokens))
           
# def calculate_vision_image_cost(
#     vision_model: Optional[Enum]= None,
#     image_detail : Optional[str]= None, 
#     input_tiles: Optional[int]= None, 
# ) -> float:
    
#     if input_tiles is None: raise Exception("Input tiles is required")
#     if image_detail not in ["low", "high"]: raise Exception("image_detail must be low or high")
    
#     base_img_token = vision_model.base_img_token
#     base_cost_per_token = vision_model.cost_per_input_token
    
#     if image_detail == "low":
#         tokens = base_img_token
#     if image_detail == "high":
#         tokens = base_img_token + (2*base_img_token * input_tiles)

#     image_cost= tokens*base_cost_per_token
    
#     return image_cost