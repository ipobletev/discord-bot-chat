
import base64
from enum import Enum
import io
from pathlib import Path
from PIL import Image
import requests
from typing import Optional, Union
from io import BytesIO
import tiktoken
from wsagent.ai_services.ai_services_enum import AIServices
from wsagent.ai_services.services.openai.enums import OpenAIEnums

# def count_tokens_from_messages(
#     messages: Optional[list]= None,
#     model: Optional[Union[Enum,str]]= None
# ):
#     if messages is None: raise Exception("Messages are required")
    
#     # Calculate tokens
#     tokens=0
#     for message in messages:
#         content=message.get('content', '')
#         txt_content=''
#         if isinstance(content, str):
#             txt_content=content
#             tokens+=count_tokens_from_text(input_txt=txt_content, model=model)
#         else:
#             for item in content:
#                 if item['type']=='text':
#                     txt_content=item['text']
#                     tokens+=count_tokens_from_text(input_txt=txt_content, model=model)
#                 # elif item['type']=='image_url':
#                 #     image=item['image_url']["url"].replace("data:image/jpeg;base64,","")           
#                     # tokens+=count_tokens_from_image(vision_model=model, image=image)

#         tokens+=count_tokens_from_text(input_txt=txt_content, model=model)
    
#     return tokens
    
# def count_tokens_from_text(
#     input_txt: Optional[str]= None,
#     model: Optional[Union[Enum,str]]= None
# ):
    
#     if model is None: model=OpenAIEnums.Feature.LLM.Model.GPT_3_5_TURBO_1106
#     if input_txt is None: raise Exception("Input text is required")
    
#     # Get the model name in str from different types of enums but same string model name
#     if isinstance(model, str):
#         str_model = model
#     elif isinstance(model, Enum):
#         str_model = model.name
#     else:
#         raise ValueError("action must be a string or Enum.")

#     # Get the oficial enum model from the model name
#     enum_model = AIServices.get_enum_model_from_model_name(str_model)
    
#     # Patch for Omni models, this not implement in ticktoken yet
#     if enum_model == OpenAIEnums.Feature.LLM.Model.GPT_4_O or enum_model == OpenAIEnums.Feature.LLM.Model.GPT_4_O_2024_05_13:
#         model = OpenAIEnums.Feature.LLM.Model.GPT_4_TURBO.name
#     if enum_model == OpenAIEnums.Feature.LLM.Model.GPT_4_O.name or enum_model == OpenAIEnums.Feature.LLM.Model.GPT_4_O_2024_05_13.name:
#         model = OpenAIEnums.Feature.LLM.Model.GPT_4_TURBO.name
    
#     # Get the name of the model to use
#     str_model=model.name
    
#     # Get the tokens from encoding model
#     enc = tiktoken.encoding_for_model(str_model)
#     return len(enc.encode(input_txt, disallowed_special=()))

# def count_tokens_from_image(
#     vision_model: Optional[Enum]= None,
#     image_detail : Optional[str]= None, 
#     image: Optional[str] = None, # base64_image or image_url
# ) -> float:
    
#     if image_detail not in ["low", "high"]: image_detail="high"
#     if vision_model is None: vision_model=OpenAIEnums.Feature.LLM.Model.Vision.GPT_4_TURBO
#     if image is None: raise Exception("You must provide an image path or url")

#     base_img_token = vision_model.base_img_token
    
#     tiles = count_image_tiles(image)

#     if image_detail == "low":
#         tokens = base_img_token
#     if image_detail == "high":
#         tokens = base_img_token + (2*base_img_token * tiles)
        
#     return tokens

# def count_image_tiles(
#     image: Optional[str] = None # base64_image or image_url
# ) -> int:

#     # OpenAI Tile Counting
#     TILE_SIZE = 512
#     SHORTER_SIZE = 768
#     headers = {
#         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0'
#     }
    
#     def get_image_dimensions_from_url(url: str):
#         try:
#             response = requests.get(url=url,headers=headers)
#             if response.status_code == 200:
#                 # Check for image Content-Type
#                 if "image" in response.headers.get("Content-Type", ""):
#                     image = Image.open(BytesIO(response.content))
#                     return image.size
#                 else:
#                     raise ValueError(f"The URL did not point to an image: {url}")

#             else:
#                 raise ValueError(f"Failed to fetch the image. HTTP Status Code: {response.status_code}")
#         except Exception as e:
#             # Log or print the exception e
#             print(f"An error occurred: {e}")
#             return None

#     def get_image_dimensions_from_file(image_path: str):
#         # Reading the image as binary data
#         with open(image_path, 'rb') as file:
#             image_bytes = file.read()
            
#         # Using BytesIO to convert the binary data into a file-like object
#         byte_stream = io.BytesIO(image_bytes)

#         # Use Pillow to open the image and get dimensions
#         with Image.open(byte_stream) as img:
#             width, height = img.size
            
#         return img.size

#     if image.startswith(('http://', 'https://')):
#         dimensions = get_image_dimensions_from_url(image)
#     elif len(image) < 512:
#         if Path(image).exists():
#             dimensions = get_image_dimensions_from_file(image)
#         else:
#             raise ValueError("The image path does not exist.")
#     else:
#         # Assuming the remaining case is base64, though you could add more validation.
#         image_data = base64.b64decode(image)
#         with Image.open(BytesIO(image_data)) as img:
#             dimensions = img.size
    
#     width=dimensions[0]
#     height=dimensions[1]

#     if max(width, height) > 2048:
#         # Mantener la relación de aspecto
#         aspect_ratio = width / height
#         if width > height:
#             width = 2048
#             height = 2048 / aspect_ratio
#         else:
#             height = 2048
#             width = 2048 * aspect_ratio
    
#     # Escalar la imagen de tal manera que el lado más corto sea de 768px.
#     shortest_side = min(width, height)
#     if shortest_side > SHORTER_SIZE:
#         scale_factor = SHORTER_SIZE / shortest_side
#         width = width * scale_factor
#         height = height * scale_factor

#     # Calcular cuántos tiles de 512px son necesarios.
#     tiles_wide = (width // TILE_SIZE) + (1 if width % TILE_SIZE else 0)
#     tiles_high = (height // TILE_SIZE) + (1 if height % TILE_SIZE else 0)
#     total_tiles = int(tiles_wide * tiles_high)

#     return total_tiles


