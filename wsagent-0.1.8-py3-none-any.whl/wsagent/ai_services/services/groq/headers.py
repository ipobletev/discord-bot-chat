
from wsagent.ai_services.services.groq.config import GROQ_API_KEY

classic_groq_headers = {
    'Authorization': f'Bearer {GROQ_API_KEY}'
}
