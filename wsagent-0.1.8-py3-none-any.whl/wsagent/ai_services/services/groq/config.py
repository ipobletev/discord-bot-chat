import os
from dotenv import load_dotenv
load_dotenv()

# OpenAI Keys
GROQ_DEFAULT_MODEL=os.getenv("GROQ_DEFAULT_MODEL",'Llama3-8b-8192')
GROQ_API_KEY=os.getenv("GROQ_API_KEY",'')