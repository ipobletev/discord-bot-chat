import asyncio
from datetime import datetime
from enum import Enum
import json
import logging
import traceback
from typing import Any, Callable, Coroutine, Dict, List, Optional, Union
from wsagent.ai_services.exceptions import StopException
# from wsagent.ai_services.services.groq.utils.content_item import content_item_image, content_item_text
from wsagent.ai_services.services.groq.utils.cost import calculate_token_cost
# from wsagent.ai_services.services.groq.utils.count import count_image_tiles, count_tokens_from_image, count_tokens_from_messages, count_tokens_from_text
from wsagent.ai_services.services.groq.headers import classic_groq_headers
from wsagent.ai_services.services.groq.enums import GroqAIEnums
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.request import request_with_exponential_backoff

async def create_chat_completion(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AIServiceResponse:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    messages=action_params.get('messages', None)
    model=action_params.get('model', None)
    temperature=action_params.get('temperature', None)
    max_tokens=action_params.get('max_tokens', None)
    top_p=action_params.get('top_p', None)
    stream=action_params.get('stream', None)
    stop=action_params.get('stop', None)
    response_format=action_params.get('response_format', None)
    tools=action_params.get('tools', None)
    tool_choice=action_params.get('tool_choice', None)
    retries=action_params.get('retries', None)
    backoff_base=action_params.get('backoff_base', None)
    user_message=action_params.get('user_message', None)
    prefix_messages=action_params.get('prefix_messages', None)
    suffix_messages=action_params.get('suffix_messages', None)
    stop_event=action_params.get('stop_event', None)
    # ai_service_params
    api_key=ai_service_params.get('groq_api_key', None)
    
    # Check if all required parameters are provided
    if api_key is None: raise ValueError("api_key cannot be None")
    
    # Optional parameters with default values
    if model is None: model=GroqAIEnums.Feature.LLM.Model.LLAMA3_70B_8192
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2

    str_model = None
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")

    # Header
    headers=classic_groq_headers.copy()
    headers['Authorization'] = f'Bearer {api_key}'
    headers['Content-Type']= 'application/json'
    
    # Set data
    data={}
    data["model"]=str_model
    if max_tokens: data["max_tokens"]=max_tokens
    if response_format: data["response_format"]=response_format
    if stop: data["stop"]=stop
    if stream: data["stream"]=stream
    if temperature: data["temperature"]=temperature
    if top_p: data["top_p"]=top_p
    if tools: data["tools"]=tools
    if tool_choice: data["tool_choice"]=tool_choice

    # Prepare messages with easy way
    if messages is None:
        # User message
        chat_user_message = [{"role": "user", "content": user_message}]

        # Make the payload
        messages = prefix_messages + chat_user_message + suffix_messages

    # Data
    data["messages"] = messages

    # Set url
    url=GroqAIEnums.Endpoints.CHATCOMPLETION.url
    
    # Clear
    tool_calls_raw=[]
    logprobs_call=[]
    chunk_text=[]
    tools_calls = []
    raw_response={}
    content=[]
    if stream: raw_response['byte_line']=[]
    completion_text_chunk=''
    output_tokens=0
    input_tokens=0
    
    # Log messages
    log.info(f'Data parameters to llm server: {data}')

    try:
        async for request_response in request_with_exponential_backoff(
            stream=stream,
            stop_event=stop_event,
            retries=retries,
            backoff_base=backoff_base,
            url=url, 
            headers=headers, 
            json=data, 
            log=log, 
            stream_handler=stream_response_handler,
            # Extra arg for stream_handler
            chunk_text=chunk_text,
            tool_calls_raw=tool_calls_raw,
            logprobs_call=logprobs_call,
            raw_response=raw_response
        ):
            if stream: yield request_response
    except StopException:
        pass
        
    if stream:
        input_tokens=0
        output_tokens=0
        #input_tokens=count_tokens_from_messages(messages=messages, model=model)
        if tools:
            for tool in tool_calls_raw:
                #output_tokens+=count_tokens_from_text(input_txt=json.dumps(tool), model=model) 
                tools_calls.append({
                    "tool_name":tool['function'],
                    "tool_input":json.loads(tool['arguments'])
                }
                )
            content=tools_calls
        else:
            #output_tokens=count_tokens_from_text(input_txt=completion_text_chunk, model=model) 
            completion_text_chunk = "".join(chunk_text)
            content.append(completion_text_chunk)
    else:
        raw_response=json.loads(request_response)
        input_tokens=raw_response['usage']['prompt_tokens']
        output_tokens=raw_response['usage']['completion_tokens']
        choices=raw_response.get('choices','')
        for choice in choices:
            message=choice.get('message','')
            completion_text_chunk=message.get('content','')
            tool_calls_raw=message.get('tool_calls', [])
            if tools:
                for tool in tool_calls_raw:
                    tools_calls.append({
                        "tool_name": tool['function']['name'],
                        "tool_input": json.loads(tool['function']['arguments'])
                    })
                content=tools_calls
            else:
                content.append(completion_text_chunk)

    # Calculate Cost
    text_token_cost=calculate_token_cost(model, input_tokens, output_tokens)

    yield AIServiceResponse(
        result=content,
        action=action,
        action_params=action_params,
        additional_data = {
            "stop_event": False if stop_event is None else stop_event.is_set()
        },
        cost = {
            "total_cost": text_token_cost,
        },
        usage = {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
        },
        init_timestamp=init_timestamp,
        raw_response=raw_response
    )

async def stream_response_handler(
    response: Optional[List[str]] = None,
    stop_event: Optional[asyncio.Event] = None,
    *args, **kwargs
):
    
    chunk_text = kwargs.get('chunk_text')
    tool_calls_raw = kwargs.get('tool_calls_raw')
    logprobs_call = kwargs.get('logprobs_call')
    raw_response = kwargs.get('raw_response')

    async for line in response.content:
        decoded_line = line.decode().strip()

        raw_response['byte_line'].append(decoded_line)
        
        if decoded_line.endswith('[DONE]'):
            return

        elif decoded_line.startswith("data: "):
            try:
                json_data = json.loads(decoded_line[len("data: "):])
                choices = json_data.get("choices", None)

                if choices is None or not choices:
                    continue

                for choice in choices:
                    index=int(choice.get('index',0))
                    delta = choice.get("delta", {})
                    logprobs = choice.get("logprobs", [])
                    chunk = delta.get("content", "")
                    if "tool_calls" in delta:
                        tool_call_data = delta['tool_calls'][0]
                        function_info = tool_call_data.get("function", {})
                        function_name = function_info.get("name", "")
                        function_arguments_fragment = function_info.get("arguments", "")
                        if function_name and "function" not in tool_calls_raw:
                            tool_calls_raw[index]["function"] = function_name
                            tool_calls_raw[index]["arguments"] = ""
                        tool_calls_raw[index]["arguments"] += function_arguments_fragment
                    if logprobs:
                        if "content" in logprobs:
                            logprobs_call.append(logprobs['content'][0])
                    
                    if chunk is not None:
                        chunk_text.append(chunk)
                        yield chunk

            except Exception as e:
                print(f'Error parsing JSON: {e}')
                print(traceback.format_exc())
                
        if stop_event:        
            if stop_event.is_set():  # Check if the stop event 
                raise StopException("Stop event set.")
        
    return