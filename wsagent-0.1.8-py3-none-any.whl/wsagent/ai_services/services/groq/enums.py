from enum import Enum

class GroqAIEnums:

    @property
    def name(self):
        return "GroqAIEnums"

    class Feature:
        
        class LLM:
            
            class Model(Enum):
                                        
                """An enumeration of GroqAI models."""
                # Enum name            Model Name                   cost_per_input_token   cost_per_ouput_token
                # LLM Model
                LLAMA3_8B_8192_TOOL_PREVIEW     = ("llama3-groq-8b-8192-tool-use-preview",  0.05    / 1000000         , 0.1       / 1000000)
                LLAMA3_70B_8192_TOOL_PREVIEW    = ("llama3-groq-70b-8192-tool-use-preview", 0.59    / 1000000         , 0.79      / 1000000)
                LLAMA3_8B_8192                  = ("llama3-8b-8192",                        0.05    / 1000000         , 0.1       / 1000000)
                LLAMA3_70B_8192                 = ("llama3-70b-8192",                       0.59    / 1000000         , 0.79      / 1000000)
                LLAMA3_1_8B_INSTANT             = ("llama-3.1-8b-instant",                  0.05    / 1000000         , 0.1       / 1000000)
                LLAMA3_1_70B_VERSATILE          = ("llama-3.1-70b-versatile",               0.59    / 1000000         , 0.79      / 1000000)
                MIXTRAL_8X7_32768               = ("mixtral-8x7b-32768",                    0.27    / 1000000         , 0.27      / 1000000)
                GEMMA2_9B_IT                    = ("gemma2-9b-it",                          0.10    / 1000000         , 0.10      / 1000000)
                GEMMA_7B_IT                     = ("gemma-7b-it",                           0.10    / 1000000         , 0.10      / 1000000)
                
                @property
                def name(self):
                    return self.value[0]

                @property
                def cost_per_input_token(self):
                    return self.value[1]

                @property
                def cost_per_ouput_token(self):
                    return self.value[2]
        
    class Action:
        
        class Chat(Enum):
            CREATE = "CHAT_CREATE"
            
            @property
            def name(self):
                return self.value
            
    class Endpoints(Enum):
        BASE                = "https://api.groq.com/openai/v1"
        CHATCOMPLETION      = f"{BASE}/chat/completions"

        @property
        def url(self):
            return self.value