import asyncio
from datetime import datetime
from enum import Enum
# import json
import logging
# import time
# import traceback
# import aiohttp
from typing import Any, Callable, Coroutine, Dict, List, Optional
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.ai_services.schemas.chat.chat_response import ContentComponent, CostComponent, InputComponent, ParameterComponent, UsageComponent
from wsagent.ai_services.services.google_ai.headers import classic_googleai_headers
from wsagent.ai_services.services.google_ai.enums import GoogleAIEnums
from wsagent.utils.request import request_with_exponential_backoff
# from wsagent.ai_services.exceptions import StopException
# from wsagent.ai_services.services.openai.utils.content_item import content_item_image, content_item_text
# from wsagent.ai_services.services.openai.utils.cost import calculate_token_cost, calculate_vision_image_cost
# from wsagent.ai_services.services.openai.utils.count import count_image_tiles, count_tokens_from_image, count_tokens_from_messages, count_tokens_from_text
# from wsagent.ai_services.services.openai.headers import classic_openai_headers
# from wsagent.ai_services.services.openai.enums import OpenAIEnums
# from wsagent.ai_services.schemas.chat.chat_response import ContentComponent, CostComponent, ImageCostItem, InputComponent, ParameterComponent, TextContentItem, ToolCallsContentItem, UsageComponent
# from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
# from wsagent.utils.request import request_with_exponential_backoff

async def create_generate_content(log: Optional[logging.Logger] = None,
    api_key: Optional[str] = None,
    # Main Parameters
    model: Optional[str] = None,
    contents: Optional[list] = None,
    tools: Optional[list] = None,
    toolConfig: Optional[dict] = None,
    safetySettings: Optional[list] = None,
    systemInstruction: Optional[dict] = None,
    generationConfig: Optional[dict] = None,
    
    # messages: Optional[List] = None,
    # model: Optional[Enum] = None,
    # frequency_penalty: Optional[float] = None,     
    # logit_bias: Optional[dict] = None,
    # logprobs: Optional[bool] = None,
    # top_logprobs: Optional[int] = None,
    # max_tokens: Optional[int] = None,
    # n: Optional[int] = None,      
    # presence_penalty: Optional[float] = None,
    # response_format: Optional[str] = None,
    # seed: Optional[int] = None,
    # stop: Optional[List[str]] = None,
    stream: Optional[bool] = None,
    # temperature: Optional[float] = None,
    # top_p: Optional[float] = None,
    # tools : Optional[List] = None,
    # tool_choice : Optional[str] = None,  
    # user: Optional[str] = None,
    # functions: Optional[dict] = None,
    # Custom
    retries: Optional[int] = None,
    backoff_base: Optional[int] = None,
    # ## Custom Messages
    # user_message: Optional[str] = None, 
    # prefix_messages: Optional[List] = None, 
    # suffix_messages: Optional[List] = None,
    # # images
    # images: Optional[List[Any]] = None,
    # image_detail: Optional[str] = None,
    # ## Others
    # callback: Optional[Callable] = None,   
    # stop_event: Optional[asyncio.Event] = None 
):
    
    init_timestamp = datetime.now().timestamp()
    
    if api_key is None: raise ValueError("api_key cannot be None")     
    if model is None: model=GoogleAIEnums.Feature.LLM.Model.Vision.GEMINI_1_5_PRO_LASTEST
    # if messages is None:
    #     if user_message is None: raise ValueError("user_message is required")
    #     if prefix_messages is None: prefix_messages = []
    #     if suffix_messages is None: suffix_messages = []
    # if logprobs is None: logprobs = False
    # if top_logprobs is None and logprobs == True: top_logprobs = 2
    # if logprobs == True and (top_logprobs < 0 or top_logprobs > 5): raise ValueError("top_logprobs must be a integer between 0 and 5")
    # if temperature is None: temperature = 0.7 
    # if temperature < 0 or temperature > 2.0: raise ValueError("temperature must be a integer between 0 and 2")
    # if frequency_penalty is None: frequency_penalty = 0.0 
    # if frequency_penalty < -2.0 or frequency_penalty > 2.0: raise ValueError("frequency_penalty must be a integer between -2 and 2")
    # if presence_penalty is None: presence_penalty = 0
    # if presence_penalty < -2.0 or presence_penalty > 2.0: raise ValueError("presence_penalty must be a integer between -2 and 2")
    # if tools is None: tool_choice = None
    # if tool_choice is None: tool_choice = None
    # if top_p is None: top_p = 1.0
    # if stream is None: stream = False
    # if images is None: images = []
    # if image_detail is None: image_detail = "high"
    if retries is None: retries = 10  # Default retries
    if backoff_base is None: backoff_base = 2  # Default backoff base
    # if n is None: n = 1

    contents = [
        {
        "parts": [
            {
                "text": "hola, como estas?"
            }
        ],
        "role": "user"
        }
    ]


    # Header
    headers=classic_googleai_headers.copy()
    headers['Authorization'] = f'Bearer {api_key}'
    headers['Content-Type']= 'application/json'
    
    # Set data
    data={}
    data["contents"]=contents
    data["tools"]=tools
    data["toolConfig"]=toolConfig
    data["safetySettings"]=safetySettings
    data["systemInstruction"]=systemInstruction
    data["generationConfig"]=generationConfig
    
    # Set url
    url=f"{GoogleAIEnums.Endpoints.BASE.url}{GoogleAIEnums.Endpoints.V1_BETA.url}{model.name}:{GoogleAIEnums.Endpoints.GenerateContent.url}"
    
    # if max_tokens: data["max_tokens"]=max_tokens
    # if frequency_penalty: data["frequency_penalty"]=frequency_penalty
    # if logit_bias: data["logit_bias"]=logit_bias
    # if logprobs: data["logprobs"]=logprobs
    # if top_logprobs: data["top_logprobs"]=top_logprobs
    # if n: data["n"]=n
    # if presence_penalty: data["presence_penalty"]=presence_penalty
    # if response_format: data["response_format"]=response_format
    # if seed: data["seed"]=seed
    # if stop: data["stop"]=stop
    # if stream: data["stream"]=stream
    # if temperature: data["temperature"]=temperature
    # if top_p: data["top_p"]=top_p
    # if tools: data["tools"]=tools
    # if tool_choice: data["tool_choice"]=tool_choice
    # if user: data["user"]=user
    # if functions: data["functions"]=functions

    # # Prepare messages with easy way
    # if messages is None:
        
    #     # Prepare image data for the payload
    #     if images:
    #         content = []
    #         for image in images:
    #             content.append(content_item_image(image, image_detail))
    #         content.append(content_item_text(user_message))
    #         chat_user_message = [{"role": "user","content": content}]
            
    #     # Prepare the payload without the image request
    #     else:
    #         chat_user_message = [{"role": "user", "content": user_message}]

    #     # Make the payload
    #     messages = prefix_messages + chat_user_message + suffix_messages

    # # Data
    # data["messages"] = messages
    
    # Send request
    status=False
    error_msg=''


    
    # # Clear
    # tool_calls_raw=[{} for _ in range(n)]
    # logprobs_call=[]
    # status=False
    # error_msg=''
    # text_chunk=[]
    # stop_reason=''
    # tools_calls = []
    raw_response={}
    # content=[]
    # if stream: raw_response['byte_line']=[]
    # completion_text_chunk=''
    # output_tokens=0
    # input_tokens=0

    
    # Log messages
    log.info(f'Data parameters to llm server: {data}')
    #print(f'Data parameters to llm server: {data}')

    status, nostream_response = await request_with_exponential_backoff(
        stream=stream,
        # stop_event=stop_event,
        retries=retries,
        backoff_base=backoff_base,
        url=url, 
        headers=headers, 
        json=data, 
        log=log, 
        # stream_handler=stream_response_handler,
        # Extra arg for stream_handler
        # callback=callback,
        # text_chunk=text_chunk,
        # tool_calls_raw=tool_calls_raw,
        # logprobs_call=logprobs_call,
        raw_response=raw_response
    )
    
    if stream:
        pass
        # input_tokens=count_tokens_from_messages(messages=messages, model=model)
        # if tools:
        #     for tool in tool_calls_raw:
        #         output_tokens+=count_tokens_from_text(input_txt=json.dumps(tool), model=model) 
        #         tools_calls.append(ToolCallsContentItem(
        #             tool_name=tool['function'],
        #             tool_input=json.loads(tool['arguments'])
        #         ))
        #     content=tools_calls
        # else:
        #     output_tokens=count_tokens_from_text(input_txt=completion_text_chunk, model=model) 
        #     completion_text_chunk = "".join(text_chunk)
        #     content.append(TextContentItem(completion_text_chunk)) 
    else:
        raw_response=nostream_response
        # input_tokens=raw_response['usage']['prompt_tokens']
        # output_tokens=raw_response['usage']['completion_tokens']
        # choices=raw_response.get('choices','')
        # for choice in choices:
        #     message=choice.get('message','')
        #     completion_text_chunk=message.get('content','')
        #     tool_calls_raw=message.get('tool_calls', [])
        #     if tools:
        #         for tool in tool_calls_raw:
        #             tools_calls.append(ToolCallsContentItem(
        #                 tool_name=tool['function']['name'],
        #                 tool_input=json.loads(tool['function']['arguments'])
        #             ))
        #         content=tools_calls
        #     else:
        #         content.append(TextContentItem(completion_text_chunk))  
        #     if logprobs: logprobs_call =choice.get('logprobs', []).get('content', [])         

    # # Calculate Cost
    # text_token_cost=calculate_token_cost(model, input_tokens, output_tokens)

    image_cost_items = []
    image_token_cost=0
    image_source=''
    # #get all images from messages
    # for message in messages:
    #     for content_item in message['content']:
    #         if type(content_item) is dict:
    #             if content_item.get('type') == 'image_url':
    #                 images.append(content_item['image_url']['url'].replace("data:image/jpeg;base64,",""))

    # if images:
    #     for image in images:
            
    #         if image.startswith(('http')):
    #             source_type='url'
    #             image_source=image
    #         elif any(image.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.webp']):
    #             source_type='local_path'
    #             image_source=image
    #         else:
    #             source_type='local_base64'
    #             image_source=''
    #         tiles = count_image_tiles(image)
    #         cost = calculate_vision_image_cost(vision_model=model, image_detail=image_detail,input_tiles=tiles)
    #         image_cost_items.append(
    #             ImageCostItem(
    #                 source_type=source_type,
    #                 image_source=image_source,
    #                 image_detail=image_detail,
    #                 cost=cost
    #             )
    #         )
    #         image_token_cost+=cost

    # Generate a output
    endpoint_response = AIServiceResponse(
        input=InputComponent(
            contents
        ),
        parameters=ParameterComponent(
            model=model.name
        ),
        content=ContentComponent(raw_response),
        usage= UsageComponent(
            # input_tokens=input_tokens,
            # output_tokens=output_tokens,
            # total_tokens=input_tokens+output_tokens
        ),
        cost =  CostComponent(
            # total_cost = text_token_cost + image_token_cost,
            # text_token_cost = text_token_cost,
            # image_token_cost = image_token_cost,
            # image_details = image_cost_items
        ),
        init_timestamp=init_timestamp,
        error_msg=error_msg,
        status=status,
        raw_response=raw_response
    )

    log.info(f'endpoint_response: {endpoint_response.to_json()}')
    return endpoint_response

# async def stream_response_handler(
#     response: Optional[List[str]] = None,
#     stop_event: Optional[asyncio.Event] = None,
#     *args, **kwargs
# ):
    
#     callback = kwargs.get('callback')
#     text_chunk = kwargs.get('text_chunk')
#     tool_calls_raw = kwargs.get('tool_calls_raw')
#     logprobs_call = kwargs.get('logprobs_call')
#     raw_response = kwargs.get('raw_response')

#     async for line in response.content:
#         decoded_line = line.decode().strip()

#         raw_response['byte_line'].append(decoded_line)
        
#         if decoded_line.endswith('[DONE]'):
#             if callback:
#                 chunk = None
#                 data_type = 'end'
#                 if asyncio.iscoroutinefunction(callback):
#                     await callback(chunk, data_type)
#                 else:
#                     callback(chunk, data_type)
#             return True

#         elif decoded_line.startswith("data: "):
#             try:
#                 json_data = json.loads(decoded_line[len("data: "):])
#                 choices = json_data.get("choices", None)

#                 if choices is None or not choices:
#                     return True

#                 for choice in choices:
#                     index=int(choice.get('index',0))
#                     delta = choice.get("delta", {})
#                     logprobs = choice.get("logprobs", [])
#                     chunk = delta.get("content", "")
#                     if "tool_calls" in delta:
#                         tool_call_data = delta['tool_calls'][0]
#                         function_info = tool_call_data.get("function", {})
#                         function_name = function_info.get("name", "")
#                         function_arguments_fragment = function_info.get("arguments", "")
#                         if function_name and "function" not in tool_calls_raw:
#                             tool_calls_raw[index]["function"] = function_name
#                             tool_calls_raw[index]["arguments"] = ""
#                         tool_calls_raw[index]["arguments"] += function_arguments_fragment
#                     if logprobs:
#                         if "content" in logprobs:
#                             logprobs_call.append(logprobs['content'][0])
                    
#                     if chunk is not None:
#                         text_chunk.append(chunk)

#                     if callback:
#                         data_type = 'data'
#                         if asyncio.iscoroutinefunction(callback):
#                             await callback(chunk, data_type)
#                         else:
#                             callback(chunk, data_type)

#             except Exception as e:
#                 print(f'Error parsing JSON: {e}')
#                 print(traceback.format_exc())
                
#         if stop_event:        
#             if stop_event.is_set():  # Check if the stop event 
#                 raise StopException("Stop event set.")
        
#     return True