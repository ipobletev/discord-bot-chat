from enum import Enum

class GoogleAIEnums:

    @property
    def name(self):
        return "GoogleAIEnums"

    class Feature:
        
        class LLM:
            
            class Model:
                    
                class Text(Enum):
                    
                    """An enumeration of OpenAI models."""
                    # Enum name            Model Name                   cost_per_input_token   cost_per_ouput_token
                    # LLM Model
                    GEMINI_1_0_PRO_LASTEST  = ("gemini-1.0-pro-latest",  0.03    / 1000         , 0.06      / 1000)
                    GEMINI_1_0_PRO          = ("gemini-1.0-pro",         0.01    / 1000         , 0.03      / 1000)
                    GEMINI_1_0_PRO_001      = ("gemini-1.0-pro-001",     0.01    / 1000         , 0.03      / 1000)  
                    
                    @property
                    def name(self):
                        return self.value[0]

                    @property
                    def cost_per_input_token(self):
                        return self.value[1]

                    @property
                    def cost_per_ouput_token(self):
                        return self.value[2]

                class Vision(Enum):
                    # Enum name            Model Name               cost_per_input_token  cost_per_ouput_token  base_img_token
                    # LLM Model
                    GEMINI_1_5_PRO_LASTEST = ("gemini-1.5-pro-latest"   , 0.01 / 1000 , 0.03 / 1000      , 85)
                    GEMINI_PRO_VISION      = ("gemini-pro-vision"       , 0.01 / 1000 , 0.03 / 1000      , 85)

                    @property
                    def name(self):
                        return self.value[0]

                    @property
                    def cost_per_input_token(self):
                        return self.value[1]

                    @property
                    def cost_per_ouput_token(self):
                        return self.value[2]
                    
                    @property
                    def base_img_token(self):
                        return self.value[3]
            
        class Embeddings:

            class Model(Enum):
                
                # Embeddings Model
                TEXT_EMBEDDING_004  = ("text-embedding-004",        0.00000  / 1000         , 0.0  , 1536)
                EMBEDDING_001       = ("embedding-001",             0.00000  / 1000         , 0.0  , 1536)

                @property
                def name(self):
                    return self.value[0]

                @property
                def cost_per_input_token(self):
                    return self.value[1]

                @property
                def dimensions(self):
                    return self.value[3]
        
    class Action:
        
        class Chat(Enum):
            CREATE = "CHAT_CREATE"
            
            @property
            def name(self):
                return self.value
            
        class Embeddings(Enum):
            CREATE = "EMBEDDING_CREATE"
            
            @property
            def name(self):
                return self.value

    class Endpoints(Enum):
        BASE                = "https://api.openai.com/v1/https://generativelanguage.googleapis.com/"
        V1_BETA             = "v1beta/models/"
        V1                  = "v1/models/"
        GenerateContent     = "generateContent"
        
        @property
        def url(self):
            return self.value