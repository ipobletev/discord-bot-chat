#https://ai.google.dev/api/rest/v1beta/Content

class Content:
    def __init__(self, parts: list, role: str = None):
        self.parts = parts
        self.role = role

    def to_dict(self):
        return {
            "parts": [part.to_dict() for part in self.parts],
            "role": self.role
        }

class Blob:
    def __init__(self, 
        mime_type: str, 
        data: str
    ):
        self.mime_type = mime_type
        self.data = data

    def to_dict(self):
        return {
            "mimeType": self.mime_type,
            "data": self.data
        }

class FunctionCall:
    def __init__(self, 
        name: str, 
        args: dict
    ):
        self.name = name
        self.args = args

    def to_dict(self):
        return {
            "name": self.name,
            "args": self.args
        }

class FunctionResponse:
    def __init__(self, 
        name: str, 
        response: dict
    ):
        self.name = name
        self.response = response

    def to_dict(self):
        return {
            "name": self.name,
            "response": self.response
        }

class FileData:
    def __init__(self, 
        mime_type: str, 
        file_uri: str
    ):
        self.mime_type = mime_type
        self.file_uri = file_uri

    def to_dict(self):
        return {
            "mimeType": self.mime_type,
            "fileUri": self.file_uri
        }

class Part:
    def __init__(self, 
        text: str = None, 
        inline_data: Blob = None, 
        function_call: FunctionCall = None, 
        function_response: FunctionResponse = None, 
        file_data: FileData = None
    ):
        self.text = text
        self.inline_data = inline_data
        self.function_call = function_call
        self.function_response = function_response
        self.file_data = file_data

    def to_dict(self):
        data = {}
        if self.text is not None:
            data["text"] = self.text
        if self.inline_data is not None:
            data["inlineData"] = self.inline_data.to_dict()
        if self.function_call is not None:
            data["functionCall"] = self.function_call.to_dict()
        if self.function_response is not None:
            data["functionResponse"] = self.function_response.to_dict()
        if self.file_data is not None:
            data["fileData"] = self.file_data.to_dict()
        return data