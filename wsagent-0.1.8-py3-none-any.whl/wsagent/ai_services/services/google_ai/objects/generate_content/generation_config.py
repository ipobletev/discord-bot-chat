# https://ai.google.dev/api/rest/v1beta/GenerationConfig

from enum import Enum
from typing import List, Optional, Dict, Any

class Schema:
    class Type(Enum):
        TYPE_UNSPECIFIED = "TYPE_UNSPECIFIED"
        STRING = "STRING"
        NUMBER = "NUMBER"
        INTEGER = "INTEGER"
        BOOLEAN = "BOOLEAN"
        ARRAY = "ARRAY"
        OBJECT = "OBJECT"

    def __init__(self, 
        type: 'Schema.Type', 
        format: Optional[str] = None, 
        description: Optional[str] = None, 
        nullable: Optional[bool] = None, 
        enum: Optional[List[str]] = None, 
        properties: Optional[Dict[str, 'Schema']] = None, 
        required: Optional[List[str]] = None, 
        items: Optional['Schema'] = None
    ):
        self.type = type
        self.format = format
        self.description = description
        self.nullable = nullable
        self.enum = enum
        self.properties = properties
        self.required = required
        self.items = items

    def to_dict(self):
        return {
            "type": self.type.value,
            "format": self.format,
            "description": self.description,
            "nullable": self.nullable,
            "enum": self.enum,
            "properties": {k: v.to_dict() for k, v in self.properties.items()} if self.properties else None,
            "required": self.required,
            "items": self.items.to_dict() if self.items else None
        }

class GenerationConfig:
    def __init__(self, 
        stop_sequences: Optional[List[str]] = None,
        response_mime_type: Optional[str] = None,
        response_schema: Optional[Schema] = None,
        candidate_count: Optional[int] = 1,
        max_output_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None
    ):
        self.stop_sequences = stop_sequences
        self.response_mime_type = response_mime_type
        self.response_schema = response_schema
        self.candidate_count = candidate_count
        self.max_output_tokens = max_output_tokens
        self.temperature = temperature
        self.top_p = top_p
        self.top_k = top_k

    def to_dict(self):
        return {
            "stopSequences": self.stop_sequences if self.stop_sequences else [],
            "responseMimeType": self.response_mime_type,
            "responseSchema": self.response_schema.to_dict() if self.response_schema else None,
            "candidateCount": self.candidate_count,
            "maxOutputTokens": self.max_output_tokens,
            "temperature": self.temperature,
            "topP": self.top_p,
            "topK": self.top_k
        }
