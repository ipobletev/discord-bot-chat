#https://ai.google.dev/api/rest/v1beta/ToolConfig

from enum import Enum
from typing import List, Optional

class ToolConfig:
    def __init__(self, function_calling_config: Optional['FunctionCallingConfig'] = None):
        self.function_calling_config = function_calling_config

    def to_dict(self):
        return {
            "functionCallingConfig": self.function_calling_config.to_dict() if self.function_calling_config else None
        }

class FunctionCallingConfig:
    class Mode(Enum):
        MODE_UNSPECIFIED = "MODE_UNSPECIFIED"
        AUTO = "AUTO"
        ANY = "ANY"
        NONE = "NONE"

    def __init__(self, mode: 'FunctionCallingConfig.Mode' = Mode.AUTO, allowed_function_names: Optional[List[str]] = None):
        self.mode = mode
        self.allowed_function_names = allowed_function_names

    def to_dict(self):
        return {
            "mode": self.mode.value,
            "allowedFunctionNames": self.allowed_function_names if self.allowed_function_names else []
        }
