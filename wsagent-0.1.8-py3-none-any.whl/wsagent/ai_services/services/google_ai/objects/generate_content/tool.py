#https://ai.google.dev/api/rest/v1beta/Tool

class Tool:
    def __init__(self, function_declarations: list):
        self.function_declarations = function_declarations

    def to_dict(self):
        return {
            "functionDeclarations": [fd.to_dict() for fd in self.function_declarations]
        }
        
class FunctionDeclaration:
    def __init__(self, name: str, description: str, parameters: dict):
        self.name = name
        self.description = description
        self.parameters = parameters

    def to_dict(self):
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters
        }