from wsagent.ai_services.services.google_ai.endpoints.chat.chat import create_generate_content
from wsagent.ai_services.services.google_ai.enums import GoogleAIEnums

googleai_function_map = {
    ### CHAT ###
    GoogleAIEnums.Action.Chat.CREATE: create_generate_content,
}