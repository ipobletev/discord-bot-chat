import os
from dotenv import load_dotenv
load_dotenv()

# OpenAI Keys
GOOGLEAI_DEFAULT_MODEL=os.getenv("GOOGLEAI_DEFAULT_MODEL",'gemini-1.5-pro-latest')
GOOGLEAI_API_KEY=os.getenv("GOOGLEAI_API_KEY",'')