
from wsagent.ai_services.services.google_ai.config import GOOGLEAI_API_KEY

classic_googleai_headers = {
    'x-goog-api-key': f'{GOOGLEAI_API_KEY}'
}
