import asyncio
from datetime import datetime
from enum import Enum
import json
import logging
import traceback
from typing import Any, Callable, Dict, List, Optional, Union
from wsagent.ai_services.exceptions import StopException
from wsagent.ai_services.services.anthropic.utils.content_item import content_item_image, content_item_text
from wsagent.ai_services.services.anthropic.utils.cost import calculate_token_cost, calculate_vision_image_cost
from wsagent.ai_services.services.anthropic.utils.cost import calculate_vision_image_cost
from wsagent.ai_services.services.anthropic.utils.count import count_tokens_from_image
from wsagent.ai_services.services.anthropic.headers import anthropic_header
from wsagent.ai_services.services.anthropic.enums import AnthropicAIEnums
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.request import request_with_exponential_backoff

async def create_chat_completion(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AIServiceResponse:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    messages = action_params.get('messages', None)
    model = action_params.get('model', None)
    max_tokens = action_params.get('max_tokens', None)
    metadata = action_params.get('metadata', None)
    stop_sequences = action_params.get('stop_sequences', None)
    stream = action_params.get('stream', None)
    system = action_params.get('system', None)
    temperature = action_params.get('temperature', None)
    tools = action_params.get('tools', None)
    top_k = action_params.get('top_k', None)
    top_p = action_params.get('top_p', None)
    retries = action_params.get('retries', None)
    backoff_base = action_params.get('backoff_base', None)
    user_message = action_params.get('user_message', None)
    prefix_messages = action_params.get('prefix_messages', None)
    suffix_messages = action_params.get('suffix_messages', None)
    images = action_params.get('images', None)
    stop_event = action_params.get('stop_event', None)
    ## ai_service_params
    api_key = ai_service_params.get('anthropic_api_key', None)
    
    # Check if all required parameters are provided
    if api_key is None: raise ValueError("api_key cannot be None")
    
    # Optional parameters with default values
    if model is None: model=AnthropicAIEnums.Feature.LLM.Model.CLAUDE_3_OPUS
    if retries is None: retries=5  # Default retries
    if backoff_base is None: backoff_base=2  # Default backoff base
    if max_tokens is None: max_tokens=1000  # Default max tokens

    str_model = None
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")

    # Prepare messages with easy way
    if messages is None:
        
        # Prepare image data for the payload
        if images:
            content = []
            for image in images:
                content.append(content_item_image(image))
            content.append(content_item_text(user_message))
            chat_user_message = [{"role": "user","content": content}]
            
        # Prepare the payload without the image request
        else:
            chat_user_message = [{"role": "user", "content": user_message}]

        # Make the payload
        messages = prefix_messages + chat_user_message + suffix_messages

    # compatibilize with openai system format
    ## System is a string
    if messages and system is None: 
        for message in messages:
            if message.get('role'):
                if message['role'] == 'system':
                    system = message['content']
                    break
            
    ## remove system if exist in messages
    for message in messages:
        if message.get('role'):
            if message['role'] == 'system':
                messages.remove(message)            
    
    ## Merge user and assitant messages, if we have multiples same roles
    merged_messages = []
    last_role = None

    ## convert all messages to list content format
    for i, message in enumerate(messages):
        # We have a no list content, convert to list content
        if isinstance(message.get('content'), str):
            messages[i] = {"role": message.get('role'), "content": [{"type": "text","text": message.get('content')}]}
            
        # We have a image list content in openai format, convert to list content anthropic format
        elif isinstance(message.get('content'), list):
            content = []
            for content_item in message.get('content'):
                
                if content_item.get('type') == 'image_url':
                    image=content_item['image_url']['url']
                    content.append(content_item_image(image))
                
                elif content_item.get('type') == 'text':
                    text=content_item['text']
                    content.append({"type": 'text', "text": text})

            messages[i] = {"role": message.get('role'), "content": content}
    
    ## merge multiples messages with the same role
    for message in messages:
        if message.get('role') == last_role:
            merged_messages[-1]['content'].extend(message['content'])
        else:
            # Add new message if the role is different
            merged_messages.append(message)
            last_role = message.get('role')
            
    # Set data
    data={}
    data["model"]=str_model
    if max_tokens: data["max_tokens"]=max_tokens    
    if metadata: data["metadata"]=metadata
    if stop_sequences: data["stop_sequences"]=stop_sequences
    if stream: data["stream"]=stream
    if system: data["system"]=system
    if temperature: data["temperature"]=temperature
    if tools: data["tools"]=tools
    if top_k: data["top_k"]=top_k
    if top_p: data["top_p"]=top_p
    # Prepare messages
    data["messages"] = merged_messages
    
    # Header
    headers=anthropic_header.copy()
    headers['Content-Type']= 'application/json'
    
    # Set url
    url=AnthropicAIEnums.Endpoints.CREATE_MESSAGE.url
    
    # Clear
    content=[]
    text_chunk=[]
    stop_reason=''
    tools_calls = []
    raw_response={}
    if stream: raw_response['byte_line']=[]
    completion_text_chunk=''
    param = {'input_tokens': 0, 'output_tokens': 0, 'stop_reason': None}
    
    # Log messages
    log.info(f'Data parameters to llm server: {data}')
    
    try:
        async for request_response in request_with_exponential_backoff(
            stream=stream,
            stop_event=stop_event,
            retries=retries,
            url=url, 
            headers=headers, 
            json=data, 
            log=log, 
            stream_handler=stream_response_handler,
            # Extra arg for stream_handler
            text_chunk=text_chunk,
            raw_response=raw_response,
            param=param,
        ):
            if stream: yield request_response
    except StopException:
        pass
     
    if stream:
        completion_text_chunk = "".join(text_chunk)    
        input_tokens=param['input_tokens']
        output_tokens=param['output_tokens']
        if completion_text_chunk:
            content.append(completion_text_chunk) 
    # For non-streaming, process as a single block
    else:   
        raw_response = json.loads(request_response)
        # Ensure 'content' key exists and is not empty
        if "content" in raw_response and raw_response["content"]:
            # Ensure 'text' key exists in the first item of 'content'
            if "text" in raw_response["content"][0]:
                completion_text_chunk = raw_response["content"][0]["text"]
            else:
                raise KeyError("'text' key not found in the first item of 'content'")
        else:
            raise KeyError("'content' key not found or is empty in raw_response")
        
        input_tokens = raw_response["usage"]['input_tokens']
        output_tokens = raw_response["usage"]['output_tokens']
        stop_reason = raw_response['stop_reason']
        
        # Get tools parameters
        if "content" in raw_response and tools:
            for tool in raw_response["content"]:
                if tool.get('type') == 'tool_use':
                    tools_calls.append({
                        "tool_name": tool['name'],
                        "tool_input": f"{tool['input']}"
                    })
                    content=tools_calls
        
        # No tool setted
        else:
            if completion_text_chunk:
                content.append(completion_text_chunk) 
    
    # Calculate Cost
    text_token_cost=calculate_token_cost(model, tools, input_tokens, output_tokens)
    image_cost_items = []
    image_token_cost=0
    image_source=''
    images=[]
    #get all images from messages
    for message in messages:
        for content_item in message['content']:
            if type(content_item) is dict:
                if content_item.get('type') == 'image':
                    images.append(content_item['source']['data'])
    if images:
        for image in images:
            
            if image.startswith(('http')):
                source_type='url'
                image_source=image
            elif any(image.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.webp']):
                source_type='local_path'
                image_source=image
            else:
                source_type='local_base64'
                image_source=''
            
            tokens = count_tokens_from_image(vision_model=model,image=image)
            cost = calculate_vision_image_cost(vision_model=model, tokens=tokens)
            image_cost_items.append({
                "source_type": source_type,
                "image_source": image_source,
                "image_detail": '',
                "cost": cost
            })
            image_token_cost+=cost

    # Generate a output
    yield AIServiceResponse(
        result=content,
        action=action,
        action_params=action_params,
        additional_data = {
            "stop_event": False if stop_event is None else stop_event.is_set(),
            "stop_reason" : stop_reason
        },
        cost={
            "total_cost": text_token_cost + image_token_cost,
            "text_token_cost": text_token_cost,
            "image_token_cost": image_token_cost,
            "image_details": image_cost_items
        },
        usage={
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens
        },
        init_timestamp=init_timestamp,
        raw_response=raw_response
    )

async def stream_response_handler(
    response: Optional[List[str]] = None,
    stop_event: Optional[asyncio.Event] = None,
    *args, **kwargs
):
    
    text_chunk = kwargs.get('text_chunk')
    raw_response = kwargs.get('raw_response')
    param=kwargs.get('param')
    
    async for line in response.content:
        decoded_line = line.decode().strip()

        raw_response['byte_line'].append(decoded_line)

        if decoded_line.startswith("event:"):
            continue
        if decoded_line == "":
            continue
        if decoded_line.startswith("data:"):
            try:
                json_data = json.loads(decoded_line[len("data: "):])

                content_type = json_data.get("type")
                if content_type.startswith("message_stop"):
                    text_chunk = None
                    return
                if content_type.startswith("message_start"):
                    message = json_data.get("message", None)
                    usage=message.get("usage", None)
                    param['input_tokens']=usage.get("input_tokens", 0)
                    
                if content_type.startswith("message_delta"):
                    usage=json_data.get("usage", None)
                    delta = json_data.get("delta", {})
                    param['output_tokens']=usage.get("output_tokens", 0)
                    param['stop_reason']=delta.get("stop_reason", None)
                    
                if content_type.startswith("content_block_delta"):
                    delta = json_data.get("delta", {})
                    content_type = delta.get("type")

                    if content_type == "text_delta":
                        # Accumulate the text chunk into the text list
                        chunk_text = delta.get("text", "")
                        text_chunk.append(chunk_text)
                        yield chunk_text

            except Exception as e:
                print(f"Processing error: {traceback.format_exc()}")
        
        if stop_event:        
            if stop_event.is_set():  # Check if the stop event 
                raise StopException("Stop event set.")
        
    return