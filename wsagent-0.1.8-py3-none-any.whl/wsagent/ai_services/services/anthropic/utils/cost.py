from enum import Enum
from typing import List, Optional, Union
from wsagent.ai_services.services.anthropic.enums import AnthropicAIEnums
from wsagent.ai_services.ai_services_enum import AIServices

CLAUDE_3_OPUS_TOOL_BASE_TOOL_COST = 395
CLAUDE_3_SONNET_TOOL_BASE_TOOL_COST = 159
CLAUDE_3_HAIKU_TOOL_BASE_TOOL_COST = 264

def calculate_token_cost(
    model: Optional[Union[Enum,str]]= None, 
    tools: Optional[List]= None,
    input_tokens: Optional[int] = None,
    output_tokens: Optional[int] = None,
) -> float:
    
    if model is None: raise Exception("model is required")
    if input_tokens is None: raise Exception("input_tokens tokens is required")
    if output_tokens is None: raise Exception("output_tokens tokens is required")
    
    if isinstance(model, str):
        str_model = model
    elif isinstance(model, Enum):
        str_model = model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    enum_model = AIServices.get_enum_model_from_model_name(str_model)
    
    base_token_tool_cost=0
    if tools:
        if model == AnthropicAIEnums.Feature.LLM.Model.CLAUDE_3_OPUS:
            base_token_tool_cost = CLAUDE_3_OPUS_TOOL_BASE_TOOL_COST 
        elif model == AnthropicAIEnums.Feature.LLM.Model.CLAUDE_3_SONNET:
            base_token_tool_cost = CLAUDE_3_SONNET_TOOL_BASE_TOOL_COST
        elif model == AnthropicAIEnums.Feature.LLM.Model.CLAUDE_3_HAIKU:
            base_token_tool_cost = CLAUDE_3_HAIKU_TOOL_BASE_TOOL_COST

    cost_per_prompt_token = enum_model.cost_per_input_token
    cost_per_completion_token = enum_model.cost_per_ouput_token
    
    return base_token_tool_cost + (cost_per_prompt_token * float(input_tokens)) + (cost_per_completion_token * float(output_tokens))

def calculate_vision_image_cost(
    vision_model: Optional[AnthropicAIEnums.Feature.LLM.Model]= None,
    tokens: Optional[int]= None
) -> float:
    
    if tokens is None: raise Exception("tokens is required")

    if isinstance(vision_model, str):
        str_model = vision_model
    elif isinstance(vision_model, Enum):
        str_model = vision_model.name
    else:
        raise ValueError("action must be a string or Enum.")
    
    enum_model = AIServices.get_enum_model_from_model_name(str_model)
    
    base_cost_per_token = enum_model.cost_per_input_token
    
    image_cost= tokens * base_cost_per_token
    
    return image_cost