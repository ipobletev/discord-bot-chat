from typing import Optional
from wsagent.utils.image import b64encode_image_from_path, b64encode_image_from_url
import re

def content_item_image(
    image: Optional[str] = None,
    media_type: Optional[str] = None
) -> dict:
    if image.startswith(('http')):
        img_b64 = b64encode_image_from_url(image)
        if media_type is None: media_type="image/jpeg"
    elif any(image.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.webp']):
        img_b64 = b64encode_image_from_path(image)
        if media_type is None: media_type = f"image/{image.split('.')[-1]}"
    else:
        img_b64=image
        if media_type is None: 
            match  = re.match(r'data:(image/\w+);base64,(.*)', img_b64)
            if match:
                media_type = match.group(1)
                img_b64 = match.group(2)
            else:
                raise ValueError("Invalid data URL")
            
    image_json={
        "type": "image",
        "source": {
            "type": "base64",
            "media_type": media_type,
            "data": img_b64,
        }
    }
    return image_json

def content_item_text(
    text: Optional[str] = None
) -> dict:
    return {
        "type": "text", 
        "text": text
    }