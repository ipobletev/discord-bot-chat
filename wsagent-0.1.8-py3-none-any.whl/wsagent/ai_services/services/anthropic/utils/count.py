import math
from typing import Optional
from enum import Enum
from PIL import Image
import requests
from io import BytesIO
import base64
import requests
from wsagent.ai_services.services.anthropic.config import ANTHROPIC_IMAGE_MAX_DIMENSION, ANTHROPIC_IMAGE_MAX_TOKENS
from wsagent.ai_services.services.anthropic.enums import AnthropicAIEnums

# def count_tokens_from_text(
#     input_txt: Optional[str]= None,
#     model: Optional[Union[Enum,str]]= None
# ):
    
#     if model is None: model=OpenAIEnums.Feature.LLM.Model.GPT_3_5_TURBO_1106
#     if input_txt is None: raise Exception("Input text is required")
    
#     # Get the model name in str from different types of enums but same string model name
#     if isinstance(model, str):
#         str_model = model
#     elif isinstance(model, Enum):
#         str_model = model.name
#     else:
#         raise ValueError("action must be a string or Enum.")

#     # Get the oficial enum model from the model name
#     enum_model = AIServices.get_enum_model_from_model_name(str_model)
    
#     # Patch for Omni models, this not implement in ticktoken yet
#     if enum_model == OpenAIEnums.Feature.LLM.Model.GPT_4_O or enum_model == OpenAIEnums.Feature.LLM.Model.GPT_4_O_2024_05_13:
#         model = OpenAIEnums.Feature.LLM.Model.GPT_4_TURBO.name
#     if enum_model == OpenAIEnums.Feature.LLM.Model.GPT_4_O.name or enum_model == OpenAIEnums.Feature.LLM.Model.GPT_4_O_2024_05_13.name:
#         model = OpenAIEnums.Feature.LLM.Model.GPT_4_TURBO.name
    
#     # Get the name of the model to use
#     str_model=model.name
    
#     # Get the tokens from encoding model
#     enc = tiktoken.encoding_for_model(str_model)
#     return len(enc.encode(input_txt, disallowed_special=()))

def count_tokens_from_image(
    vision_model: Optional[AnthropicAIEnums.Feature.LLM.Model]= None,
    image: Optional[str] = None, # base64_image or image_url or image_path
) -> float:
    
    def dimensions_to_max_token_param(img: Image, max_tokens: int, max_dimension: [int, int]):
        # Calculate the maximum number of pixels allowed based on the maximum number of tokens
        max_pixels = max_tokens * 750

        # Also consider maximum dimensions
        max_width, max_height = max_dimension

        # Calculate scale factors independently for width and height based on different constraints
        scale_factor_by_tokens = math.sqrt(max_pixels / (img.width * img.height)) if img.width * img.height > max_pixels else 1
        scale_factor_by_width = max_width / img.width if img.width > max_width else 1
        scale_factor_by_height = max_height / img.height if img.height > max_height else 1

        # Choose the smallest scale factor to ensure both constraints are respected
        scale_factor = min(scale_factor_by_tokens, scale_factor_by_width, scale_factor_by_height)

        new_width = int(img.width * scale_factor)
        new_height = int(img.height * scale_factor)

        return [new_width, new_height]
        
    if vision_model is None: vision_model=AnthropicAIEnums.Feature.LLM.Model.Vision.CLAUDE_3_OPUS
    if image is None: raise Exception("You must provide an image path or url")
    
    if image is None: 
        raise Exception("You must provide an image as a base64 string, URL, or local path")

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0'
    }

    # Determine if the image is a URL, base64 string, or a file path
    try:
        if image.startswith(('http')):
            # Image is a URL
            response = requests.get(url=image,headers=headers)
            response.raise_for_status()
            image_bytes = BytesIO(response.content)
        elif any(image.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.webp']):
            # Image is a local file path
            with open(image, "rb") as image_file:
                image_bytes = BytesIO(image_file.read())
        else:
            # Assuming it's a base64 encoded image
            image_bytes = BytesIO(base64.b64decode(image))
    except Exception as e:
        raise ValueError(f"Error handling the provided image input: {str(e)}")

    with Image.open(image_bytes) as img:
        #raw_width_px, raw_height_px = img.size
        width_px, height_px = dimensions_to_max_token_param(img=img, max_tokens=ANTHROPIC_IMAGE_MAX_TOKENS, max_dimension=ANTHROPIC_IMAGE_MAX_DIMENSION)

    # Calculate tokens
    tokens = int(math.ceil((width_px * height_px) / 750))
        
    return tokens