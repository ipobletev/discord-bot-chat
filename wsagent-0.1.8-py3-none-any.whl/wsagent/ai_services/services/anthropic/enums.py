from enum import Enum

class AnthropicAIEnums:

    @property
    def name(self):
        return "AnthropicAIEnums"

    class Feature:
        
        class LLM:
            
            class Model(Enum):
                
                # Text Model
                ##################################
                # Enum name               Model Name                    cost_per_input_token        cost_per_ouput_token
                # LLM Model
                CLAUDE_2_1              = ("claude-2.1"                 , 8       / 1000000         , 24      / 1000000)
                CLAUDE_2_0              = ("claude-2.0"                 , 8       / 1000000         , 24      / 1000000)
                CLAUDE_INSTANT_1_2      = ("claude-instant-1.2"         , 0.8     / 1000000         , 2.4     / 1000000)

                # Vision Model
                ##################################
                # Enum name             Model Name                      cost_per_input_token        cost_per_ouput_token  tokens_use_per_tool
                # LLM Model
                CLAUDE_3_OPUS           = ("claude-3-opus-20240229"     , 15      / 1000000         , 75      / 1000000 , 395)
                CLAUDE_3_SONNET         = ("claude-3-sonnet-20240229"   , 3       / 1000000         , 15      / 1000000 , 159)
                CLAUDE_3_HAIKU          = ("claude-3-haiku-20240307"    , 0.25    / 1000000         , 1.25    / 1000000 , 264)
                CLAUDE_3_5_SONNET       = ("claude-3-5-sonnet-20240620" , 3       / 1000000         , 15      / 1000000 , 159)
                
                @property
                def name(self):
                    return self.value[0]

                @property
                def cost_per_input_token(self):
                    return self.value[1]

                @property
                def cost_per_ouput_token(self):
                    return self.value[2]
                
                @property
                def tokens_use_per_tool(self):
                    return self.value[3]
                    
    class Action:
        
        class Chat(Enum):
            CREATE = "CHAT_CREATE"
            
            @property
            def name(self):
                return self.value

    class Endpoints(Enum):
        BASE                    = "https://api.anthropic.com/v1"
        CREATE_MESSAGE          = f"{BASE}/messages"
        
        @property
        def url(self):
            return self.value