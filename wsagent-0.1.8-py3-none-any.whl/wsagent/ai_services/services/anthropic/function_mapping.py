from wsagent.ai_services.services.anthropic.enums import AnthropicAIEnums
from wsagent.ai_services.services.anthropic.endpoints.create_messages.create_messages import create_chat_completion

anthropic_function_map = {
    ### CHAT ###
    AnthropicAIEnums.Action.Chat.CREATE.value: create_chat_completion,
}