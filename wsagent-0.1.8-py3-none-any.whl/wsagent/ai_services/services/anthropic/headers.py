
from wsagent.ai_services.services.anthropic.config import ANTHROPIC_API_KEY

anthropic_header = {
    'anthropic-version': '2023-06-01',
    'x-api-key': f'{ANTHROPIC_API_KEY}',
    'anthropic-beta': 'tools-2024-04-04'
}
