import os
from dotenv import load_dotenv
load_dotenv()

# Azure OpenAI Keys
AZUREAI_DEFAULT_MODEL=os.getenv("AZUREAI_DEFAULT_MODEL",'gpt-4o')
AZUREAI_API_KEY=os.getenv("AZURE_AI_API_KEY",'')
AZUREAI_BASE_URL=os.getenv("AZURE_AI_BASE_URL",'')
AZUREAI_API_VERSION=os.getenv("AZURE_AI_API_VERSION",'')
AZUREAI_API_VERSION_W_FUNCTIONS=os.getenv("AZURE_AI_API_VERSION_W_FUNCTIONS",'')