from datetime import datetime
from enum import Enum
import json
import logging
from typing import Optional, Union
from wsagent.ai_services.services.azure_ai.enums import AzureAIEnums
from wsagent.ai_services.services.azure_ai.utils.azure_ad_token import get_azure_ad_token
from wsagent.ai_services.services.openai.utils.cost import calculate_embedding_cost
from wsagent.ai_services.services.openai.enums import OpenAIEnums
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.request import request_with_exponential_backoff
from wsagent.utils.validate_args import validate_required_args
    
@validate_required_args
async def create_embedding(
    action: Optional[Union[Enum,str]] = None,
    action_params: Optional[dict] = None,
    ai_service_params: Optional[dict]=None,
    log: Optional[logging.Logger] = None
) -> AIServiceResponse:
    
    init_timestamp=datetime.now().timestamp()
    
    if action is None: raise ValueError("action must be provided")
    if log is None: log=logging.getLogger(__name__)
    if action_params is None: action_params={}
    if ai_service_params is None: raise ValueError("ai_service_params must be provided")
    
    # All parameters for this method
    ## action_params
    input = action_params.get('input', None)
    model = action_params.get('model', None)
    encoding_format = action_params.get('encoding_format', None)
    dimensions = action_params.get('dimensions', None)
    user = action_params.get('user', None)
    retries = action_params.get('retries', None)
    backoff_base = action_params.get('backoff_base', None)
    m_entraid = action_params.get('m_entraid', None)
    azureai_ad_token_provide = ai_service_params.get('azureai_ad_token_provide', None)
    #azure
    deployment = action_params.get('deployment', None)
    extra_body = action_params.get('extra_body', None)
    m_entraid = action_params.get('m_entraid', None)
    # ai_service_params
    api_key = ai_service_params.get('azureai_api_key', None)
    azureai_endpoint_base_url = ai_service_params.get('azureai_endpoint_base_url', None)
    azureai_api_version = ai_service_params.get('azureai_api_version', None)
    azureai_ad_token_provide = ai_service_params.get('azureai_ad_token_provide', None)

    # Check if all required parameters are provided
    # if api_key is None: raise ValueError("openai_api_key cannot be None")
    if input is None or input == '': raise ValueError("input is required")
    
    # Optional parameters with default values
    if model is None: model = OpenAIEnums.Feature.Embeddings.Model.LARGE_V3.name
    if encoding_format is None: encoding_format='float'
    if retries is None: retries=5
    if backoff_base is None: backoff_base=2
    if dimensions is None: dimensions=OpenAIEnums.Feature.Embeddings.Model.LARGE_V3.dimensions
    if m_entraid is None: m_entraid=False
    
    # Set Header
    headers={}
    headers['Content-Type']= 'application/json'
    
    if m_entraid and azureai_ad_token_provide:
        azure_ad_token = await get_azure_ad_token(azureai_ad_token_provide)
        if azure_ad_token is None:
            raise ValueError("Unable to handle auth")
        headers['Authorization'] = f"Bearer {azure_ad_token}"
    else:
        headers['api-key'] = f'{api_key}'
    

    # str_model=None
    # if isinstance(model, str):
    #     str_model = model
    # elif isinstance(model, Enum):
    #     str_model = model.name
    # else:
    #     raise ValueError("action must be a string or Enum.")
    
    # Set data
    data={}
    data["input"]=input
    if model != OpenAIEnums.Feature.Embeddings.Model.ADA_V2:
        data["dimensions"]=dimensions
    
    if encoding_format: data["encoding_format"]=encoding_format
    if user: data["user"]=user
    if extra_body: data["extra_body"] = extra_body

    # Set url
    url = f'https://{azureai_endpoint_base_url}.openai.azure.com/openai/deployments/{deployment}{AzureAIEnums.Endpoints.EMBEDDINGS.value}?api-version={azureai_api_version}'

    log.info(f"Getting embedding for text: {input}")
    log.info(f"data: {data}")
    
    embedding=None
    cost=0
    input_tokens=0    
    total_tokens=0
    raw_response={}
    
    async for response in request_with_exponential_backoff(
        stream=False,
        retries=retries,
        backoff_base=backoff_base,
        url=url, 
        headers=headers, 
        json=data, 
        log=log
    ):
        raw_response = json.loads(response)
        
    embedding = raw_response["data"][0]["embedding"]
    input_tokens = raw_response["usage"]["prompt_tokens"]
    total_tokens = raw_response["usage"]["total_tokens"]
    cost = calculate_embedding_cost(model,input_tokens)
    log.info(f"Embedding received. Cost: ${cost:.10f}")

    yield AIServiceResponse(
        result=embedding,
        action=action,
        action_params=action_params,
        additional_data=None,
        usage= {
            "input_tokens": input_tokens,
            "total_tokens": total_tokens
        },
        cost =  {
            "total_cost": cost
        },
        init_timestamp=init_timestamp,
        raw_response=raw_response
    )