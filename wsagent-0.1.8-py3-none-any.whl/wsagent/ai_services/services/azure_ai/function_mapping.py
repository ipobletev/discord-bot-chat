from wsagent.ai_services.services.azure_ai.enums import AzureAIEnums
from wsagent.ai_services.services.azure_ai.endpoints.chat.chat import create_chat_completion
from wsagent.ai_services.services.azure_ai.endpoints.embedding.embedding import create_embedding

azureai_function_map = {
    ### CHAT ###
    AzureAIEnums.Action.Chat.CREATE.value: create_chat_completion,
    ### EMBEDDING ###
    AzureAIEnums.Action.Embeddings.CREATE.value: create_embedding
}