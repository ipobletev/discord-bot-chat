import inspect

async def get_azure_ad_token(azure_ad_token_provider) -> str | None:

    provider = azure_ad_token_provider
    if provider is not None:
        token = provider()
        if inspect.isawaitable(token):
            token = await token
        if not token or not isinstance(token, str):
            raise ValueError(
                f"Expected `azure_ad_token_provider` argument to return a string but it returned {token}",
            )
        return token

    return None