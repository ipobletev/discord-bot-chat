from enum import Enum, unique

class AzureAIEnums:
        
    @property
    def name(self):
        return "AzureAIEnums"

    class Feature:
        
        class LLM:
            
            class Model(Enum):
            
                # Enum name            Model Name                   cost_per_input_token   cost_per_ouput_token
                # LLM Model
                GPT_3_5_TURBO_16K       = ("azure_gpt-35-turbo-16k",          0.0005   / 1000         , 0.0015     / 1000)
                GPT_3_5_TURBO_INSTRUCT  = ("azure_gpt-35-turbo-instruct",     0.0015   / 1000         , 0.002     / 1000)
                GPT_4                   = ("azure_gpt-4",                     0.03    / 1000          , 0.06      / 1000)
                GPT_4_32K               = ("azure_gpt-4-32k",                 0.06    / 1000          , 0.12      / 1000)
                GPT_4_O                 = ("azure_gpt-4o",                    0.005   / 1000          , 0.015     / 1000)

                @property
                def name(self):
                    return self.value[0]

                @property
                def cost_per_input_token(self):
                    return self.value[1]

                @property
                def cost_per_ouput_token(self):
                    return self.value[2]

        class Image:
            
            class Model(Enum):
                DALL_E_3 = ("dall-e-3", {
                    '1024x1024': {'standard': 0.04, 'hd': 0.08},
                    '1024x1792': {'standard': 0.08, 'hd': 0.12},
                    '1792x1024': {'standard': 0.08, 'hd': 0.12},
                })

                DALL_E_2 = ("dall-e-2", {
                    '1024x1024': 0.02,
                    '512x512': 0.018,
                    '256x256': 0.016,
                })
                
                @property
                def name(self):
                    return self.value[0]
                
                @property
                def cost_usage(self):
                    return self.value[1]
            
            class Resolution(Enum):
                _1024x1024  = "1024x1024"
                _1024x1792  = '1024x1792'
                _1792x1024  = '1792x1024'
                _512x512    = '512x512'
                _256x256    = '256x256'
                
                @property
                def name(self):
                    return self.value

        class Embeddings:

            class Model(Enum):
                
                # Embeddings Model
                ADA_V2              = ("text-embedding-ada-002",    0.0001   / 1000          , 0.0  , 1536)
                SMALL_V3            = ("text-embedding-3-small",    0.00002  / 1000          , 0.0  , 1536)
                LARGE_V3            = ("text-embedding-3-large",    0.00013  / 1000          , 0.0  , 3072)

                @property
                def name(self):
                    return self.value[0]

                @property
                def cost_per_input_token(self):
                    return self.value[1]

                @property
                def dimensions(self):
                    return self.value[3]
                
    class Action:
        
        class Chat(Enum):
            CREATE = "CHAT_CREATE"
            """
            ### Brief: Create a chat completion.
            
            ### Action params:
            
            - messages: list. of messages to be used as context for the completion in OpenAI format. Required.
            - model: Enum. The model to use for the completion. Optional.
            - frequency_penalty: float. The frequency penalty to apply to the completion. Optional.
            - logit_bias: The logit bias to apply to the completion. Optional.
            - logprobs: The logprobs to use for the completion. Optional.
            - max_tokens: The maximum number of tokens to generate. Optional.
            - n: The number of completions to generate. Optional.
            - presence_penalty: The presence penalty to apply to the completion. Optional.
            - response_format: The response format to use for the completion. Optional.
            - seed: The seed to use for the completion. Optional.
            - stop: The stop sequence to use for the completion. Optional.
            - stream: The stream to use for the completion. Optional.
            - temperature: The temperature to use for the completion. Optional.
            - top_p: The top_k to use for the completion. Optional.
            - tools: The tools to use for the completion. Optional.
            - tool_choise: The tool chooise to use for the completion. Optional.
            - user: The user to use for the completion. Optional.
            - function: The function to use for the completion. Optional.
            - retries: The number of retries to use for the completion. Optional.
            - backoff: The backoff to use for the completion. Optional.
            - user_message: The user message to use for the completion. Optional.
            - prefix_message: The prefix message to use for the completion. Optional.
            - suffix_message: The suffix message to use for the completion. Optional.
            - images: The images to use for the completion. Optional.
            - image_details: The image details to use for the completion. Optional.
            - callback: The callback to use for the completion. Optional.
            - stop_event: The stop event to use for the completion. Optional.
            
            - azureai_endpoint_base_url: The azureai endpoint base url to use for the request. Optional.
            - azureai_api_key: The azureai api key to use for the completion. Optional.
            - azureai_api_version: The azureai api version to use for the completion. Optional.
            - deployment: The azureai deployment name to use for the completion. Optional.
            - m_entraid: The m_entraid to True use Microsfot Entra ID, False and use only Api key. Optional.
            - azureai_ad_token_provider: The azureai ad token provider when m_entraid is True. Not use if m_entraid is False. Optional.
            - extra_body: The extra body to use for the azure. Optional.
            
            ### Example
            ```
            messages = [{ "role": "user", "content": [{"type": "text", "text": "Hello, how are you?" }]]

            response = await ai_service.execute(
                action=OpenAIEnums.Action.Chat.CREATE,
                action_params={
                    "model": OpenAIEnums.Feature.LLM.Model.Omni.GPT_4_O,
                    "messages": messages,
                }
            )
            print(response.result)
            ```
            """
            
            @property
            def name(self):
                return self.value
            
        class Embeddings(Enum):
            CREATE = "EMBEDDING_CREATE"
            """
            ### Brief: Create an embedding.
            
            ### Action params:
            
            - input: str. The input text to create the embedding. Required.
            - model: Enum. The model to use for the completion. Optional.
            - encoding_format: str. The encoding format to use for the completion. Optional. Default: float.
            - dimensions: int. The dimensions to use for the completion. Optional.
            - user: str. The user to use for the completion. Optional.
            - retries: int. The number of retries to use for the completion. Optional.
            - backoff: int. The backoff to use for the completion. Optional.
            
            - azureai_endpoint_base_url: The azureai endpoint base url to use for the request. Optional.
            - azureai_api_key: The azureai api key to use for the completion. Optional.
            - azureai_api_version: The azureai api version to use for the completion. Optional.
            - deployment: The azureai deployment name to use for the completion. Optional.
            - m_entraid: The m_entraid to True use Microsfot Entra ID, False and use only Api key. Optional.
            - azureai_ad_token_provider: The azureai ad token provider when m_entraid is True. Not use if m_entraid is False. Optional.
            - extra_body: The extra body to use for the azure. Optional.
            
            ### Example
            ```
            response = await ai_service.execute(
                action=OpenAIEnums.Action.Embeddings.CREATE,
                action_params={
                    "model": OpenAIEnums.Feature.Embeddings.Model.LARGE_V3,
                    "input": "Hello, how are you?",
                }
            )
            print(response.result)
            ```
            """
            
            @property
            def name(self):
                return self.value

        class Images(Enum):
            
            CREATE      = "IMAGE_CREATE"
            EDIT        = "IMAGE_EDIT"
            VARIATION   = "IMAGE_VARIATION"

            @property
            def name(self):
                return self.value

    class Endpoints(Enum):
        EMBEDDINGS          = f"/embeddings"
        CHATCOMPLETION      = f"/chat/completions"
        IMAGES_CREATE       = f"/images/generations"
        IMAGES_EDIT         = f"/images/edits"
        IMAGES_VARIATION    = f"/images/variations"
        
        @property
        def url(self):
            return self.value