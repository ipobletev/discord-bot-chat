from numpy import dot
from numpy.linalg import norm

def vector_similarity(v1, v2):
    cos_score = dot(v1, v2)/(norm(v1)*norm(v2))
    return cos_score