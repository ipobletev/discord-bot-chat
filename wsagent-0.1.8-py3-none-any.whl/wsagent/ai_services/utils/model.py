from enum import Enum
from wsagent.ai_services.ai_services_enum import AIServices

def is_action_in_aiservices(action, aimodel_enum=None):
    def retrieve_enum_classes(cls):
        enum_classes = set()
        # Search for Enum classes within the top-level class (members and subclasses)
        for attr in dir(cls):
            # Skip special attributes
            if attr.startswith('__'):
                continue

            attr_value = getattr(cls, attr)
            if isinstance(attr_value, Enum):
                enum_classes.add(attr_value.__class__) # Add the class of the enum member
            elif isinstance(attr_value, type) and issubclass(attr_value, Enum):
                enum_classes.add(attr_value) # Add the enum class
            elif hasattr(attr_value, "__dict__"): # If it's a class-like, explore further
                enum_classes |= retrieve_enum_classes(attr_value) # Union assignment

        return enum_classes

    # Find all Enum classes within AIEnums
    aimodel_class_enum_classes = retrieve_enum_classes(aimodel_enum)
    # Check if action's class is in the retrieved set of enum classes
    return action.__class__ in aimodel_class_enum_classes

def determine_aiservices_class(action):
    for name in dir(AIServices):
        
        # Retrieve the attribute from AIModel
        attr_value = getattr(AIServices, name)

        if is_action_in_aiservices(action, attr_value):
            return attr_value  # Return the matching enum class
        
    # Return None if the action does not belong to any AIModel enum class
    return None

def get_aiservice_enum_from_action(action):
    for name in dir(AIServices):
        
        # Retrieve the attribute from AIModel
        attr_value = getattr(AIServices, name)

        if is_action_in_aiservices(action, attr_value):
            return attr_value  # Return the matching enum class
        
    # Return None if the action does not belong to any AIModel enum class
    return None

def get_enum_from_name(model_name,obj=AIServices):
    """
    Recursively search for an Enum by name within classes or Enum classes.

    Args:
    - model_name (str): The name of the model to find.
    
    Returns:
    - Enum: The Enum member if found, otherwise None.
    """
    if isinstance(obj, Enum):
        # Access the name property if we have an Enum and the names match
        if obj.name == model_name:
            return obj
    elif isinstance(obj, type):
        # If this is a class, iterate through its non-special attributes
        for attr_name in [attr for attr in dir(obj) if not attr.startswith("__")]:
            attr_value = getattr(obj, attr_name)
            # Continue the search with the attribute value
            result = get_enum_from_name(model_name, attr_value)
            # Return the result if it's an Enum member
            if isinstance(result, Enum):
                return result
    return None

# def get_aiservice_enum_from_modelname(model_name,obj=AIServices):

#     for name in dir(obj):
#         attr_value = getattr(obj, name)
#         if isinstance(attr_value, Enum) and attr_value.name == model_name:
#             return attr_value
#         elif isinstance(attr_value, type):
#             result = 
#             if isinstance(result, Enum):
#                 return result

#     # if isinstance(obj, Enum):
#     #     # Access the name property if we have an Enum and the names match
#     #     if obj.name == model_name:
#     #         return obj
#     # elif isinstance(obj, type):
#     #     # If this is a class, iterate through its non-special attributes
#     #     for attr_name in [attr for attr in dir(obj) if not attr.startswith("__")]:
#     #         attr_value = getattr(obj, attr_name)
#     #         # Continue the search with the attribute value
#     #         result = get_enum_from_name(model_name, attr_value)
#     #         # Return the result if it's an Enum member
#     #         if isinstance(result, Enum):
#     #             return result
#     return None