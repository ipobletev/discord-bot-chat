from enum import Enum
from typing import Any, Dict, Optional, Union
from wsagent.ai_services.ai_services_enum import AIServices
from wsagent.ai_services.base import AIServiceBase
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.ai_services.services_mapping import AIServicesRegistry
from wsagent.utils.validate_args import validate_required_args

class AIServicesInterface():
    
    @validate_required_args
    def __init__(self,
        ai_service_params: Optional[dict]=None,
        session_id: Optional[str]=None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False
    ):
                
        if ai_service_params is None: raise ValueError("ai_service_params must be provided.")

        self.ai_service_params = ai_service_params

        if session_id:
            self.log_name = f'{log_name}.{session_id}.as'
            self.log_path = f'{log_path}/{session_id}/as'
        else:
            self.log_name=f'{log_name}.as'
            self.log_path=f'{log_path}/as'
            
        self.enable_log_file = enable_log_file
        self.enable_log_stream = enable_log_stream
    
    @validate_required_args
    async def execute(self, 
        action: Optional[Union[Enum,str]] = None, 
        action_params: Optional[Dict] = None
    ) -> AIServiceResponse:
        
        if action is None: raise ValueError("action must be provided.")
        aiservices_type=None
        
        # Get aiservices_type from model name
        if action_params and action_params.get("model",None) is not None:
                
                if isinstance(action_params["model"], str):
                    str_model = action_params["model"]
                elif isinstance(action_params["model"], Enum):
                    str_model = action_params["model"].name
                else:
                    raise ValueError("model must be a string or Enum.")
                    
                # If the model is an azure model
                if str_model.startswith("azure_"):
                    #remove azure_ prefix
                    action_params["model"] = str_model[6:]
                    aiservices_type = AIServices.AzureAI
                else:
                    # Get aimodel enum
                    aiservices_type = AIServices.get_aiservices_from_str_model(str_model)
                    if aiservices_type is None:
                        raise ValueError(f"aiservices_type not found for model: {str_model}")
            
        # Get aiservices_type from action name
        else:
            
            if isinstance(action, str):
                str_action = action
            elif isinstance(action, Enum):
                str_action = action.name
            else:
                raise ValueError("model must be a string or Enum.")
                
            # Get aimodel enum
            aiservices_type = AIServices.get_aiservices_from_action(str_action)
            if aiservices_type is None:
                raise ValueError(f"aiservices_type not found for action: {str_action}")
        
        # Get aimodel class
        ai_service_class = AIServicesRegistry.get_ai_services(aiservices_type) 
        if ai_service_class is None:
            raise ValueError(f"ai_service_class cannot aimodel class for action: {action}")
        
        # Create an instance of the aiservice class.
        self.ai_service_instance: AIServiceBase = ai_service_class(
            ai_service_params=self.ai_service_params,
            session_id=None,
            log_name=self.log_name,
            log_path=self.log_path,
            enable_log_file=self.enable_log_file,
            enable_log_stream=self.enable_log_stream
        )
        
        async for result in self.ai_service_instance.execute(
            action=action,
            action_params=action_params
        ):
            yield result
                
    @staticmethod
    @validate_required_args
    async def standalone_execute(
        ai_service_params: Optional[Dict] = None,
        session_id: Optional[str] = None,
        action: Optional[Union[Enum,str]] = None,
        action_params: Optional[Dict] = None,
        # Logging parameters
        log_name: Optional[bool] = None,
        log_path: Optional[bool] = None,
        enable_log_file: Optional[bool] = None,
        enable_log_stream: Optional[bool] = None,
    ) -> AIServiceResponse:
        
        if ai_service_params is None: raise ValueError("ai_service_params must be provided.")
        if action_params is None: ValueError("action_params must be provided.")
        if action_params["model"] is None: raise ValueError("model is required")
        
        if action is None: raise ValueError("action must be provided.")
        aiservices_type=None
        
        # Get aiservices_type from model name
        if action_params and action_params.get("model",None) is not None:
                
                if isinstance(action_params["model"], str):
                    str_model = action_params["model"]
                elif isinstance(action_params["model"], Enum):
                    str_model = action_params["model"].name
                else:
                    raise ValueError("model must be a string or Enum.")
                    
                # Get aimodel enum
                aiservices_type = AIServices.get_aiservices_from_str_model(str_model)
                if aiservices_type is None:
                    raise ValueError(f"aiservices_type not found for model: {str_model}")
            
        # Get aiservices_type from action name
        else:
            
            if isinstance(action, str):
                str_action = action
            elif isinstance(action, Enum):
                str_action = action.name
            else:
                raise ValueError("model must be a string or Enum.")
                
            # Get aimodel enum
            aiservices_type = AIServices.get_aiservices_from_action(str_action)
            if aiservices_type is None:
                raise ValueError(f"aiservices_type not found for action: {str_action}")
        
        # Get aimodel class
        ai_service_class = AIServicesRegistry.get_ai_services(aiservices_type) 
        if ai_service_class is None:
            raise ValueError(f"ai_service_class cannot aimodel class for action: {action}")
        
        # Create an instance of the aiservice class.
        ai_service_instance: AIServiceBase = ai_service_class(
            ai_service_params=ai_service_params,
            session_id=session_id,
            log_name=log_name,
            log_path=log_path,
            enable_log_file=enable_log_file,
            enable_log_stream=enable_log_stream
        )

        # Execute the requested action on the aiservice instance.
        async for result in ai_service_instance.execute(
            action=action,
            action_params=action_params,
            ai_service_params=ai_service_params
        ):
            yield result