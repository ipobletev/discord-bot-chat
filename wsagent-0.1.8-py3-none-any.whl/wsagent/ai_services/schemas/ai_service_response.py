from enum import Enum
import time
from typing import Any, Optional, Union
from wsagent.utils.validate_args import validate_required_args

class AIServiceResponse:
    @validate_required_args
    def __init__(self,
        result: Optional[Any] = None,
        additional_data: Optional[dict] = None,
        action: Optional[Union[Enum,str]] = None,
        action_params: Optional[dict] = None,
        cost: Optional[dict] = None,
        usage: Optional[dict] = None,
        init_timestamp: Optional[Union[float,int]] = None,
        raw_response: Optional[dict] = None,
    ):
        self._result=result
        self._additional_data=additional_data
        self._action=action
        self._action_params=action_params
        self._cost=cost
        self._usage=usage
        self._init_timestamp=init_timestamp
        self._raw_response=raw_response
        
        if result is None: raise ValueError("result is required")
        if action is None: raise ValueError("action must be provided")
        if action_params is None: action_params={}
        if init_timestamp is None: raise ValueError("init_timestamp is required")
        
        self._time_exec=time.time() - init_timestamp
    
    @property
    def result(self):
        return self._result
    
    @property
    def additional_data(self):
        return self._additional_data
    
    @property
    def action(self):
        return self._action

    @property
    def cost(self):
        return self._cost
 
    @property
    def usage(self):
        return self._usage
    
    @property
    def action_params(self):
        return self._action_params
    
    @property
    def init_timestamp(self):
        return self._init_timestamp
    
    @property
    def raw_response(self):
        return self._raw_response
    
    @property
    def time_exec(self):
        return self._time_exec
    
    def to_json(self):
        def serialize(obj):
            if hasattr(obj, "to_dict"):
                return obj.to_dict()
            elif isinstance(obj, list):
                return [serialize(item) for item in obj]
            elif isinstance(obj, dict):
                return {key.lstrip('_'): serialize(value) for key, value in obj.items()}
            elif isinstance(obj, (int, float, str, bool, type(None))):  # check for basic types
                return obj
            else:
                return str(obj)  # default to string for any other types that are not recognized

        return {key.lstrip('_'): serialize(value) for key, value in self.__dict__.items()}