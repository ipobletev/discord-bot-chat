from enum import Enum
from abc import ABC, abstractmethod
from datetime import datetime
from typing import AsyncGenerator, Optional, Union
from wsagent.ai_services.schemas.ai_service_response import AIServiceResponse
from wsagent.utils.logs import PrintAndLog
import uuid

class AIServiceBase(ABC): 
    """An abstract class representing an OpenAI model.

    This serves as a blueprint for specific OpenAI models, requiring the implementation of core functionality.
    """

    def __init__(self, 
        ai_service_name: Optional[str] = None,
        ai_service_params: Optional[dict] = None,
        session_id: Optional[str] = None,
        log_name: Optional[str] = None,
        log_path: Optional[str] = None,
        enable_log_file: Optional[bool]=False,
        enable_log_stream: Optional[bool]=False):
        """Initializes the OpenAI model with essential parameters.
        """
                
        if ai_service_name is None: raise ValueError("ai_service_name must be provided")
        if ai_service_params is None: raise ValueError("ai_service_params must be provided")

        self.ai_service_name=ai_service_name     
        self.ai_service_params=ai_service_params   
        self.session_id=session_id
        self.log_name=log_name
        self.log_path=log_path
        self.enable_log_file=enable_log_file
        self.enable_log_stream=enable_log_stream

    async def execute(self,
        action: Optional[Union[Enum,str]] = None,
        action_params: Optional[dict] = None,
    ) -> AsyncGenerator[Union[str, AIServiceResponse], None]:
        
        execution_id = str(uuid.uuid4())[:8]
        
        if self.session_id:
            log_name = f'{self.log_name}.{self.session_id}.{self.ai_service_name}.{execution_id}'
            log_path = f'{self.log_path}/{self.session_id}/{self.ai_service_name}/{datetime.now().strftime("%m-%d-%Y-%H-%M-%S")}-{execution_id}'
        else:
            log_name=f'{self.log_name}.{self.ai_service_name}.{execution_id}'
            log_path=f'{self.log_path}/{self.ai_service_name}/{datetime.now().strftime("%m-%d-%Y-%H-%M-%S")}-{execution_id}'
            
        self.log=PrintAndLog(
            log_name=log_name,
			log_path=log_path,
            enable_log_file=self.enable_log_file,
            enable_log_stream=self.enable_log_stream
        ).logger
    
        # Consume the internal_async_generator and yield its results
        async for result in self.internal_execute(action, action_params):
            yield result
    
    @abstractmethod
    async def internal_execute(self,
        action: Optional[Union[Enum,str]] = None,
        action_params: Optional[dict] = None,
    ) -> AsyncGenerator[Union[str, AIServiceResponse], None]:
        pass